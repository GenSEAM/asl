source_filename = "asl-target-llvm/gcAsl"

@str.0 = private unnamed_addr constant [13 x i8] c"ERR_INTERNAL\00"
@str.1 = private unnamed_addr constant [23 x i8] c"gc root stack overflow\00"
@str.2 = private unnamed_addr constant [8 x i8] c"ERR_OOM\00"
@str.3 = private unnamed_addr constant [53 x i8] c"out of memory growing the GC page set to %zu entries\00"
@str.4 = private unnamed_addr constant [37 x i8] c"gc page set is empty on page release\00"
@str.5 = private unnamed_addr constant [37 x i8] c"gc page %p missing from the page set\00"
@str.6 = private unnamed_addr constant [33 x i8] c"out of memory allocating GC page\00"
@str.7 = private unnamed_addr constant [60 x i8] c"out of memory growing the large object index to %zu entries\00"
@str.8 = private unnamed_addr constant [35 x i8] c"out of memory allocating %zu bytes\00"
@str.9 = private unnamed_addr constant [37 x i8] c"live heap exceeds ASL_GC_MAX_MIB=%zu\00"
@str.10 = private unnamed_addr constant [40 x i8] c"gcScanConservative outside a collection\00"
@str.11 = private unnamed_addr constant [44 x i8] c"gcScanConservative range %p..%p is inverted\00"
@str.12 = private unnamed_addr constant [15 x i8] c"ERR_HEAP_CYCLE\00"
@str.13 = private unnamed_addr constant [33 x i8] c"cycle of depth %d detected in %s\00"
@str.14 = private unnamed_addr constant [31 x i8] c"(:gcCycle :type %s :depth %d)\0A\00"
@str.15 = private unnamed_addr constant [10 x i8] c"ERR_LIMIT\00"
@str.16 = private unnamed_addr constant [45 x i8] c"heap verification stack depth limit exceeded\00"
@str.17 = private unnamed_addr constant [9 x i8] c"ERR_OOM\0A\00"
@str.18 = private unnamed_addr constant [162 x i8] c"(:gcStats :collections %llu :objectsAllocated %llu :objectsFreed %llu :bytesAllocated %llu :bytesLive %llu :totalGCNs %llu :pagesFreed %llu :pagesAcquired %llu)\0A\00"
@str.19 = private unnamed_addr constant [14 x i8] c"ASL_GC_STRESS\00"
@str.20 = private unnamed_addr constant [13 x i8] c"ASL_GC_STATS\00"
@str.21 = private unnamed_addr constant [14 x i8] c"ASL_GC_GROWTH\00"
@str.22 = private unnamed_addr constant [15 x i8] c"ASL_GC_MIN_MIB\00"
@str.23 = private unnamed_addr constant [15 x i8] c"ASL_GC_MAX_MIB\00"
@str.24 = private unnamed_addr constant [14 x i8] c"ASL_GC_VERIFY\00"
@str.25 = private unnamed_addr constant [65 x i8] c"ERR_ENV: ASL_GC_GROWTH must be a number in [0.25, 64], got '%s'\0A\00"
@str.26 = private unnamed_addr constant [68 x i8] c"ERR_ENV: ASL_GC_MIN_MIB must be an integer in [1, 65536], got '%s'\0A\00"
@str.27 = private unnamed_addr constant [68 x i8] c"ERR_ENV: ASL_GC_MAX_MIB must be an integer in [1, 65536], got '%s'\0A\00"
@str.28 = private unnamed_addr constant [29 x i8] c"cannot unmap GC memory at %p\00"
@str.29 = private unnamed_addr constant [135 x i8] c"(:gcPhases :markNs %llu :sweepLargeNs %llu :sweepPagesNs %llu :releaseNs %llu :pagesMapped %llu :pagesUnmapped %llu :unmapCalls %llu)\0A\00"
@str.30 = private unnamed_addr constant [37 x i8] c"out of memory releasing %zu GC pages\00"
@str.31 = private unnamed_addr constant [6 x i8] c":cons\00"
@str.32 = private unnamed_addr constant [8 x i8] c":record\00"
@str.33 = private unnamed_addr constant [6 x i8] c":ctor\00"
@str.34 = private unnamed_addr constant [9 x i8] c":closure\00"
@str.35 = private unnamed_addr constant [8 x i8] c":string\00"
@str.36 = private unnamed_addr constant [7 x i8] c":bytes\00"
@str.37 = private unnamed_addr constant [7 x i8] c":array\00"
@str.38 = private unnamed_addr constant [8 x i8] c":handle\00"
@str.39 = private unnamed_addr constant [9 x i8] c":unknown\00"

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2ErootPush(i64 %v) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %n$2Eptr = inttoptr i64 %s to ptr
  %n$2Eoff = bitcast i64 128 to i64
  %n.p.gep = getelementptr inbounds i8, ptr %n$2Eptr, i64 %n$2Eoff
  %n = load i64, ptr %n.p.gep
  %full$2Ek = bitcast i64 4096 to i64
  %full = icmp eq i64 %n, %full$2Ek
  br i1 %full, label %bb.full, label %bb.put
bb.full:
  %full$2Ec = bitcast ptr @str.0 to ptr
  %full$2Ef = bitcast ptr @str.1 to ptr
  %full$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %full$2Ec, ptr %full$2Ef)
  %full$2Ez = bitcast i64 0 to i64
  ret i64 %full$2Ez
bb.put:
  %base$2Ek = bitcast i64 2048 to i64
  %base = add i64 %s, %base$2Ek
  %at$2Em$2Ek = bitcast i64 8 to i64
  %at$2Em = mul i64 %n, %at$2Em$2Ek
  %at = add i64 %base, %at$2Em
  %w$2Eptr = inttoptr i64 %at to ptr
  %w$2Eoff = bitcast i64 0 to i64
  %w.p.gep = getelementptr inbounds i8, ptr %w$2Eptr, i64 %w$2Eoff
  store i64 %v, ptr %w.p.gep
  %w = bitcast i1 true to i1
  %n1$2Ek = bitcast i64 1 to i64
  %n1 = add i64 %n, %n1$2Ek
  %c$2Eptr = inttoptr i64 %s to ptr
  %c$2Eoff = bitcast i64 128 to i64
  %c.p.gep = getelementptr inbounds i8, ptr %c$2Eptr, i64 %c$2Eoff
  store i64 %n1, ptr %c.p.gep
  %c = bitcast i1 true to i1
  %put$2Ez = bitcast i64 0 to i64
  ret i64 %put$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2ErootPop(i64 %n) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %c$2Eptr = inttoptr i64 %s to ptr
  %c$2Eoff = bitcast i64 128 to i64
  %c.p.gep = getelementptr inbounds i8, ptr %c$2Eptr, i64 %c$2Eoff
  %c = load i64, ptr %c.p.gep
  %c1 = sub i64 %c, %n
  %w$2Eptr = inttoptr i64 %s to ptr
  %w$2Eoff = bitcast i64 128 to i64
  %w.p.gep = getelementptr inbounds i8, ptr %w$2Eptr, i64 %w$2Eoff
  store i64 %c1, ptr %w.p.gep
  %w = bitcast i1 true to i1
  %entry$2Ez = bitcast i64 0 to i64
  ret i64 %entry$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EregisterProto(i64 %p) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %n$2Eptr = inttoptr i64 %s to ptr
  %n$2Eoff = bitcast i64 144 to i64
  %n.p.gep = getelementptr inbounds i8, ptr %n$2Eptr, i64 %n$2Eoff
  %n = load i64, ptr %n.p.gep
  %cap$2Eptr = inttoptr i64 %s to ptr
  %cap$2Eoff = bitcast i64 152 to i64
  %cap.p.gep = getelementptr inbounds i8, ptr %cap$2Eptr, i64 %cap$2Eoff
  %cap = load i64, ptr %cap.p.gep
  %full = icmp eq i64 %n, %cap
  br i1 %full, label %bb.grow, label %bb.put
bb.grow:
  %z$2Ek = bitcast i64 0 to i64
  %z = icmp eq i64 %cap, %z$2Ek
  %first = bitcast i64 64 to i64
  %twice$2Ek = bitcast i64 2 to i64
  %twice = mul i64 %cap, %twice$2Ek
  br i1 %z, label %bb.grow.e0, label %bb.grow.e1
bb.grow.e0:
  br label %bb.sized
bb.grow.e1:
  br label %bb.sized
bb.sized:
  %nc = phi i64 [ %first, %bb.grow.e0 ], [ %twice, %bb.grow.e1 ]
  %bytes$2Ek = bitcast i64 8 to i64
  %bytes = mul i64 %nc, %bytes$2Ek
  %old$2Eptr = inttoptr i64 %s to ptr
  %old$2Eoff = bitcast i64 136 to i64
  %old.p.gep = getelementptr inbounds i8, ptr %old$2Eptr, i64 %old$2Eoff
  %old = load i64, ptr %old.p.gep
  %oldp = inttoptr i64 %old to ptr
  %r = call ptr (ptr, i64) @realloc(ptr %oldp, i64 %bytes)
  %ri = ptrtoint ptr %r to i64
  %w1$2Eptr = inttoptr i64 %s to ptr
  %w1$2Eoff = bitcast i64 136 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %ri, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  %w2$2Eptr = inttoptr i64 %s to ptr
  %w2$2Eoff = bitcast i64 152 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %nc, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  %dead$2Ek = bitcast i64 0 to i64
  %dead = icmp eq i64 %ri, %dead$2Ek
  br i1 %dead, label %bb.die, label %bb.put
bb.die:
  %die$2Ec = bitcast i32 70 to i32
  %die$2Er = call i64 (i32) @exit(i32 %die$2Ec)
  %die$2Ez = bitcast i64 0 to i64
  ret i64 %die$2Ez
bb.put:
  %arr$2Eptr = inttoptr i64 %s to ptr
  %arr$2Eoff = bitcast i64 136 to i64
  %arr.p.gep = getelementptr inbounds i8, ptr %arr$2Eptr, i64 %arr$2Eoff
  %arr = load i64, ptr %arr.p.gep
  %at$2Em$2Ek = bitcast i64 8 to i64
  %at$2Em = mul i64 %n, %at$2Em$2Ek
  %at = add i64 %arr, %at$2Em
  %w3$2Eptr = inttoptr i64 %at to ptr
  %w3$2Eoff = bitcast i64 0 to i64
  %w3.p.gep = getelementptr inbounds i8, ptr %w3$2Eptr, i64 %w3$2Eoff
  store i64 %p, ptr %w3.p.gep
  %w3 = bitcast i1 true to i1
  %n1$2Ek = bitcast i64 1 to i64
  %n1 = add i64 %n, %n1$2Ek
  %w4$2Eptr = inttoptr i64 %s to ptr
  %w4$2Eoff = bitcast i64 144 to i64
  %w4.p.gep = getelementptr inbounds i8, ptr %w4$2Eptr, i64 %w4$2Eoff
  store i64 %n1, ptr %w4.p.gep
  %w4 = bitcast i1 true to i1
  %put$2Ez = bitcast i64 0 to i64
  ret i64 %put$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmarkObj(i64 %o) alwaysinline {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %h$2Eptr = inttoptr i64 %o to ptr
  %h$2Eoff = bitcast i64 0 to i64
  %h.p.gep = getelementptr inbounds i8, ptr %h$2Eptr, i64 %h$2Eoff
  %h = load i64, ptr %h.p.gep
  %cls$2Ek = bitcast i64 56 to i64
  %cls.p.m = and i64 %cls$2Ek, 63
  %cls = lshr i64 %h, %cls.p.m
  %pooled$2Ek = bitcast i64 255 to i64
  %pooled = icmp ne i64 %cls, %pooled$2Ek
  br i1 %pooled, label %bb.ptest, label %bb.ltest
bb.ltest:
  %skip$2Emark$2Es$2Ek = bitcast i64 40 to i64
  %skip$2Emark$2Es.p.m = and i64 %skip$2Emark$2Es$2Ek, 63
  %skip$2Emark$2Es = lshr i64 %h, %skip$2Emark$2Es.p.m
  %skip$2Emark$2Ek = bitcast i64 255 to i64
  %skip$2Emark = and i64 %skip$2Emark$2Es, %skip$2Emark$2Ek
  %skip$2Eperm$2Es$2Ek = bitcast i64 48 to i64
  %skip$2Eperm$2Es.p.m = and i64 %skip$2Eperm$2Es$2Ek, 63
  %skip$2Eperm$2Es = lshr i64 %h, %skip$2Eperm$2Es.p.m
  %skip$2Eperm$2Ek = bitcast i64 255 to i64
  %skip$2Eperm = and i64 %skip$2Eperm$2Es, %skip$2Eperm$2Ek
  %skip$2Ety$2Es$2Ek = bitcast i64 32 to i64
  %skip$2Ety$2Es.p.m = and i64 %skip$2Ety$2Es$2Ek, 63
  %skip$2Ety$2Es = lshr i64 %h, %skip$2Ety$2Es.p.m
  %skip$2Ety$2Ek = bitcast i64 255 to i64
  %skip$2Ety = and i64 %skip$2Ety$2Es, %skip$2Ety$2Ek
  %skip$2Emarked$2Ek = bitcast i64 0 to i64
  %skip$2Emarked = icmp ne i64 %skip$2Emark, %skip$2Emarked$2Ek
  %skip$2Eheld$2Ek = bitcast i64 0 to i64
  %skip$2Eheld = icmp ne i64 %skip$2Eperm, %skip$2Eheld$2Ek
  %skip$2Ehandle$2Ek = bitcast i64 7 to i64
  %skip$2Ehandle = icmp eq i64 %skip$2Ety, %skip$2Ehandle$2Ek
  %skip$2Eown = xor i1 %skip$2Ehandle, true
  %skip$2Ekept = and i1 %skip$2Eheld, %skip$2Eown
  %skip = or i1 %skip$2Emarked, %skip$2Ekept
  br i1 %skip, label %bb.done, label %bb.lset
bb.lset:
  %m$2Eptr = inttoptr i64 %o to ptr
  %m$2Eoff = bitcast i64 5 to i64
  %m$2Ev = bitcast i32 1 to i32
  %m.p.gep = getelementptr inbounds i8, ptr %m$2Eptr, i64 %m$2Eoff
  %m.p.trunc = trunc i32 %m$2Ev to i8
  store i8 %m.p.trunc, ptr %m.p.gep
  %m = bitcast i1 true to i1
  br label %bb.push
bb.ptest:
  %pm$2Es$2Ek = bitcast i64 40 to i64
  %pm$2Es.p.m = and i64 %pm$2Es$2Ek, 63
  %pm$2Es = lshr i64 %h, %pm$2Es.p.m
  %pm$2Ek = bitcast i64 255 to i64
  %pm = and i64 %pm$2Es, %pm$2Ek
  %ep$2Eptr = inttoptr i64 %s to ptr
  %ep$2Eoff = bitcast i64 456 to i64
  %ep.p.gep = getelementptr inbounds i8, ptr %ep$2Eptr, i64 %ep$2Eoff
  %ep = load i64, ptr %ep.p.gep
  %seen = icmp eq i64 %pm, %ep
  br i1 %seen, label %bb.done, label %bb.page
bb.page:
  %em$2Eptr = inttoptr i64 %o to ptr
  %em$2Eoff = bitcast i64 5 to i64
  %em$2En.p.low = icmp sge i64 %ep, -2147483648
  %em$2En.p.high = icmp sle i64 %ep, 2147483647
  %em$2En.p.fits = and i1 %em$2En.p.low, %em$2En.p.high
  %em$2En.p.bad = xor i1 %em$2En.p.fits, true
  br i1 %em$2En.p.bad, label %em$2En.p.trap, label %em$2En.p.ok
em$2En.p.trap:
  call void @rterr.int(i32 7)
  unreachable
em$2En.p.ok:
  %em$2En = trunc i64 %ep to i32
  %em.p.gep = getelementptr inbounds i8, ptr %em$2Eptr, i64 %em$2Eoff
  %em.p.trunc = trunc i32 %em$2En to i8
  store i8 %em.p.trunc, ptr %em.p.gep
  %em = bitcast i1 true to i1
  %mb$2Epg$2Ek = bitcast i64 -16384 to i64
  %mb$2Epg = and i64 %o, %mb$2Epg$2Ek
  %mb$2Er0 = sub i64 %o, %mb$2Epg
  %mb$2Erel$2Ek = bitcast i64 -512 to i64
  %mb$2Erel = add i64 %mb$2Er0, %mb$2Erel$2Ek
  %mb$2Erc$2Eptr = inttoptr i64 %mb$2Epg to ptr
  %mb$2Erc$2Eoff = bitcast i64 16 to i64
  %mb$2Erc.p.gep = getelementptr inbounds i8, ptr %mb$2Erc$2Eptr, i64 %mb$2Erc$2Eoff
  %mb$2Erc = load i64, ptr %mb$2Erc.p.gep
  %mb$2Epr = mul i64 %mb$2Erel, %mb$2Erc
  %mb$2Eidx$2Ek = bitcast i64 32 to i64
  %mb$2Eidx.p.m = and i64 %mb$2Eidx$2Ek, 63
  %mb$2Eidx = lshr i64 %mb$2Epr, %mb$2Eidx.p.m
  %mb$2Ewi$2Ek = bitcast i64 6 to i64
  %mb$2Ewi.p.m = and i64 %mb$2Ewi$2Ek, 63
  %mb$2Ewi = lshr i64 %mb$2Eidx, %mb$2Ewi.p.m
  %mb$2Ewo$2Ek = bitcast i64 3 to i64
  %mb$2Ewo.p.m = and i64 %mb$2Ewo$2Ek, 63
  %mb$2Ewo = shl i64 %mb$2Ewi, %mb$2Ewo.p.m
  %mb$2Ewb = add i64 %mb$2Epg, %mb$2Ewo
  %mb$2Ewa$2Ek = bitcast i64 200 to i64
  %mb$2Ewa = add i64 %mb$2Ewb, %mb$2Ewa$2Ek
  %mb$2Ew$2Eptr = inttoptr i64 %mb$2Ewa to ptr
  %mb$2Ew$2Eoff = bitcast i64 0 to i64
  %mb$2Ew.p.gep = getelementptr inbounds i8, ptr %mb$2Ew$2Eptr, i64 %mb$2Ew$2Eoff
  %mb$2Ew = load i64, ptr %mb$2Ew.p.gep
  %mb$2Ebn$2Ek = bitcast i64 63 to i64
  %mb$2Ebn = and i64 %mb$2Eidx, %mb$2Ebn$2Ek
  %mb$2Eone = bitcast i64 1 to i64
  %mb$2Ebit.p.m = and i64 %mb$2Ebn, 63
  %mb$2Ebit = shl i64 %mb$2Eone, %mb$2Ebit.p.m
  %ms$2Ew1 = or i64 %mb$2Ew, %mb$2Ebit
  %ms$2Esw$2Eptr = inttoptr i64 %mb$2Ewa to ptr
  %ms$2Esw$2Eoff = bitcast i64 0 to i64
  %ms$2Esw.p.gep = getelementptr inbounds i8, ptr %ms$2Esw$2Eptr, i64 %ms$2Esw$2Eoff
  store i64 %ms$2Ew1, ptr %ms$2Esw.p.gep
  %ms$2Esw = bitcast i1 true to i1
  %sz$2Ek = bitcast i64 4294967295 to i64
  %sz = and i64 %h, %sz$2Ek
  %lb$2Eold$2Eptr = inttoptr i64 %s to ptr
  %lb$2Eold$2Eoff = bitcast i64 448 to i64
  %lb$2Eold.p.gep = getelementptr inbounds i8, ptr %lb$2Eold$2Eptr, i64 %lb$2Eold$2Eoff
  %lb$2Eold = load i64, ptr %lb$2Eold.p.gep
  %lb$2Enew = add i64 %lb$2Eold, %sz
  %lb$2Eptr = inttoptr i64 %s to ptr
  %lb$2Eoff = bitcast i64 448 to i64
  %lb.p.gep = getelementptr inbounds i8, ptr %lb$2Eptr, i64 %lb$2Eoff
  store i64 %lb$2Enew, ptr %lb.p.gep
  %lb = bitcast i1 true to i1
  br label %bb.push
bb.push:
  %sp$2Eptr = inttoptr i64 %s to ptr
  %sp$2Eoff = bitcast i64 168 to i64
  %sp.p.gep = getelementptr inbounds i8, ptr %sp$2Eptr, i64 %sp$2Eoff
  %sp = load i64, ptr %sp.p.gep
  %cap$2Eptr = inttoptr i64 %s to ptr
  %cap$2Eoff = bitcast i64 176 to i64
  %cap.p.gep = getelementptr inbounds i8, ptr %cap$2Eptr, i64 %cap$2Eoff
  %cap = load i64, ptr %cap.p.gep
  %full = icmp eq i64 %sp, %cap
  br i1 %full, label %bb.grow, label %bb.put
bb.grow:
  %g = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EgrowMark(i64 %cap)
  br label %bb.put
bb.put:
  %stk$2Eptr = inttoptr i64 %s to ptr
  %stk$2Eoff = bitcast i64 160 to i64
  %stk.p.gep = getelementptr inbounds i8, ptr %stk$2Eptr, i64 %stk$2Eoff
  %stk = load i64, ptr %stk.p.gep
  %at$2Em$2Ek = bitcast i64 8 to i64
  %at$2Em = mul i64 %sp, %at$2Em$2Ek
  %at = add i64 %stk, %at$2Em
  %w3$2Eptr = inttoptr i64 %at to ptr
  %w3$2Eoff = bitcast i64 0 to i64
  %w3.p.gep = getelementptr inbounds i8, ptr %w3$2Eptr, i64 %w3$2Eoff
  store i64 %o, ptr %w3.p.gep
  %w3 = bitcast i1 true to i1
  %sp1$2Ek = bitcast i64 1 to i64
  %sp1 = add i64 %sp, %sp1$2Ek
  %w4$2Eptr = inttoptr i64 %s to ptr
  %w4$2Eoff = bitcast i64 168 to i64
  %w4.p.gep = getelementptr inbounds i8, ptr %w4$2Eptr, i64 %w4$2Eoff
  store i64 %sp1, ptr %w4.p.gep
  %w4 = bitcast i1 true to i1
  %put$2Ez = bitcast i64 0 to i64
  ret i64 %put$2Ez
bb.done:
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EgrowMark(i64 %cap) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %z$2Ek = bitcast i64 0 to i64
  %z = icmp eq i64 %cap, %z$2Ek
  %first = bitcast i64 1024 to i64
  %twice$2Ek = bitcast i64 2 to i64
  %twice = mul i64 %cap, %twice$2Ek
  br i1 %z, label %bb.entry.e0, label %bb.entry.e1
bb.entry.e0:
  br label %bb.sized
bb.entry.e1:
  br label %bb.sized
bb.sized:
  %nc = phi i64 [ %first, %bb.entry.e0 ], [ %twice, %bb.entry.e1 ]
  %bytes$2Ek = bitcast i64 8 to i64
  %bytes = mul i64 %nc, %bytes$2Ek
  %old$2Eptr = inttoptr i64 %s to ptr
  %old$2Eoff = bitcast i64 160 to i64
  %old.p.gep = getelementptr inbounds i8, ptr %old$2Eptr, i64 %old$2Eoff
  %old = load i64, ptr %old.p.gep
  %oldp = inttoptr i64 %old to ptr
  %r = call ptr (ptr, i64) @realloc(ptr %oldp, i64 %bytes)
  %ri = ptrtoint ptr %r to i64
  %w1$2Eptr = inttoptr i64 %s to ptr
  %w1$2Eoff = bitcast i64 160 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %ri, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  %w2$2Eptr = inttoptr i64 %s to ptr
  %w2$2Eoff = bitcast i64 176 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %nc, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  %dead$2Ek = bitcast i64 0 to i64
  %dead = icmp eq i64 %ri, %dead$2Ek
  br i1 %dead, label %bb.die, label %bb.done
bb.die:
  %die$2Ec = bitcast i32 70 to i32
  %die$2Er = call i64 (i32) @exit(i32 %die$2Ec)
  %die$2Ez = bitcast i64 0 to i64
  ret i64 %die$2Ez
bb.done:
  ret i64 %ri
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmarkVal(i64 %tag, i64 %obj) alwaysinline {
bb.entry:
  %has$2Elo$2Ek = bitcast i64 5 to i64
  %has$2Elo = icmp sge i64 %tag, %has$2Elo$2Ek
  %has$2Ehi$2Ek = bitcast i64 15 to i64
  %has$2Ehi = icmp sle i64 %tag, %has$2Ehi$2Ek
  %has$2Ene$2Ek = bitcast i64 10 to i64
  %has$2Ene = icmp ne i64 %tag, %has$2Ene$2Ek
  %has$2Enz$2Ek = bitcast i64 0 to i64
  %has$2Enz = icmp ne i64 %obj, %has$2Enz$2Ek
  %has$2Ea = and i1 %has$2Elo, %has$2Ehi
  %has$2Eb = and i1 %has$2Ene, %has$2Enz
  %has = and i1 %has$2Ea, %has$2Eb
  br i1 %has, label %bb.mark, label %bb.done
bb.mark:
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmarkObj(i64 %obj)
  %mark$2Ez = bitcast i64 0 to i64
  ret i64 %mark$2Ez
bb.done:
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Edrain() {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %sp0$2Eptr = inttoptr i64 %s to ptr
  %sp0$2Eoff = bitcast i64 168 to i64
  %sp0.p.gep = getelementptr inbounds i8, ptr %sp0$2Eptr, i64 %sp0$2Eoff
  %sp0 = load i64, ptr %sp0.p.gep
  %idle$2Ek = bitcast i64 0 to i64
  %idle = icmp eq i64 %sp0, %idle$2Ek
  br i1 %idle, label %bb.idle, label %bb.start
bb.idle:
  %idle$2Ez = bitcast i64 0 to i64
  ret i64 %idle$2Ez
bb.start:
  %ep$2Eptr = inttoptr i64 %s to ptr
  %ep$2Eoff = bitcast i64 456 to i64
  %ep.p.gep = getelementptr inbounds i8, ptr %ep$2Eptr, i64 %ep$2Eoff
  %ep = load i64, ptr %ep.p.gep
  %ep8.p.low = icmp sge i64 %ep, -2147483648
  %ep8.p.high = icmp sle i64 %ep, 2147483647
  %ep8.p.fits = and i1 %ep8.p.low, %ep8.p.high
  %ep8.p.bad = xor i1 %ep8.p.fits, true
  br i1 %ep8.p.bad, label %ep8.p.trap, label %ep8.p.ok
ep8.p.trap:
  call void @rterr.int(i32 7)
  unreachable
ep8.p.ok:
  %ep8 = trunc i64 %ep to i32
  %stk0$2Eptr = inttoptr i64 %s to ptr
  %stk0$2Eoff = bitcast i64 160 to i64
  %stk0.p.gep = getelementptr inbounds i8, ptr %stk0$2Eptr, i64 %stk0$2Eoff
  %stk0 = load i64, ptr %stk0.p.gep
  %cap0$2Eptr = inttoptr i64 %s to ptr
  %cap0$2Eoff = bitcast i64 176 to i64
  %cap0.p.gep = getelementptr inbounds i8, ptr %cap0$2Eptr, i64 %cap0$2Eoff
  %cap0 = load i64, ptr %cap0.p.gep
  %mb0$2Eptr = inttoptr i64 %s to ptr
  %mb0$2Eoff = bitcast i64 448 to i64
  %mb0.p.gep = getelementptr inbounds i8, ptr %mb0$2Eptr, i64 %mb0$2Eoff
  %mb0 = load i64, ptr %mb0.p.gep
  br label %bb.loop
bb.loop:
  %sp = phi i64 [ %sp0, %ep8.p.ok ], [ %sp1, %bb.leaf ], [ %ksp, %bb.kids ]
  %stk = phi i64 [ %stk0, %ep8.p.ok ], [ %stk, %bb.leaf ], [ %kstk, %bb.kids ]
  %cap = phi i64 [ %cap0, %ep8.p.ok ], [ %cap, %bb.leaf ], [ %kcap, %bb.kids ]
  %mb = phi i64 [ %mb0, %ep8.p.ok ], [ %mb, %bb.leaf ], [ %kmb, %bb.kids ]
  %empty$2Ek = bitcast i64 0 to i64
  %empty = icmp eq i64 %sp, %empty$2Ek
  br i1 %empty, label %bb.done, label %bb.pop
bb.pop:
  %sp1$2Ek = bitcast i64 -1 to i64
  %sp1 = add i64 %sp, %sp1$2Ek
  %at$2Em$2Ek = bitcast i64 8 to i64
  %at$2Em = mul i64 %sp1, %at$2Em$2Ek
  %at = add i64 %stk, %at$2Em
  %o$2Eptr = inttoptr i64 %at to ptr
  %o$2Eoff = bitcast i64 0 to i64
  %o.p.gep = getelementptr inbounds i8, ptr %o$2Eptr, i64 %o$2Eoff
  %o = load i64, ptr %o.p.gep
  %h$2Eptr = inttoptr i64 %o to ptr
  %h$2Eoff = bitcast i64 0 to i64
  %h.p.gep = getelementptr inbounds i8, ptr %h$2Eptr, i64 %h$2Eoff
  %h = load i64, ptr %h.p.gep
  %type$2Es$2Ek = bitcast i64 32 to i64
  %type$2Es.p.m = and i64 %type$2Es$2Ek, 63
  %type$2Es = lshr i64 %h, %type$2Es.p.m
  %type$2Ek = bitcast i64 255 to i64
  %type = and i64 %type$2Es, %type$2Ek
  %z0 = bitcast i64 0 to i64
  br label %bb.t0
bb.cons:
  %cb$2Ek = bitcast i64 8 to i64
  %cb = add i64 %o, %cb$2Ek
  %cn = bitcast i64 2 to i64
  br label %bb.kids
bb.rec:
  %rn$2Eptr = inttoptr i64 %o to ptr
  %rn$2Eoff = bitcast i64 12 to i64
  %rn$2Ew.p.gep = getelementptr inbounds i8, ptr %rn$2Eptr, i64 %rn$2Eoff
  %rn$2Ew = load i32, ptr %rn$2Ew.p.gep
  %rn = sext i32 %rn$2Ew to i64
  %rb$2Ek = bitcast i64 24 to i64
  %rb = add i64 %o, %rb$2Ek
  br label %bb.kids
bb.ctor:
  %fn$2Eptr = inttoptr i64 %o to ptr
  %fn$2Eoff = bitcast i64 12 to i64
  %fn$2Ew.p.gep = getelementptr inbounds i8, ptr %fn$2Eptr, i64 %fn$2Eoff
  %fn$2Ew = load i32, ptr %fn$2Ew.p.gep
  %fn = sext i32 %fn$2Ew to i64
  %fb$2Ek = bitcast i64 16 to i64
  %fb = add i64 %o, %fb$2Ek
  br label %bb.kids
bb.clo:
  %un$2Eptr = inttoptr i64 %o to ptr
  %un$2Eoff = bitcast i64 16 to i64
  %un$2Ew.p.gep = getelementptr inbounds i8, ptr %un$2Eptr, i64 %un$2Eoff
  %un$2Ew = load i32, ptr %un$2Ew.p.gep
  %un = sext i32 %un$2Ew to i64
  %ub$2Ek = bitcast i64 24 to i64
  %ub = add i64 %o, %ub$2Ek
  br label %bb.kids
bb.leaf:
  br label %bb.loop
bb.kids:
  %base = phi i64 [ %cb, %bb.cons ], [ %rb, %bb.rec ], [ %fb, %bb.ctor ], [ %ub, %bb.clo ], [ %base, %bb.kid ], [ %base, %bb.ltest ], [ %base, %bb.ptest ], [ %base, %bb.push ], [ %base, %bb.put ]
  %n = phi i64 [ %cn, %bb.cons ], [ %rn, %bb.rec ], [ %fn, %bb.ctor ], [ %un, %bb.clo ], [ %n, %bb.kid ], [ %n, %bb.ltest ], [ %n, %bb.ptest ], [ %n, %bb.push ], [ %n, %bb.put ]
  %i = phi i64 [ %z0, %bb.cons ], [ %z0, %bb.rec ], [ %z0, %bb.ctor ], [ %z0, %bb.clo ], [ %i1, %bb.kid ], [ %i1, %bb.ltest ], [ %i1, %bb.ptest ], [ %i1, %bb.push ], [ %i1, %bb.put ]
  %ksp = phi i64 [ %sp1, %bb.cons ], [ %sp1, %bb.rec ], [ %sp1, %bb.ctor ], [ %sp1, %bb.clo ], [ %ksp, %bb.kid ], [ %ksp, %bb.ltest ], [ %ksp, %bb.ptest ], [ %ksp, %bb.push ], [ %ksp1, %bb.put ]
  %kstk = phi i64 [ %stk, %bb.cons ], [ %stk, %bb.rec ], [ %stk, %bb.ctor ], [ %stk, %bb.clo ], [ %kstk, %bb.kid ], [ %kstk, %bb.ltest ], [ %kstk, %bb.ptest ], [ %kstk, %bb.push ], [ %pstk, %bb.put ]
  %kcap = phi i64 [ %cap, %bb.cons ], [ %cap, %bb.rec ], [ %cap, %bb.ctor ], [ %cap, %bb.clo ], [ %kcap, %bb.kid ], [ %kcap, %bb.ltest ], [ %kcap, %bb.ptest ], [ %kcap, %bb.push ], [ %pcap, %bb.put ]
  %kmb = phi i64 [ %mb, %bb.cons ], [ %mb, %bb.rec ], [ %mb, %bb.ctor ], [ %mb, %bb.clo ], [ %kmb, %bb.kid ], [ %kmb, %bb.ltest ], [ %kmb, %bb.ptest ], [ %pmb, %bb.push ], [ %pmb, %bb.put ]
  %more = icmp slt i64 %i, %n
  br i1 %more, label %bb.kid, label %bb.loop
bb.kid:
  %a$2Em$2Ek = bitcast i64 16 to i64
  %a$2Em = mul i64 %i, %a$2Em$2Ek
  %a = add i64 %base, %a$2Em
  %tag$2Es$2Eptr = inttoptr i64 %a to ptr
  %tag$2Es$2Eoff = bitcast i64 0 to i64
  %tag$2Es$2Ew.p.gep = getelementptr inbounds i8, ptr %tag$2Es$2Eptr, i64 %tag$2Es$2Eoff
  %tag$2Es$2Ew = load i32, ptr %tag$2Es$2Ew.p.gep
  %tag$2Es = sext i32 %tag$2Es$2Ew to i64
  %tag$2Ek = bitcast i64 4294967295 to i64
  %tag = and i64 %tag$2Es, %tag$2Ek
  %obj$2Eptr = inttoptr i64 %a to ptr
  %obj$2Eoff = bitcast i64 8 to i64
  %obj.p.gep = getelementptr inbounds i8, ptr %obj$2Eptr, i64 %obj$2Eoff
  %obj = load i64, ptr %obj.p.gep
  %i1$2Ek = bitcast i64 1 to i64
  %i1 = add i64 %i, %i1$2Ek
  %has$2Elo$2Ek = bitcast i64 5 to i64
  %has$2Elo = icmp sge i64 %tag, %has$2Elo$2Ek
  %has$2Ehi$2Ek = bitcast i64 15 to i64
  %has$2Ehi = icmp sle i64 %tag, %has$2Ehi$2Ek
  %has$2Ene$2Ek = bitcast i64 10 to i64
  %has$2Ene = icmp ne i64 %tag, %has$2Ene$2Ek
  %has$2Enz$2Ek = bitcast i64 0 to i64
  %has$2Enz = icmp ne i64 %obj, %has$2Enz$2Ek
  %has$2Ea = and i1 %has$2Elo, %has$2Ehi
  %has$2Eb = and i1 %has$2Ene, %has$2Enz
  %has = and i1 %has$2Ea, %has$2Eb
  br i1 %has, label %bb.test, label %bb.kids
bb.test:
  %oh$2Eptr = inttoptr i64 %obj to ptr
  %oh$2Eoff = bitcast i64 0 to i64
  %oh.p.gep = getelementptr inbounds i8, ptr %oh$2Eptr, i64 %oh$2Eoff
  %oh = load i64, ptr %oh.p.gep
  %cls$2Ek = bitcast i64 56 to i64
  %cls.p.m = and i64 %cls$2Ek, 63
  %cls = lshr i64 %oh, %cls.p.m
  %pooled$2Ek = bitcast i64 255 to i64
  %pooled = icmp ne i64 %cls, %pooled$2Ek
  br i1 %pooled, label %bb.ptest, label %bb.ltest
bb.ltest:
  %skip$2Emark$2Es$2Ek = bitcast i64 40 to i64
  %skip$2Emark$2Es.p.m = and i64 %skip$2Emark$2Es$2Ek, 63
  %skip$2Emark$2Es = lshr i64 %oh, %skip$2Emark$2Es.p.m
  %skip$2Emark$2Ek = bitcast i64 255 to i64
  %skip$2Emark = and i64 %skip$2Emark$2Es, %skip$2Emark$2Ek
  %skip$2Eperm$2Es$2Ek = bitcast i64 48 to i64
  %skip$2Eperm$2Es.p.m = and i64 %skip$2Eperm$2Es$2Ek, 63
  %skip$2Eperm$2Es = lshr i64 %oh, %skip$2Eperm$2Es.p.m
  %skip$2Eperm$2Ek = bitcast i64 255 to i64
  %skip$2Eperm = and i64 %skip$2Eperm$2Es, %skip$2Eperm$2Ek
  %skip$2Ety$2Es$2Ek = bitcast i64 32 to i64
  %skip$2Ety$2Es.p.m = and i64 %skip$2Ety$2Es$2Ek, 63
  %skip$2Ety$2Es = lshr i64 %oh, %skip$2Ety$2Es.p.m
  %skip$2Ety$2Ek = bitcast i64 255 to i64
  %skip$2Ety = and i64 %skip$2Ety$2Es, %skip$2Ety$2Ek
  %skip$2Emarked$2Ek = bitcast i64 0 to i64
  %skip$2Emarked = icmp ne i64 %skip$2Emark, %skip$2Emarked$2Ek
  %skip$2Eheld$2Ek = bitcast i64 0 to i64
  %skip$2Eheld = icmp ne i64 %skip$2Eperm, %skip$2Eheld$2Ek
  %skip$2Ehandle$2Ek = bitcast i64 7 to i64
  %skip$2Ehandle = icmp eq i64 %skip$2Ety, %skip$2Ehandle$2Ek
  %skip$2Eown = xor i1 %skip$2Ehandle, true
  %skip$2Ekept = and i1 %skip$2Eheld, %skip$2Eown
  %skip = or i1 %skip$2Emarked, %skip$2Ekept
  br i1 %skip, label %bb.kids, label %bb.lset
bb.lset:
  %m$2Eptr = inttoptr i64 %obj to ptr
  %m$2Eoff = bitcast i64 5 to i64
  %m$2Ev = bitcast i32 1 to i32
  %m.p.gep = getelementptr inbounds i8, ptr %m$2Eptr, i64 %m$2Eoff
  %m.p.trunc = trunc i32 %m$2Ev to i8
  store i8 %m.p.trunc, ptr %m.p.gep
  %m = bitcast i1 true to i1
  br label %bb.push
bb.ptest:
  %pm$2Es$2Ek = bitcast i64 40 to i64
  %pm$2Es.p.m = and i64 %pm$2Es$2Ek, 63
  %pm$2Es = lshr i64 %oh, %pm$2Es.p.m
  %pm$2Ek = bitcast i64 255 to i64
  %pm = and i64 %pm$2Es, %pm$2Ek
  %seen = icmp eq i64 %pm, %ep
  br i1 %seen, label %bb.kids, label %bb.page
bb.page:
  %em$2Eptr = inttoptr i64 %obj to ptr
  %em$2Eoff = bitcast i64 5 to i64
  %em.p.gep = getelementptr inbounds i8, ptr %em$2Eptr, i64 %em$2Eoff
  %em.p.trunc = trunc i32 %ep8 to i8
  store i8 %em.p.trunc, ptr %em.p.gep
  %em = bitcast i1 true to i1
  %mb$2Epg$2Ek = bitcast i64 -16384 to i64
  %mb$2Epg = and i64 %obj, %mb$2Epg$2Ek
  %mb$2Er0 = sub i64 %obj, %mb$2Epg
  %mb$2Erel$2Ek = bitcast i64 -512 to i64
  %mb$2Erel = add i64 %mb$2Er0, %mb$2Erel$2Ek
  %mb$2Erc$2Eptr = inttoptr i64 %mb$2Epg to ptr
  %mb$2Erc$2Eoff = bitcast i64 16 to i64
  %mb$2Erc.p.gep = getelementptr inbounds i8, ptr %mb$2Erc$2Eptr, i64 %mb$2Erc$2Eoff
  %mb$2Erc = load i64, ptr %mb$2Erc.p.gep
  %mb$2Epr = mul i64 %mb$2Erel, %mb$2Erc
  %mb$2Eidx$2Ek = bitcast i64 32 to i64
  %mb$2Eidx.p.m = and i64 %mb$2Eidx$2Ek, 63
  %mb$2Eidx = lshr i64 %mb$2Epr, %mb$2Eidx.p.m
  %mb$2Ewi$2Ek = bitcast i64 6 to i64
  %mb$2Ewi.p.m = and i64 %mb$2Ewi$2Ek, 63
  %mb$2Ewi = lshr i64 %mb$2Eidx, %mb$2Ewi.p.m
  %mb$2Ewo$2Ek = bitcast i64 3 to i64
  %mb$2Ewo.p.m = and i64 %mb$2Ewo$2Ek, 63
  %mb$2Ewo = shl i64 %mb$2Ewi, %mb$2Ewo.p.m
  %mb$2Ewb = add i64 %mb$2Epg, %mb$2Ewo
  %mb$2Ewa$2Ek = bitcast i64 200 to i64
  %mb$2Ewa = add i64 %mb$2Ewb, %mb$2Ewa$2Ek
  %mb$2Ew$2Eptr = inttoptr i64 %mb$2Ewa to ptr
  %mb$2Ew$2Eoff = bitcast i64 0 to i64
  %mb$2Ew.p.gep = getelementptr inbounds i8, ptr %mb$2Ew$2Eptr, i64 %mb$2Ew$2Eoff
  %mb$2Ew = load i64, ptr %mb$2Ew.p.gep
  %mb$2Ebn$2Ek = bitcast i64 63 to i64
  %mb$2Ebn = and i64 %mb$2Eidx, %mb$2Ebn$2Ek
  %mb$2Eone = bitcast i64 1 to i64
  %mb$2Ebit.p.m = and i64 %mb$2Ebn, 63
  %mb$2Ebit = shl i64 %mb$2Eone, %mb$2Ebit.p.m
  %ms$2Ew1 = or i64 %mb$2Ew, %mb$2Ebit
  %ms$2Esw$2Eptr = inttoptr i64 %mb$2Ewa to ptr
  %ms$2Esw$2Eoff = bitcast i64 0 to i64
  %ms$2Esw.p.gep = getelementptr inbounds i8, ptr %ms$2Esw$2Eptr, i64 %ms$2Esw$2Eoff
  store i64 %ms$2Ew1, ptr %ms$2Esw.p.gep
  %ms$2Esw = bitcast i1 true to i1
  %sz$2Ek = bitcast i64 4294967295 to i64
  %sz = and i64 %oh, %sz$2Ek
  %kmb1 = add i64 %kmb, %sz
  br label %bb.push
bb.push:
  %pmb = phi i64 [ %kmb, %bb.lset ], [ %kmb1, %bb.page ]
  %ct$2Ek = bitcast i64 32 to i64
  %ct.p.m = and i64 %ct$2Ek, 63
  %ct = lshr i64 %oh, %ct.p.m
  %ct1$2Ek = bitcast i64 -1 to i64
  %ct1 = add i64 %ct, %ct1$2Ek
  %ct2$2Ek = bitcast i64 255 to i64
  %ct2 = and i64 %ct1, %ct2$2Ek
  %inner$2Ek = bitcast i64 4 to i64
  %inner = icmp slt i64 %ct2, %inner$2Ek
  br i1 %inner, label %bb.room, label %bb.kids
bb.room:
  %full = icmp eq i64 %ksp, %kcap
  br i1 %full, label %bb.grow, label %bb.put
bb.grow:
  %gw$2Eptr = inttoptr i64 %s to ptr
  %gw$2Eoff = bitcast i64 168 to i64
  %gw.p.gep = getelementptr inbounds i8, ptr %gw$2Eptr, i64 %gw$2Eoff
  store i64 %ksp, ptr %gw.p.gep
  %gw = bitcast i1 true to i1
  %nstk = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EgrowMark(i64 %kcap)
  %ncap$2Eptr = inttoptr i64 %s to ptr
  %ncap$2Eoff = bitcast i64 176 to i64
  %ncap.p.gep = getelementptr inbounds i8, ptr %ncap$2Eptr, i64 %ncap$2Eoff
  %ncap = load i64, ptr %ncap.p.gep
  br label %bb.put
bb.put:
  %pstk = phi i64 [ %kstk, %bb.room ], [ %nstk, %bb.grow ]
  %pcap = phi i64 [ %kcap, %bb.room ], [ %ncap, %bb.grow ]
  %pat$2Em$2Ek = bitcast i64 8 to i64
  %pat$2Em = mul i64 %ksp, %pat$2Em$2Ek
  %pat = add i64 %pstk, %pat$2Em
  %pw$2Eptr = inttoptr i64 %pat to ptr
  %pw$2Eoff = bitcast i64 0 to i64
  %pw.p.gep = getelementptr inbounds i8, ptr %pw$2Eptr, i64 %pw$2Eoff
  store i64 %obj, ptr %pw.p.gep
  %pw = bitcast i1 true to i1
  %ksp1$2Ek = bitcast i64 1 to i64
  %ksp1 = add i64 %ksp, %ksp1$2Ek
  br label %bb.kids
bb.done:
  %dw$2Eptr = inttoptr i64 %s to ptr
  %dw$2Eoff = bitcast i64 168 to i64
  %dw.p.gep = getelementptr inbounds i8, ptr %dw$2Eptr, i64 %dw$2Eoff
  store i64 %sp, ptr %dw.p.gep
  %dw = bitcast i1 true to i1
  %dmb$2Eptr = inttoptr i64 %s to ptr
  %dmb$2Eoff = bitcast i64 448 to i64
  %dmb.p.gep = getelementptr inbounds i8, ptr %dmb$2Eptr, i64 %dmb$2Eoff
  store i64 %mb, ptr %dmb.p.gep
  %dmb = bitcast i1 true to i1
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
bb.t0:
  %t0$2Eeq$2Ek = bitcast i64 1 to i64
  %t0$2Eeq = icmp eq i64 %type, %t0$2Eeq$2Ek
  br i1 %t0$2Eeq, label %bb.cons, label %bb.t1
bb.t1:
  %t1$2Eeq$2Ek = bitcast i64 2 to i64
  %t1$2Eeq = icmp eq i64 %type, %t1$2Eeq$2Ek
  br i1 %t1$2Eeq, label %bb.rec, label %bb.t2
bb.t2:
  %t2$2Eeq$2Ek = bitcast i64 3 to i64
  %t2$2Eeq = icmp eq i64 %type, %t2$2Eeq$2Ek
  br i1 %t2$2Eeq, label %bb.ctor, label %bb.t3
bb.t3:
  %t3$2Eeq$2Ek = bitcast i64 4 to i64
  %t3$2Eeq = icmp eq i64 %type, %t3$2Eeq$2Ek
  br i1 %t3$2Eeq, label %bb.clo, label %bb.leaf
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmarkRoot(i64 %w0, i64 %w1) {
bb.entry:
  %tag$2Ek = bitcast i64 4294967295 to i64
  %tag = and i64 %w0, %tag$2Ek
  %m = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmarkVal(i64 %tag, i64 %w1)
  %d = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Edrain()
  %entry$2Ez = bitcast i64 0 to i64
  ret i64 %entry$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmarkPhase() {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %c1$2Ev = bitcast i64 1 to i64
  %c1$2Eptr = inttoptr i64 %s to ptr
  %c1$2Eoff = bitcast i64 304 to i64
  %c1.p.gep = getelementptr inbounds i8, ptr %c1$2Eptr, i64 %c1$2Eoff
  store i64 %c1$2Ev, ptr %c1.p.gep
  %c1 = bitcast i1 true to i1
  %mr = call tailcc i64 @gcAslMutatorRoots()
  %er = call tailcc i64 @gcAslExternalRoots()
  %base = call tailcc i64 @gcAslStackBase()
  %topp = call tailcc i64 @gcAslStackTop()
  %bz$2Ek = bitcast i64 0 to i64
  %bz = icmp eq i64 %base, %bz$2Ek
  %tz$2Ek = bitcast i64 0 to i64
  %tz = icmp eq i64 %topp, %tz$2Ek
  %skip = or i1 %bz, %tz
  br i1 %skip, label %bb.roots, label %bb.sloop
bb.sloop:
  %p = phi i64 [ %base, %bb.entry ], [ %p1, %bb.sbody ]
  %top$2Eptr = inttoptr i64 %topp to ptr
  %top$2Eoff = bitcast i64 0 to i64
  %top.p.gep = getelementptr inbounds i8, ptr %top$2Eptr, i64 %top$2Eoff
  %top = load i64, ptr %top.p.gep
  %more$2Ea$2Eone = bitcast i64 1 to i64
  %more$2Ea$2Esh = bitcast i64 63 to i64
  %more$2Ea$2Emin.p.m = and i64 %more$2Ea$2Esh, 63
  %more$2Ea$2Emin = shl i64 %more$2Ea$2Eone, %more$2Ea$2Emin.p.m
  %more$2Ea = xor i64 %p, %more$2Ea$2Emin
  %more$2Eb$2Eone = bitcast i64 1 to i64
  %more$2Eb$2Esh = bitcast i64 63 to i64
  %more$2Eb$2Emin.p.m = and i64 %more$2Eb$2Esh, 63
  %more$2Eb$2Emin = shl i64 %more$2Eb$2Eone, %more$2Eb$2Emin.p.m
  %more$2Eb = xor i64 %top, %more$2Eb$2Emin
  %more = icmp slt i64 %more$2Ea, %more$2Eb
  br i1 %more, label %bb.sbody, label %bb.roots
bb.sbody:
  %sv$2Et$2Es$2Eptr = inttoptr i64 %p to ptr
  %sv$2Et$2Es$2Eoff = bitcast i64 0 to i64
  %sv$2Et$2Es$2Ew.p.gep = getelementptr inbounds i8, ptr %sv$2Et$2Es$2Eptr, i64 %sv$2Et$2Es$2Eoff
  %sv$2Et$2Es$2Ew = load i32, ptr %sv$2Et$2Es$2Ew.p.gep
  %sv$2Et$2Es = sext i32 %sv$2Et$2Es$2Ew to i64
  %sv$2Et$2Ek = bitcast i64 4294967295 to i64
  %sv$2Et = and i64 %sv$2Et$2Es, %sv$2Et$2Ek
  %sv$2Eo$2Eptr = inttoptr i64 %p to ptr
  %sv$2Eo$2Eoff = bitcast i64 8 to i64
  %sv$2Eo.p.gep = getelementptr inbounds i8, ptr %sv$2Eo$2Eptr, i64 %sv$2Eo$2Eoff
  %sv$2Eo = load i64, ptr %sv$2Eo.p.gep
  %sv$2Em = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmarkVal(i64 %sv$2Et, i64 %sv$2Eo)
  %sv$2Ed = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Edrain()
  %p1$2Ek = bitcast i64 16 to i64
  %p1 = add i64 %p, %p1$2Ek
  br label %bb.sloop
bb.roots:
  %r0 = bitcast i64 0 to i64
  br label %bb.rloop
bb.rloop:
  %ri = phi i64 [ %r0, %bb.roots ], [ %ri1, %bb.rbody ]
  %rn$2Eptr = inttoptr i64 %s to ptr
  %rn$2Eoff = bitcast i64 128 to i64
  %rn.p.gep = getelementptr inbounds i8, ptr %rn$2Eptr, i64 %rn$2Eoff
  %rn = load i64, ptr %rn.p.gep
  %rmore = icmp slt i64 %ri, %rn
  br i1 %rmore, label %bb.rbody, label %bb.protos
bb.rbody:
  %rbase$2Ek = bitcast i64 2048 to i64
  %rbase = add i64 %s, %rbase$2Ek
  %rat$2Em$2Ek = bitcast i64 8 to i64
  %rat$2Em = mul i64 %ri, %rat$2Em$2Ek
  %rat = add i64 %rbase, %rat$2Em
  %rv$2Eptr = inttoptr i64 %rat to ptr
  %rv$2Eoff = bitcast i64 0 to i64
  %rv.p.gep = getelementptr inbounds i8, ptr %rv$2Eptr, i64 %rv$2Eoff
  %rv = load i64, ptr %rv.p.gep
  %rm$2Et$2Es$2Eptr = inttoptr i64 %rv to ptr
  %rm$2Et$2Es$2Eoff = bitcast i64 0 to i64
  %rm$2Et$2Es$2Ew.p.gep = getelementptr inbounds i8, ptr %rm$2Et$2Es$2Eptr, i64 %rm$2Et$2Es$2Eoff
  %rm$2Et$2Es$2Ew = load i32, ptr %rm$2Et$2Es$2Ew.p.gep
  %rm$2Et$2Es = sext i32 %rm$2Et$2Es$2Ew to i64
  %rm$2Et$2Ek = bitcast i64 4294967295 to i64
  %rm$2Et = and i64 %rm$2Et$2Es, %rm$2Et$2Ek
  %rm$2Eo$2Eptr = inttoptr i64 %rv to ptr
  %rm$2Eo$2Eoff = bitcast i64 8 to i64
  %rm$2Eo.p.gep = getelementptr inbounds i8, ptr %rm$2Eo$2Eptr, i64 %rm$2Eo$2Eoff
  %rm$2Eo = load i64, ptr %rm$2Eo.p.gep
  %rm$2Em = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmarkVal(i64 %rm$2Et, i64 %rm$2Eo)
  %rm$2Ed = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Edrain()
  %ri1$2Ek = bitcast i64 1 to i64
  %ri1 = add i64 %ri, %ri1$2Ek
  br label %bb.rloop
bb.protos:
  %p0 = bitcast i64 0 to i64
  br label %bb.ploop
bb.ploop:
  %pi = phi i64 [ %p0, %bb.protos ], [ %pi1, %bb.pnext ]
  %pn$2Eptr = inttoptr i64 %s to ptr
  %pn$2Eoff = bitcast i64 144 to i64
  %pn.p.gep = getelementptr inbounds i8, ptr %pn$2Eptr, i64 %pn$2Eoff
  %pn = load i64, ptr %pn.p.gep
  %pmore = icmp slt i64 %pi, %pn
  br i1 %pmore, label %bb.pbody, label %bb.done
bb.pbody:
  %parr$2Eptr = inttoptr i64 %s to ptr
  %parr$2Eoff = bitcast i64 136 to i64
  %parr.p.gep = getelementptr inbounds i8, ptr %parr$2Eptr, i64 %parr$2Eoff
  %parr = load i64, ptr %parr.p.gep
  %pat$2Em$2Ek = bitcast i64 8 to i64
  %pat$2Em = mul i64 %pi, %pat$2Em$2Ek
  %pat = add i64 %parr, %pat$2Em
  %proto$2Eptr = inttoptr i64 %pat to ptr
  %proto$2Eoff = bitcast i64 0 to i64
  %proto.p.gep = getelementptr inbounds i8, ptr %proto$2Eptr, i64 %proto$2Eoff
  %proto = load i64, ptr %proto.p.gep
  %nk$2Eptr = inttoptr i64 %proto to ptr
  %nk$2Eoff = bitcast i64 48 to i64
  %nk$2Ew.p.gep = getelementptr inbounds i8, ptr %nk$2Eptr, i64 %nk$2Eoff
  %nk$2Ew = load i32, ptr %nk$2Ew.p.gep
  %nk = sext i32 %nk$2Ew to i64
  %consts$2Eptr = inttoptr i64 %proto to ptr
  %consts$2Eoff = bitcast i64 40 to i64
  %consts.p.gep = getelementptr inbounds i8, ptr %consts$2Eptr, i64 %consts$2Eoff
  %consts = load i64, ptr %consts.p.gep
  %k0 = bitcast i64 0 to i64
  br label %bb.kloop
bb.kloop:
  %ki = phi i64 [ %k0, %bb.pbody ], [ %ki1, %bb.kbody ]
  %kmore = icmp slt i64 %ki, %nk
  br i1 %kmore, label %bb.kbody, label %bb.pnext
bb.kbody:
  %kat$2Em$2Ek = bitcast i64 16 to i64
  %kat$2Em = mul i64 %ki, %kat$2Em$2Ek
  %kat = add i64 %consts, %kat$2Em
  %km$2Et$2Es$2Eptr = inttoptr i64 %kat to ptr
  %km$2Et$2Es$2Eoff = bitcast i64 0 to i64
  %km$2Et$2Es$2Ew.p.gep = getelementptr inbounds i8, ptr %km$2Et$2Es$2Eptr, i64 %km$2Et$2Es$2Eoff
  %km$2Et$2Es$2Ew = load i32, ptr %km$2Et$2Es$2Ew.p.gep
  %km$2Et$2Es = sext i32 %km$2Et$2Es$2Ew to i64
  %km$2Et$2Ek = bitcast i64 4294967295 to i64
  %km$2Et = and i64 %km$2Et$2Es, %km$2Et$2Ek
  %km$2Eo$2Eptr = inttoptr i64 %kat to ptr
  %km$2Eo$2Eoff = bitcast i64 8 to i64
  %km$2Eo.p.gep = getelementptr inbounds i8, ptr %km$2Eo$2Eptr, i64 %km$2Eo$2Eoff
  %km$2Eo = load i64, ptr %km$2Eo.p.gep
  %km$2Em = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmarkVal(i64 %km$2Et, i64 %km$2Eo)
  %km$2Ed = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Edrain()
  %ki1$2Ek = bitcast i64 1 to i64
  %ki1 = add i64 %ki, %ki1$2Ek
  br label %bb.kloop
bb.pnext:
  %pi1$2Ek = bitcast i64 1 to i64
  %pi1 = add i64 %pi, %pi1$2Ek
  br label %bb.ploop
bb.done:
  %c0$2Ev = bitcast i64 0 to i64
  %c0$2Eptr = inttoptr i64 %s to ptr
  %c0$2Eoff = bitcast i64 304 to i64
  %c0.p.gep = getelementptr inbounds i8, ptr %c0$2Eptr, i64 %c0$2Eoff
  store i64 %c0$2Ev, ptr %c0.p.gep
  %c0 = bitcast i1 true to i1
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpoolScan(i64 %mode) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %clear$2Ek = bitcast i64 1 to i64
  %clear = icmp eq i64 %mode, %clear$2Ek
  %sc0 = bitcast i64 0 to i64
  br label %bb.cloop
bb.cloop:
  %sc = phi i64 [ %sc0, %bb.entry ], [ %sc1, %bb.cnext ]
  %cmore$2Ek = bitcast i64 63 to i64
  %cmore = icmp slt i64 %sc, %cmore$2Ek
  br i1 %cmore, label %bb.cbody, label %bb.done
bb.cbody:
  %ca$2Em$2Ek = bitcast i64 24 to i64
  %ca$2Em = mul i64 %sc, %ca$2Em$2Ek
  %ca$2Ea = add i64 %s, %ca$2Em
  %ca$2Ek = bitcast i64 512 to i64
  %ca = add i64 %ca$2Ea, %ca$2Ek
  %p0$2Eptr = inttoptr i64 %ca to ptr
  %p0$2Eoff = bitcast i64 0 to i64
  %p0.p.gep = getelementptr inbounds i8, ptr %p0$2Eptr, i64 %p0$2Eoff
  %p0 = load i64, ptr %p0.p.gep
  br label %bb.ploop
bb.ploop:
  %p = phi i64 [ %p0, %bb.cbody ], [ %nx, %bb.pnext ]
  %pz$2Ek = bitcast i64 0 to i64
  %pz = icmp eq i64 %p, %pz$2Ek
  br i1 %pz, label %bb.cnext, label %bb.pbody
bb.pbody:
  br i1 %clear, label %bb.preset, label %bb.pwords
bb.preset:
  %mw0$2Ev = bitcast i64 0 to i64
  %mw0$2Eptr = inttoptr i64 %p to ptr
  %mw0$2Eoff = bitcast i64 200 to i64
  %mw0.p.gep = getelementptr inbounds i8, ptr %mw0$2Eptr, i64 %mw0$2Eoff
  store i64 %mw0$2Ev, ptr %mw0.p.gep
  %mw0 = bitcast i1 true to i1
  %mw1$2Ev = bitcast i64 0 to i64
  %mw1$2Eptr = inttoptr i64 %p to ptr
  %mw1$2Eoff = bitcast i64 208 to i64
  %mw1.p.gep = getelementptr inbounds i8, ptr %mw1$2Eptr, i64 %mw1$2Eoff
  store i64 %mw1$2Ev, ptr %mw1.p.gep
  %mw1 = bitcast i1 true to i1
  %mw2$2Ev = bitcast i64 0 to i64
  %mw2$2Eptr = inttoptr i64 %p to ptr
  %mw2$2Eoff = bitcast i64 216 to i64
  %mw2.p.gep = getelementptr inbounds i8, ptr %mw2$2Eptr, i64 %mw2$2Eoff
  store i64 %mw2$2Ev, ptr %mw2.p.gep
  %mw2 = bitcast i1 true to i1
  %mw3$2Ev = bitcast i64 0 to i64
  %mw3$2Eptr = inttoptr i64 %p to ptr
  %mw3$2Eoff = bitcast i64 224 to i64
  %mw3.p.gep = getelementptr inbounds i8, ptr %mw3$2Eptr, i64 %mw3$2Eoff
  store i64 %mw3$2Ev, ptr %mw3.p.gep
  %mw3 = bitcast i1 true to i1
  %mw4$2Ev = bitcast i64 0 to i64
  %mw4$2Eptr = inttoptr i64 %p to ptr
  %mw4$2Eoff = bitcast i64 232 to i64
  %mw4.p.gep = getelementptr inbounds i8, ptr %mw4$2Eptr, i64 %mw4$2Eoff
  store i64 %mw4$2Ev, ptr %mw4.p.gep
  %mw4 = bitcast i1 true to i1
  %mw5$2Ev = bitcast i64 0 to i64
  %mw5$2Eptr = inttoptr i64 %p to ptr
  %mw5$2Eoff = bitcast i64 240 to i64
  %mw5.p.gep = getelementptr inbounds i8, ptr %mw5$2Eptr, i64 %mw5$2Eoff
  store i64 %mw5$2Ev, ptr %mw5.p.gep
  %mw5 = bitcast i1 true to i1
  %mw6$2Ev = bitcast i64 0 to i64
  %mw6$2Eptr = inttoptr i64 %p to ptr
  %mw6$2Eoff = bitcast i64 248 to i64
  %mw6.p.gep = getelementptr inbounds i8, ptr %mw6$2Eptr, i64 %mw6$2Eoff
  store i64 %mw6$2Ev, ptr %mw6.p.gep
  %mw6 = bitcast i1 true to i1
  %mw7$2Ev = bitcast i64 0 to i64
  %mw7$2Eptr = inttoptr i64 %p to ptr
  %mw7$2Eoff = bitcast i64 256 to i64
  %mw7.p.gep = getelementptr inbounds i8, ptr %mw7$2Eptr, i64 %mw7$2Eoff
  store i64 %mw7$2Ev, ptr %mw7.p.gep
  %mw7 = bitcast i1 true to i1
  %mw8$2Ev = bitcast i64 0 to i64
  %mw8$2Eptr = inttoptr i64 %p to ptr
  %mw8$2Eoff = bitcast i64 264 to i64
  %mw8.p.gep = getelementptr inbounds i8, ptr %mw8$2Eptr, i64 %mw8$2Eoff
  store i64 %mw8$2Ev, ptr %mw8.p.gep
  %mw8 = bitcast i1 true to i1
  %mw9$2Ev = bitcast i64 0 to i64
  %mw9$2Eptr = inttoptr i64 %p to ptr
  %mw9$2Eoff = bitcast i64 272 to i64
  %mw9.p.gep = getelementptr inbounds i8, ptr %mw9$2Eptr, i64 %mw9$2Eoff
  store i64 %mw9$2Ev, ptr %mw9.p.gep
  %mw9 = bitcast i1 true to i1
  %mw10$2Ev = bitcast i64 0 to i64
  %mw10$2Eptr = inttoptr i64 %p to ptr
  %mw10$2Eoff = bitcast i64 280 to i64
  %mw10.p.gep = getelementptr inbounds i8, ptr %mw10$2Eptr, i64 %mw10$2Eoff
  store i64 %mw10$2Ev, ptr %mw10.p.gep
  %mw10 = bitcast i1 true to i1
  %mw11$2Ev = bitcast i64 0 to i64
  %mw11$2Eptr = inttoptr i64 %p to ptr
  %mw11$2Eoff = bitcast i64 288 to i64
  %mw11.p.gep = getelementptr inbounds i8, ptr %mw11$2Eptr, i64 %mw11$2Eoff
  store i64 %mw11$2Ev, ptr %mw11.p.gep
  %mw11 = bitcast i1 true to i1
  %mw12$2Ev = bitcast i64 0 to i64
  %mw12$2Eptr = inttoptr i64 %p to ptr
  %mw12$2Eoff = bitcast i64 296 to i64
  %mw12.p.gep = getelementptr inbounds i8, ptr %mw12$2Eptr, i64 %mw12$2Eoff
  store i64 %mw12$2Ev, ptr %mw12.p.gep
  %mw12 = bitcast i1 true to i1
  %mw13$2Ev = bitcast i64 0 to i64
  %mw13$2Eptr = inttoptr i64 %p to ptr
  %mw13$2Eoff = bitcast i64 304 to i64
  %mw13.p.gep = getelementptr inbounds i8, ptr %mw13$2Eptr, i64 %mw13$2Eoff
  store i64 %mw13$2Ev, ptr %mw13.p.gep
  %mw13 = bitcast i1 true to i1
  %mw14$2Ev = bitcast i64 0 to i64
  %mw14$2Eptr = inttoptr i64 %p to ptr
  %mw14$2Eoff = bitcast i64 312 to i64
  %mw14.p.gep = getelementptr inbounds i8, ptr %mw14$2Eptr, i64 %mw14$2Eoff
  store i64 %mw14$2Ev, ptr %mw14.p.gep
  %mw14 = bitcast i1 true to i1
  %mw15$2Ev = bitcast i64 0 to i64
  %mw15$2Eptr = inttoptr i64 %p to ptr
  %mw15$2Eoff = bitcast i64 320 to i64
  %mw15.p.gep = getelementptr inbounds i8, ptr %mw15$2Eptr, i64 %mw15$2Eoff
  store i64 %mw15$2Ev, ptr %mw15.p.gep
  %mw15 = bitcast i1 true to i1
  br label %bb.pwords
bb.pwords:
  %cnt$2Eptr = inttoptr i64 %p to ptr
  %cnt$2Eoff = bitcast i64 32 to i64
  %cnt.p.gep = getelementptr inbounds i8, ptr %cnt$2Eptr, i64 %cnt$2Eoff
  %cnt = load i64, ptr %cnt.p.gep
  %cnt63$2Ek = bitcast i64 63 to i64
  %cnt63 = add i64 %cnt, %cnt63$2Ek
  %nw$2Ek = bitcast i64 6 to i64
  %nw.p.m = and i64 %nw$2Ek, 63
  %nw = lshr i64 %cnt63, %nw.p.m
  %kk0 = bitcast i64 0 to i64
  br label %bb.wloop
bb.wloop:
  %kk = phi i64 [ %kk0, %bb.pwords ], [ %kk1, %bb.wnext ]
  %wmore = icmp slt i64 %kk, %nw
  br i1 %wmore, label %bb.wbody, label %bb.pnext
bb.wbody:
  %wbase$2Ek = bitcast i64 72 to i64
  %wbase = add i64 %p, %wbase$2Ek
  %wat$2Em$2Ek = bitcast i64 8 to i64
  %wat$2Em = mul i64 %kk, %wat$2Em$2Ek
  %wat = add i64 %wbase, %wat$2Em
  %w0$2Eptr = inttoptr i64 %wat to ptr
  %w0$2Eoff = bitcast i64 0 to i64
  %w0.p.gep = getelementptr inbounds i8, ptr %w0$2Eptr, i64 %w0$2Eoff
  %w0 = load i64, ptr %w0.p.gep
  br label %bb.bloop
bb.bloop:
  %w = phi i64 [ %w0, %bb.wbody ], [ %w1, %bb.bstep ]
  %wz$2Ek = bitcast i64 0 to i64
  %wz = icmp eq i64 %w, %wz$2Ek
  br i1 %wz, label %bb.wnext, label %bb.bbody
bb.bbody:
  %t = call tailcc i64 @gcAslCtz(i64 %w)
  %kb$2Ek = bitcast i64 6 to i64
  %kb.p.m = and i64 %kb$2Ek, 63
  %kb = shl i64 %kk, %kb.p.m
  %idx = add i64 %kb, %t
  %ss$2Eptr = inttoptr i64 %p to ptr
  %ss$2Eoff = bitcast i64 24 to i64
  %ss.p.gep = getelementptr inbounds i8, ptr %ss$2Eptr, i64 %ss$2Eoff
  %ss = load i64, ptr %ss.p.gep
  %off = mul i64 %idx, %ss
  %first$2Ek = bitcast i64 512 to i64
  %first = add i64 %p, %first$2Ek
  %o = add i64 %first, %off
  br i1 %clear, label %bb.bclear, label %bb.bverify
bb.bclear:
  %m$2Eptr = inttoptr i64 %o to ptr
  %m$2Eoff = bitcast i64 5 to i64
  %m$2Ev = bitcast i32 0 to i32
  %m.p.gep = getelementptr inbounds i8, ptr %m$2Eptr, i64 %m$2Eoff
  %m.p.trunc = trunc i32 %m$2Ev to i8
  store i8 %m.p.trunc, ptr %m.p.gep
  %m = bitcast i1 true to i1
  br label %bb.bstep
bb.bverify:
  %v = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EverifyDfs(i64 %o)
  br label %bb.bstep
bb.bstep:
  %wm1$2Ek = bitcast i64 -1 to i64
  %wm1 = add i64 %w, %wm1$2Ek
  %w1 = and i64 %w, %wm1
  br label %bb.bloop
bb.wnext:
  %kk1$2Ek = bitcast i64 1 to i64
  %kk1 = add i64 %kk, %kk1$2Ek
  br label %bb.wloop
bb.pnext:
  %nx$2Eptr = inttoptr i64 %p to ptr
  %nx$2Eoff = bitcast i64 0 to i64
  %nx.p.gep = getelementptr inbounds i8, ptr %nx$2Eptr, i64 %nx$2Eoff
  %nx = load i64, ptr %nx.p.gep
  br label %bb.ploop
bb.cnext:
  %sc1$2Ek = bitcast i64 1 to i64
  %sc1 = add i64 %sc, %sc1$2Ek
  br label %bb.cloop
bb.done:
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EclearMarks() {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %l0$2Eptr = inttoptr i64 %s to ptr
  %l0$2Eoff = bitcast i64 224 to i64
  %l0.p.gep = getelementptr inbounds i8, ptr %l0$2Eptr, i64 %l0$2Eoff
  %l0 = load i64, ptr %l0.p.gep
  br label %bb.loop
bb.loop:
  %lo = phi i64 [ %l0, %bb.entry ], [ %nx, %bb.body ]
  %z$2Ek = bitcast i64 0 to i64
  %z = icmp eq i64 %lo, %z$2Ek
  br i1 %z, label %bb.pooled, label %bb.body
bb.body:
  %m$2Eptr = inttoptr i64 %lo to ptr
  %m$2Eoff = bitcast i64 29 to i64
  %m$2Ev = bitcast i32 0 to i32
  %m.p.gep = getelementptr inbounds i8, ptr %m$2Eptr, i64 %m$2Eoff
  %m.p.trunc = trunc i32 %m$2Ev to i8
  store i8 %m.p.trunc, ptr %m.p.gep
  %m = bitcast i1 true to i1
  %nx$2Eptr = inttoptr i64 %lo to ptr
  %nx$2Eoff = bitcast i64 0 to i64
  %nx.p.gep = getelementptr inbounds i8, ptr %nx$2Eptr, i64 %nx$2Eoff
  %nx = load i64, ptr %nx.p.gep
  br label %bb.loop
bb.pooled:
  %one = bitcast i64 1 to i64
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpoolScan(i64 %one)
  %pooled$2Ez = bitcast i64 0 to i64
  ret i64 %pooled$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EabortMark() {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %c$2Ev = bitcast i64 0 to i64
  %c$2Eptr = inttoptr i64 %s to ptr
  %c$2Eoff = bitcast i64 304 to i64
  %c.p.gep = getelementptr inbounds i8, ptr %c$2Eptr, i64 %c$2Eoff
  store i64 %c$2Ev, ptr %c.p.gep
  %c = bitcast i1 true to i1
  %sp$2Ev = bitcast i64 0 to i64
  %sp$2Eptr = inttoptr i64 %s to ptr
  %sp$2Eoff = bitcast i64 168 to i64
  %sp.p.gep = getelementptr inbounds i8, ptr %sp$2Eptr, i64 %sp$2Eoff
  store i64 %sp$2Ev, ptr %sp.p.gep
  %sp = bitcast i1 true to i1
  %mb$2Ev = bitcast i64 0 to i64
  %mb$2Eptr = inttoptr i64 %s to ptr
  %mb$2Eoff = bitcast i64 448 to i64
  %mb.p.gep = getelementptr inbounds i8, ptr %mb$2Eptr, i64 %mb$2Eoff
  store i64 %mb$2Ev, ptr %mb.p.gep
  %mb = bitcast i1 true to i1
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EclearMarks()
  %entry$2Ez = bitcast i64 0 to i64
  ret i64 %entry$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EnumChildren(i64 %o) {
bb.entry:
  %h$2Eptr = inttoptr i64 %o to ptr
  %h$2Eoff = bitcast i64 0 to i64
  %h.p.gep = getelementptr inbounds i8, ptr %h$2Eptr, i64 %h$2Eoff
  %h = load i64, ptr %h.p.gep
  %type$2Es$2Ek = bitcast i64 32 to i64
  %type$2Es.p.m = and i64 %type$2Es$2Ek, 63
  %type$2Es = lshr i64 %h, %type$2Es.p.m
  %type$2Ek = bitcast i64 255 to i64
  %type = and i64 %type$2Es, %type$2Ek
  br label %bb.t0
bb.cons:
  %cn = bitcast i64 2 to i64
  ret i64 %cn
bb.rec:
  %rn$2Eptr = inttoptr i64 %o to ptr
  %rn$2Eoff = bitcast i64 12 to i64
  %rn$2Ew.p.gep = getelementptr inbounds i8, ptr %rn$2Eptr, i64 %rn$2Eoff
  %rn$2Ew = load i32, ptr %rn$2Ew.p.gep
  %rn = sext i32 %rn$2Ew to i64
  ret i64 %rn
bb.ctor:
  %fn$2Eptr = inttoptr i64 %o to ptr
  %fn$2Eoff = bitcast i64 12 to i64
  %fn$2Ew.p.gep = getelementptr inbounds i8, ptr %fn$2Eptr, i64 %fn$2Eoff
  %fn$2Ew = load i32, ptr %fn$2Ew.p.gep
  %fn = sext i32 %fn$2Ew to i64
  ret i64 %fn
bb.clo:
  %un$2Eptr = inttoptr i64 %o to ptr
  %un$2Eoff = bitcast i64 16 to i64
  %un$2Ew.p.gep = getelementptr inbounds i8, ptr %un$2Eptr, i64 %un$2Eoff
  %un$2Ew = load i32, ptr %un$2Ew.p.gep
  %un = sext i32 %un$2Ew to i64
  ret i64 %un
bb.leaf:
  %leaf$2Ez = bitcast i64 0 to i64
  ret i64 %leaf$2Ez
bb.t0:
  %t0$2Eeq$2Ek = bitcast i64 1 to i64
  %t0$2Eeq = icmp eq i64 %type, %t0$2Eeq$2Ek
  br i1 %t0$2Eeq, label %bb.cons, label %bb.t1
bb.t1:
  %t1$2Eeq$2Ek = bitcast i64 2 to i64
  %t1$2Eeq = icmp eq i64 %type, %t1$2Eeq$2Ek
  br i1 %t1$2Eeq, label %bb.rec, label %bb.t2
bb.t2:
  %t2$2Eeq$2Ek = bitcast i64 3 to i64
  %t2$2Eeq = icmp eq i64 %type, %t2$2Eeq$2Ek
  br i1 %t2$2Eeq, label %bb.ctor, label %bb.t3
bb.t3:
  %t3$2Eeq$2Ek = bitcast i64 4 to i64
  %t3$2Eeq = icmp eq i64 %type, %t3$2Eeq$2Ek
  br i1 %t3$2Eeq, label %bb.clo, label %bb.leaf
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EchildAddr(i64 %o, i64 %idx) {
bb.entry:
  %h$2Eptr = inttoptr i64 %o to ptr
  %h$2Eoff = bitcast i64 0 to i64
  %h.p.gep = getelementptr inbounds i8, ptr %h$2Eptr, i64 %h$2Eoff
  %h = load i64, ptr %h.p.gep
  %type$2Es$2Ek = bitcast i64 32 to i64
  %type$2Es.p.m = and i64 %type$2Es$2Ek, 63
  %type$2Es = lshr i64 %h, %type$2Es.p.m
  %type$2Ek = bitcast i64 255 to i64
  %type = and i64 %type$2Es, %type$2Ek
  br label %bb.t0
bb.cons:
  %car$2Ek = bitcast i64 0 to i64
  %car = icmp eq i64 %idx, %car$2Ek
  %ca$2Ek = bitcast i64 8 to i64
  %ca = add i64 %o, %ca$2Ek
  %cd$2Ek = bitcast i64 24 to i64
  %cd = add i64 %o, %cd$2Ek
  br i1 %car, label %bb.cons.e0, label %bb.cons.e1
bb.cons.e0:
  br label %bb.out
bb.cons.e1:
  br label %bb.out
bb.rec:
  %rb$2Ek = bitcast i64 24 to i64
  %rb = add i64 %o, %rb$2Ek
  %ra$2Em$2Ek = bitcast i64 16 to i64
  %ra$2Em = mul i64 %idx, %ra$2Em$2Ek
  %ra = add i64 %rb, %ra$2Em
  br label %bb.out
bb.ctor:
  %fb$2Ek = bitcast i64 16 to i64
  %fb = add i64 %o, %fb$2Ek
  %fa$2Em$2Ek = bitcast i64 16 to i64
  %fa$2Em = mul i64 %idx, %fa$2Em$2Ek
  %fa = add i64 %fb, %fa$2Em
  br label %bb.out
bb.clo:
  %ub$2Ek = bitcast i64 24 to i64
  %ub = add i64 %o, %ub$2Ek
  %ua$2Em$2Ek = bitcast i64 16 to i64
  %ua$2Em = mul i64 %idx, %ua$2Em$2Ek
  %ua = add i64 %ub, %ua$2Em
  br label %bb.out
bb.out:
  %a = phi i64 [ %ca, %bb.cons.e0 ], [ %cd, %bb.cons.e1 ], [ %ra, %bb.rec ], [ %fa, %bb.ctor ], [ %ua, %bb.clo ]
  ret i64 %a
bb.leaf:
  %leaf$2Ez = bitcast i64 0 to i64
  ret i64 %leaf$2Ez
bb.t0:
  %t0$2Eeq$2Ek = bitcast i64 1 to i64
  %t0$2Eeq = icmp eq i64 %type, %t0$2Eeq$2Ek
  br i1 %t0$2Eeq, label %bb.cons, label %bb.t1
bb.t1:
  %t1$2Eeq$2Ek = bitcast i64 2 to i64
  %t1$2Eeq = icmp eq i64 %type, %t1$2Eeq$2Ek
  br i1 %t1$2Eeq, label %bb.rec, label %bb.t2
bb.t2:
  %t2$2Eeq$2Ek = bitcast i64 3 to i64
  %t2$2Eeq = icmp eq i64 %type, %t2$2Eeq$2Ek
  br i1 %t2$2Eeq, label %bb.ctor, label %bb.t3
bb.t3:
  %t3$2Eeq$2Ek = bitcast i64 4 to i64
  %t3$2Eeq = icmp eq i64 %type, %t3$2Eeq$2Ek
  br i1 %t3$2Eeq, label %bb.clo, label %bb.leaf
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EtypeName(i64 %type) {
bb.entry:
  br label %bb.t0
bb.other:
  %u = bitcast ptr @str.39 to ptr
  %ui = ptrtoint ptr %u to i64
  ret i64 %ui
bb.n1:
  %n1$2Es = bitcast ptr @str.31 to ptr
  %n1$2Ei = ptrtoint ptr %n1$2Es to i64
  ret i64 %n1$2Ei
bb.n2:
  %n2$2Es = bitcast ptr @str.32 to ptr
  %n2$2Ei = ptrtoint ptr %n2$2Es to i64
  ret i64 %n2$2Ei
bb.n3:
  %n3$2Es = bitcast ptr @str.33 to ptr
  %n3$2Ei = ptrtoint ptr %n3$2Es to i64
  ret i64 %n3$2Ei
bb.n4:
  %n4$2Es = bitcast ptr @str.34 to ptr
  %n4$2Ei = ptrtoint ptr %n4$2Es to i64
  ret i64 %n4$2Ei
bb.n0:
  %n0$2Es = bitcast ptr @str.35 to ptr
  %n0$2Ei = ptrtoint ptr %n0$2Es to i64
  ret i64 %n0$2Ei
bb.n5:
  %n5$2Es = bitcast ptr @str.36 to ptr
  %n5$2Ei = ptrtoint ptr %n5$2Es to i64
  ret i64 %n5$2Ei
bb.n6:
  %n6$2Es = bitcast ptr @str.37 to ptr
  %n6$2Ei = ptrtoint ptr %n6$2Es to i64
  ret i64 %n6$2Ei
bb.n7:
  %n7$2Es = bitcast ptr @str.38 to ptr
  %n7$2Ei = ptrtoint ptr %n7$2Es to i64
  ret i64 %n7$2Ei
bb.t0:
  %t0$2Eeq$2Ek = bitcast i64 1 to i64
  %t0$2Eeq = icmp eq i64 %type, %t0$2Eeq$2Ek
  br i1 %t0$2Eeq, label %bb.n1, label %bb.t1
bb.t1:
  %t1$2Eeq$2Ek = bitcast i64 2 to i64
  %t1$2Eeq = icmp eq i64 %type, %t1$2Eeq$2Ek
  br i1 %t1$2Eeq, label %bb.n2, label %bb.t2
bb.t2:
  %t2$2Eeq$2Ek = bitcast i64 3 to i64
  %t2$2Eeq = icmp eq i64 %type, %t2$2Eeq$2Ek
  br i1 %t2$2Eeq, label %bb.n3, label %bb.t3
bb.t3:
  %t3$2Eeq$2Ek = bitcast i64 4 to i64
  %t3$2Eeq = icmp eq i64 %type, %t3$2Eeq$2Ek
  br i1 %t3$2Eeq, label %bb.n4, label %bb.t4
bb.t4:
  %t4$2Eeq$2Ek = bitcast i64 0 to i64
  %t4$2Eeq = icmp eq i64 %type, %t4$2Eeq$2Ek
  br i1 %t4$2Eeq, label %bb.n0, label %bb.t5
bb.t5:
  %t5$2Eeq$2Ek = bitcast i64 5 to i64
  %t5$2Eeq = icmp eq i64 %type, %t5$2Eeq$2Ek
  br i1 %t5$2Eeq, label %bb.n5, label %bb.t6
bb.t6:
  %t6$2Eeq$2Ek = bitcast i64 6 to i64
  %t6$2Eeq = icmp eq i64 %type, %t6$2Eeq$2Ek
  br i1 %t6$2Eeq, label %bb.n6, label %bb.t7
bb.t7:
  %t7$2Eeq$2Ek = bitcast i64 7 to i64
  %t7$2Eeq = icmp eq i64 %type, %t7$2Eeq$2Ek
  br i1 %t7$2Eeq, label %bb.n7, label %bb.other
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EverifyDfs(i64 %start) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %h0$2Eptr = inttoptr i64 %start to ptr
  %h0$2Eoff = bitcast i64 0 to i64
  %h0.p.gep = getelementptr inbounds i8, ptr %h0$2Eptr, i64 %h0$2Eoff
  %h0 = load i64, ptr %h0.p.gep
  %m0$2Es$2Ek = bitcast i64 40 to i64
  %m0$2Es.p.m = and i64 %m0$2Es$2Ek, 63
  %m0$2Es = lshr i64 %h0, %m0$2Es.p.m
  %m0$2Ek = bitcast i64 255 to i64
  %m0 = and i64 %m0$2Es, %m0$2Ek
  %seen$2Ek = bitcast i64 0 to i64
  %seen = icmp ne i64 %m0, %seen$2Ek
  br i1 %seen, label %bb.done, label %bb.init
bb.init:
  %sp0$2Ev = bitcast i64 0 to i64
  %sp0$2Eptr = inttoptr i64 %s to ptr
  %sp0$2Eoff = bitcast i64 192 to i64
  %sp0.p.gep = getelementptr inbounds i8, ptr %sp0$2Eptr, i64 %sp0$2Eoff
  store i64 %sp0$2Ev, ptr %sp0.p.gep
  %sp0 = bitcast i1 true to i1
  %cap0$2Eptr = inttoptr i64 %s to ptr
  %cap0$2Eoff = bitcast i64 200 to i64
  %cap0.p.gep = getelementptr inbounds i8, ptr %cap0$2Eptr, i64 %cap0$2Eoff
  %cap0 = load i64, ptr %cap0.p.gep
  %small$2En = bitcast i64 1024 to i64
  %small$2Ea$2Eone = bitcast i64 1 to i64
  %small$2Ea$2Esh = bitcast i64 63 to i64
  %small$2Ea$2Emin.p.m = and i64 %small$2Ea$2Esh, 63
  %small$2Ea$2Emin = shl i64 %small$2Ea$2Eone, %small$2Ea$2Emin.p.m
  %small$2Ea = xor i64 %cap0, %small$2Ea$2Emin
  %small$2Eb$2Eone = bitcast i64 1 to i64
  %small$2Eb$2Esh = bitcast i64 63 to i64
  %small$2Eb$2Emin.p.m = and i64 %small$2Eb$2Esh, 63
  %small$2Eb$2Emin = shl i64 %small$2Eb$2Eone, %small$2Eb$2Emin.p.m
  %small$2Eb = xor i64 %small$2En, %small$2Eb$2Emin
  %small = icmp slt i64 %small$2Ea, %small$2Eb
  br i1 %small, label %bb.alloc0, label %bb.seed
bb.alloc0:
  %cap1 = bitcast i64 1024 to i64
  %wc$2Eptr = inttoptr i64 %s to ptr
  %wc$2Eoff = bitcast i64 200 to i64
  %wc.p.gep = getelementptr inbounds i8, ptr %wc$2Eptr, i64 %wc$2Eoff
  store i64 %cap1, ptr %wc.p.gep
  %wc = bitcast i1 true to i1
  %nb = bitcast i64 24576 to i64
  %old$2Eptr = inttoptr i64 %s to ptr
  %old$2Eoff = bitcast i64 184 to i64
  %old.p.gep = getelementptr inbounds i8, ptr %old$2Eptr, i64 %old$2Eoff
  %old = load i64, ptr %old.p.gep
  %oldp = inttoptr i64 %old to ptr
  %r0 = call ptr (ptr, i64) @realloc(ptr %oldp, i64 %nb)
  %r0i = ptrtoint ptr %r0 to i64
  %ws$2Eptr = inttoptr i64 %s to ptr
  %ws$2Eoff = bitcast i64 184 to i64
  %ws.p.gep = getelementptr inbounds i8, ptr %ws$2Eptr, i64 %ws$2Eoff
  store i64 %r0i, ptr %ws.p.gep
  %ws = bitcast i1 true to i1
  %dead0$2Ek = bitcast i64 0 to i64
  %dead0 = icmp eq i64 %r0i, %dead0$2Ek
  br i1 %dead0, label %bb.oom, label %bb.seed
bb.oom:
  %fd = bitcast i32 2 to i32
  %msg = bitcast ptr @str.17 to ptr
  %pr = call i32 (i32, ptr, ...) @dprintf(i32 %fd, ptr %msg)
  %code = bitcast i32 70 to i32
  %ex = call i64 (i32) @exit(i32 %code)
  %oom$2Ez = bitcast i64 0 to i64
  ret i64 %oom$2Ez
bb.seed:
  %g0$2Eptr = inttoptr i64 %start to ptr
  %g0$2Eoff = bitcast i64 5 to i64
  %g0$2Ev = bitcast i32 1 to i32
  %g0.p.gep = getelementptr inbounds i8, ptr %g0$2Eptr, i64 %g0$2Eoff
  %g0.p.trunc = trunc i32 %g0$2Ev to i8
  store i8 %g0.p.trunc, ptr %g0.p.gep
  %g0 = bitcast i1 true to i1
  %nc0 = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EnumChildren(i64 %start)
  %stk0$2Eptr = inttoptr i64 %s to ptr
  %stk0$2Eoff = bitcast i64 184 to i64
  %stk0.p.gep = getelementptr inbounds i8, ptr %stk0$2Eptr, i64 %stk0$2Eoff
  %stk0 = load i64, ptr %stk0.p.gep
  %sps$2Eptr = inttoptr i64 %s to ptr
  %sps$2Eoff = bitcast i64 192 to i64
  %sps.p.gep = getelementptr inbounds i8, ptr %sps$2Eptr, i64 %sps$2Eoff
  %sps = load i64, ptr %sps.p.gep
  %f0$2Em$2Ek = bitcast i64 24 to i64
  %f0$2Em = mul i64 %sps, %f0$2Em$2Ek
  %f0 = add i64 %stk0, %f0$2Em
  %f0o$2Eptr = inttoptr i64 %f0 to ptr
  %f0o$2Eoff = bitcast i64 0 to i64
  %f0o.p.gep = getelementptr inbounds i8, ptr %f0o$2Eptr, i64 %f0o$2Eoff
  store i64 %start, ptr %f0o.p.gep
  %f0o = bitcast i1 true to i1
  %f0i$2Ev = bitcast i64 0 to i64
  %f0i$2Eptr = inttoptr i64 %f0 to ptr
  %f0i$2Eoff = bitcast i64 8 to i64
  %f0i.p.gep = getelementptr inbounds i8, ptr %f0i$2Eptr, i64 %f0i$2Eoff
  store i64 %f0i$2Ev, ptr %f0i.p.gep
  %f0i = bitcast i1 true to i1
  %f0n$2Eptr = inttoptr i64 %f0 to ptr
  %f0n$2Eoff = bitcast i64 16 to i64
  %f0n.p.gep = getelementptr inbounds i8, ptr %f0n$2Eptr, i64 %f0n$2Eoff
  store i64 %nc0, ptr %f0n.p.gep
  %f0n = bitcast i1 true to i1
  %sps1$2Ek = bitcast i64 1 to i64
  %sps1 = add i64 %sps, %sps1$2Ek
  %wsp$2Eptr = inttoptr i64 %s to ptr
  %wsp$2Eoff = bitcast i64 192 to i64
  %wsp.p.gep = getelementptr inbounds i8, ptr %wsp$2Eptr, i64 %wsp$2Eoff
  store i64 %sps1, ptr %wsp.p.gep
  %wsp = bitcast i1 true to i1
  br label %bb.loop
bb.loop:
  %sp$2Eptr = inttoptr i64 %s to ptr
  %sp$2Eoff = bitcast i64 192 to i64
  %sp.p.gep = getelementptr inbounds i8, ptr %sp$2Eptr, i64 %sp$2Eoff
  %sp = load i64, ptr %sp.p.gep
  %empty$2Ek = bitcast i64 0 to i64
  %empty = icmp eq i64 %sp, %empty$2Ek
  br i1 %empty, label %bb.done, label %bb.top
bb.top:
  %stk$2Eptr = inttoptr i64 %s to ptr
  %stk$2Eoff = bitcast i64 184 to i64
  %stk.p.gep = getelementptr inbounds i8, ptr %stk$2Eptr, i64 %stk$2Eoff
  %stk = load i64, ptr %stk.p.gep
  %spm1$2Ek = bitcast i64 -1 to i64
  %spm1 = add i64 %sp, %spm1$2Ek
  %f$2Em$2Ek = bitcast i64 24 to i64
  %f$2Em = mul i64 %spm1, %f$2Em$2Ek
  %f = add i64 %stk, %f$2Em
  %o$2Eptr = inttoptr i64 %f to ptr
  %o$2Eoff = bitcast i64 0 to i64
  %o.p.gep = getelementptr inbounds i8, ptr %o$2Eptr, i64 %o$2Eoff
  %o = load i64, ptr %o.p.gep
  %ci$2Eptr = inttoptr i64 %f to ptr
  %ci$2Eoff = bitcast i64 8 to i64
  %ci.p.gep = getelementptr inbounds i8, ptr %ci$2Eptr, i64 %ci$2Eoff
  %ci = load i64, ptr %ci.p.gep
  %nc$2Eptr = inttoptr i64 %f to ptr
  %nc$2Eoff = bitcast i64 16 to i64
  %nc.p.gep = getelementptr inbounds i8, ptr %nc$2Eptr, i64 %nc$2Eoff
  %nc = load i64, ptr %nc.p.gep
  %has = icmp slt i64 %ci, %nc
  br i1 %has, label %bb.child, label %bb.pop
bb.pop:
  %b$2Eptr = inttoptr i64 %o to ptr
  %b$2Eoff = bitcast i64 5 to i64
  %b$2Ev = bitcast i32 2 to i32
  %b.p.gep = getelementptr inbounds i8, ptr %b$2Eptr, i64 %b$2Eoff
  %b.p.trunc = trunc i32 %b$2Ev to i8
  store i8 %b.p.trunc, ptr %b.p.gep
  %b = bitcast i1 true to i1
  %wpop$2Eptr = inttoptr i64 %s to ptr
  %wpop$2Eoff = bitcast i64 192 to i64
  %wpop.p.gep = getelementptr inbounds i8, ptr %wpop$2Eptr, i64 %wpop$2Eoff
  store i64 %spm1, ptr %wpop.p.gep
  %wpop = bitcast i1 true to i1
  br label %bb.loop
bb.child:
  %ca = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EchildAddr(i64 %o, i64 %ci)
  %ci1$2Ek = bitcast i64 1 to i64
  %ci1 = add i64 %ci, %ci1$2Ek
  %wci$2Eptr = inttoptr i64 %f to ptr
  %wci$2Eoff = bitcast i64 8 to i64
  %wci.p.gep = getelementptr inbounds i8, ptr %wci$2Eptr, i64 %wci$2Eoff
  store i64 %ci1, ptr %wci.p.gep
  %wci = bitcast i1 true to i1
  %tag$2Es$2Eptr = inttoptr i64 %ca to ptr
  %tag$2Es$2Eoff = bitcast i64 0 to i64
  %tag$2Es$2Ew.p.gep = getelementptr inbounds i8, ptr %tag$2Es$2Eptr, i64 %tag$2Es$2Eoff
  %tag$2Es$2Ew = load i32, ptr %tag$2Es$2Ew.p.gep
  %tag$2Es = sext i32 %tag$2Es$2Ew to i64
  %tag$2Ek = bitcast i64 4294967295 to i64
  %tag = and i64 %tag$2Es, %tag$2Ek
  %obj$2Eptr = inttoptr i64 %ca to ptr
  %obj$2Eoff = bitcast i64 8 to i64
  %obj.p.gep = getelementptr inbounds i8, ptr %obj$2Eptr, i64 %obj$2Eoff
  %obj = load i64, ptr %obj.p.gep
  %isObj$2Elo$2Ek = bitcast i64 5 to i64
  %isObj$2Elo = icmp sge i64 %tag, %isObj$2Elo$2Ek
  %isObj$2Ehi$2Ek = bitcast i64 15 to i64
  %isObj$2Ehi = icmp sle i64 %tag, %isObj$2Ehi$2Ek
  %isObj$2Ene$2Ek = bitcast i64 10 to i64
  %isObj$2Ene = icmp ne i64 %tag, %isObj$2Ene$2Ek
  %isObj$2Enz$2Ek = bitcast i64 0 to i64
  %isObj$2Enz = icmp ne i64 %obj, %isObj$2Enz$2Ek
  %isObj$2Ea = and i1 %isObj$2Elo, %isObj$2Ehi
  %isObj$2Eb = and i1 %isObj$2Ene, %isObj$2Enz
  %isObj = and i1 %isObj$2Ea, %isObj$2Eb
  br i1 %isObj, label %bb.cobj, label %bb.loop
bb.cobj:
  %ch$2Eptr = inttoptr i64 %obj to ptr
  %ch$2Eoff = bitcast i64 0 to i64
  %ch.p.gep = getelementptr inbounds i8, ptr %ch$2Eptr, i64 %ch$2Eoff
  %ch = load i64, ptr %ch.p.gep
  %cperm$2Es$2Ek = bitcast i64 48 to i64
  %cperm$2Es.p.m = and i64 %cperm$2Es$2Ek, 63
  %cperm$2Es = lshr i64 %ch, %cperm$2Es.p.m
  %cperm$2Ek = bitcast i64 255 to i64
  %cperm = and i64 %cperm$2Es, %cperm$2Ek
  %cp$2Ek = bitcast i64 0 to i64
  %cp = icmp ne i64 %cperm, %cp$2Ek
  br i1 %cp, label %bb.loop, label %bb.cmark
bb.cmark:
  %cm$2Es$2Ek = bitcast i64 40 to i64
  %cm$2Es.p.m = and i64 %cm$2Es$2Ek, 63
  %cm$2Es = lshr i64 %ch, %cm$2Es.p.m
  %cm$2Ek = bitcast i64 255 to i64
  %cm = and i64 %cm$2Es, %cm$2Ek
  %grey$2Ek = bitcast i64 1 to i64
  %grey = icmp eq i64 %cm, %grey$2Ek
  br i1 %grey, label %bb.cycle, label %bb.cwhite
bb.cwhite:
  %white$2Ek = bitcast i64 0 to i64
  %white = icmp eq i64 %cm, %white$2Ek
  br i1 %white, label %bb.cpush, label %bb.loop
bb.cpush:
  %sp2$2Eptr = inttoptr i64 %s to ptr
  %sp2$2Eoff = bitcast i64 192 to i64
  %sp2.p.gep = getelementptr inbounds i8, ptr %sp2$2Eptr, i64 %sp2$2Eoff
  %sp2 = load i64, ptr %sp2.p.gep
  %cap2$2Eptr = inttoptr i64 %s to ptr
  %cap2$2Eoff = bitcast i64 200 to i64
  %cap2.p.gep = getelementptr inbounds i8, ptr %cap2$2Eptr, i64 %cap2$2Eoff
  %cap2 = load i64, ptr %cap2.p.gep
  %full = icmp eq i64 %sp2, %cap2
  br i1 %full, label %bb.cgrow, label %bb.cput
bb.cgrow:
  %lim = bitcast i64 1048576 to i64
  %atLim$2Ea$2Eone = bitcast i64 1 to i64
  %atLim$2Ea$2Esh = bitcast i64 63 to i64
  %atLim$2Ea$2Emin.p.m = and i64 %atLim$2Ea$2Esh, 63
  %atLim$2Ea$2Emin = shl i64 %atLim$2Ea$2Eone, %atLim$2Ea$2Emin.p.m
  %atLim$2Ea = xor i64 %lim, %atLim$2Ea$2Emin
  %atLim$2Eb$2Eone = bitcast i64 1 to i64
  %atLim$2Eb$2Esh = bitcast i64 63 to i64
  %atLim$2Eb$2Emin.p.m = and i64 %atLim$2Eb$2Esh, 63
  %atLim$2Eb$2Emin = shl i64 %atLim$2Eb$2Eone, %atLim$2Eb$2Emin.p.m
  %atLim$2Eb = xor i64 %cap2, %atLim$2Eb$2Emin
  %atLim = icmp sle i64 %atLim$2Ea, %atLim$2Eb
  br i1 %atLim, label %bb.limit, label %bb.cgrow2
bb.limit:
  %limit$2Ec = bitcast ptr @str.15 to ptr
  %limit$2Ef = bitcast ptr @str.16 to ptr
  %limit$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %limit$2Ec, ptr %limit$2Ef)
  %limit$2Ez = bitcast i64 0 to i64
  ret i64 %limit$2Ez
bb.cgrow2:
  %cap3$2Ek = bitcast i64 2 to i64
  %cap3 = mul i64 %cap2, %cap3$2Ek
  %wc3$2Eptr = inttoptr i64 %s to ptr
  %wc3$2Eoff = bitcast i64 200 to i64
  %wc3.p.gep = getelementptr inbounds i8, ptr %wc3$2Eptr, i64 %wc3$2Eoff
  store i64 %cap3, ptr %wc3.p.gep
  %wc3 = bitcast i1 true to i1
  %nb3$2Ek = bitcast i64 24 to i64
  %nb3 = mul i64 %cap3, %nb3$2Ek
  %old3$2Eptr = inttoptr i64 %s to ptr
  %old3$2Eoff = bitcast i64 184 to i64
  %old3.p.gep = getelementptr inbounds i8, ptr %old3$2Eptr, i64 %old3$2Eoff
  %old3 = load i64, ptr %old3.p.gep
  %old3p = inttoptr i64 %old3 to ptr
  %r3 = call ptr (ptr, i64) @realloc(ptr %old3p, i64 %nb3)
  %r3i = ptrtoint ptr %r3 to i64
  %ws3$2Eptr = inttoptr i64 %s to ptr
  %ws3$2Eoff = bitcast i64 184 to i64
  %ws3.p.gep = getelementptr inbounds i8, ptr %ws3$2Eptr, i64 %ws3$2Eoff
  store i64 %r3i, ptr %ws3.p.gep
  %ws3 = bitcast i1 true to i1
  %dead3$2Ek = bitcast i64 0 to i64
  %dead3 = icmp eq i64 %r3i, %dead3$2Ek
  br i1 %dead3, label %bb.oom, label %bb.cput
bb.cput:
  %g1$2Eptr = inttoptr i64 %obj to ptr
  %g1$2Eoff = bitcast i64 5 to i64
  %g1$2Ev = bitcast i32 1 to i32
  %g1.p.gep = getelementptr inbounds i8, ptr %g1$2Eptr, i64 %g1$2Eoff
  %g1.p.trunc = trunc i32 %g1$2Ev to i8
  store i8 %g1.p.trunc, ptr %g1.p.gep
  %g1 = bitcast i1 true to i1
  %ncc = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EnumChildren(i64 %obj)
  %stk4$2Eptr = inttoptr i64 %s to ptr
  %stk4$2Eoff = bitcast i64 184 to i64
  %stk4.p.gep = getelementptr inbounds i8, ptr %stk4$2Eptr, i64 %stk4$2Eoff
  %stk4 = load i64, ptr %stk4.p.gep
  %sp4$2Eptr = inttoptr i64 %s to ptr
  %sp4$2Eoff = bitcast i64 192 to i64
  %sp4.p.gep = getelementptr inbounds i8, ptr %sp4$2Eptr, i64 %sp4$2Eoff
  %sp4 = load i64, ptr %sp4.p.gep
  %f4$2Em$2Ek = bitcast i64 24 to i64
  %f4$2Em = mul i64 %sp4, %f4$2Em$2Ek
  %f4 = add i64 %stk4, %f4$2Em
  %f4o$2Eptr = inttoptr i64 %f4 to ptr
  %f4o$2Eoff = bitcast i64 0 to i64
  %f4o.p.gep = getelementptr inbounds i8, ptr %f4o$2Eptr, i64 %f4o$2Eoff
  store i64 %obj, ptr %f4o.p.gep
  %f4o = bitcast i1 true to i1
  %f4i$2Ev = bitcast i64 0 to i64
  %f4i$2Eptr = inttoptr i64 %f4 to ptr
  %f4i$2Eoff = bitcast i64 8 to i64
  %f4i.p.gep = getelementptr inbounds i8, ptr %f4i$2Eptr, i64 %f4i$2Eoff
  store i64 %f4i$2Ev, ptr %f4i.p.gep
  %f4i = bitcast i1 true to i1
  %f4n$2Eptr = inttoptr i64 %f4 to ptr
  %f4n$2Eoff = bitcast i64 16 to i64
  %f4n.p.gep = getelementptr inbounds i8, ptr %f4n$2Eptr, i64 %f4n$2Eoff
  store i64 %ncc, ptr %f4n.p.gep
  %f4n = bitcast i1 true to i1
  %sp41$2Ek = bitcast i64 1 to i64
  %sp41 = add i64 %sp4, %sp41$2Ek
  %wsp4$2Eptr = inttoptr i64 %s to ptr
  %wsp4$2Eoff = bitcast i64 192 to i64
  %wsp4.p.gep = getelementptr inbounds i8, ptr %wsp4$2Eptr, i64 %wsp4$2Eoff
  store i64 %sp41, ptr %wsp4.p.gep
  %wsp4 = bitcast i1 true to i1
  br label %bb.loop
bb.cycle:
  br label %bb.dloop
bb.dloop:
  %di = phi i64 [ %spm1, %bb.cycle ], [ %di1, %bb.dnext ]
  %dneg$2Ek = bitcast i64 0 to i64
  %dneg = icmp slt i64 %di, %dneg$2Ek
  %d1 = bitcast i64 1 to i64
  br i1 %dneg, label %bb.report, label %bb.dbody
bb.dbody:
  %dat$2Em$2Ek = bitcast i64 24 to i64
  %dat$2Em = mul i64 %di, %dat$2Em$2Ek
  %dat = add i64 %stk, %dat$2Em
  %dobj$2Eptr = inttoptr i64 %dat to ptr
  %dobj$2Eoff = bitcast i64 0 to i64
  %dobj.p.gep = getelementptr inbounds i8, ptr %dobj$2Eptr, i64 %dobj$2Eoff
  %dobj = load i64, ptr %dobj.p.gep
  %deq = icmp eq i64 %dobj, %obj
  br i1 %deq, label %bb.found, label %bb.dnext
bb.found:
  %dd = sub i64 %sp, %di
  br label %bb.report
bb.dnext:
  %di1$2Ek = bitcast i64 -1 to i64
  %di1 = add i64 %di, %di1$2Ek
  br label %bb.dloop
bb.report:
  %depth = phi i64 [ %d1, %bb.dloop ], [ %dd, %bb.found ]
  %ctype$2Es$2Ek = bitcast i64 32 to i64
  %ctype$2Es.p.m = and i64 %ctype$2Es$2Ek, 63
  %ctype$2Es = lshr i64 %ch, %ctype$2Es.p.m
  %ctype$2Ek = bitcast i64 255 to i64
  %ctype = and i64 %ctype$2Es, %ctype$2Ek
  %tni = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EtypeName(i64 %ctype)
  %tn = inttoptr i64 %tni to ptr
  %d32.p.low = icmp sge i64 %depth, -2147483648
  %d32.p.high = icmp sle i64 %depth, 2147483647
  %d32.p.fits = and i1 %d32.p.low, %d32.p.high
  %d32.p.bad = xor i1 %d32.p.fits, true
  br i1 %d32.p.bad, label %d32.p.trap, label %d32.p.ok
d32.p.trap:
  call void @rterr.int(i32 7)
  unreachable
d32.p.ok:
  %d32 = trunc i64 %depth to i32
  %efd = bitcast i32 2 to i32
  %cyc = bitcast ptr @str.14 to ptr
  %pc = call i32 (i32, ptr, ...) @dprintf(i32 %efd, ptr %cyc, ptr %tn, i32 %d32)
  br label %bb.raise
bb.raise:
  %raise$2Ec = bitcast ptr @str.12 to ptr
  %raise$2Ef = bitcast ptr @str.13 to ptr
  %raise$2Ebi = call tailcc i64 @gcAslFailBuf()
  %raise$2Eb = inttoptr i64 %raise$2Ebi to ptr
  %raise$2Ecap = bitcast i64 1024 to i64
  %raise$2En = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %raise$2Eb, i64 %raise$2Ecap, ptr %raise$2Ef, i32 %d32, ptr %tn)
  %raise$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %raise$2Ec, ptr %raise$2Eb)
  %raise$2Ez = bitcast i64 0 to i64
  ret i64 %raise$2Ez
bb.done:
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EverifyHeap() {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %c0 = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EclearMarks()
  %l0$2Eptr = inttoptr i64 %s to ptr
  %l0$2Eoff = bitcast i64 224 to i64
  %l0.p.gep = getelementptr inbounds i8, ptr %l0$2Eptr, i64 %l0$2Eoff
  %l0 = load i64, ptr %l0.p.gep
  br label %bb.loop
bb.loop:
  %lo = phi i64 [ %l0, %bb.entry ], [ %nx, %bb.body ]
  %z$2Ek = bitcast i64 0 to i64
  %z = icmp eq i64 %lo, %z$2Ek
  br i1 %z, label %bb.pooled, label %bb.body
bb.body:
  %o$2Ek = bitcast i64 24 to i64
  %o = add i64 %lo, %o$2Ek
  %v = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EverifyDfs(i64 %o)
  %nx$2Eptr = inttoptr i64 %lo to ptr
  %nx$2Eoff = bitcast i64 0 to i64
  %nx.p.gep = getelementptr inbounds i8, ptr %nx$2Eptr, i64 %nx$2Eoff
  %nx = load i64, ptr %nx.p.gep
  br label %bb.loop
bb.pooled:
  %zero = bitcast i64 0 to i64
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpoolScan(i64 %zero)
  %c = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EclearMarks()
  %pooled$2Ez = bitcast i64 0 to i64
  ret i64 %pooled$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSlot(i64 %base, i64 %cap) {
bb.entry:
  %b$2Ek = bitcast i64 14 to i64
  %b.p.m = and i64 %b$2Ek, 63
  %b = lshr i64 %base, %b.p.m
  %h$2Ek = bitcast i64 -7046029254386353131 to i64
  %h = mul i64 %b, %h$2Ek
  %h20$2Ek = bitcast i64 20 to i64
  %h20.p.m = and i64 %h20$2Ek, 63
  %h20 = lshr i64 %h, %h20.p.m
  %m$2Ek = bitcast i64 -1 to i64
  %m = add i64 %cap, %m$2Ek
  %i = and i64 %h20, %m
  ret i64 %i
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSetPut(i64 %p) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %cap$2Eptr = inttoptr i64 %s to ptr
  %cap$2Eoff = bitcast i64 240 to i64
  %cap.p.gep = getelementptr inbounds i8, ptr %cap$2Eptr, i64 %cap$2Eoff
  %cap = load i64, ptr %cap.p.gep
  %set$2Eptr = inttoptr i64 %s to ptr
  %set$2Eoff = bitcast i64 232 to i64
  %set.p.gep = getelementptr inbounds i8, ptr %set$2Eptr, i64 %set$2Eoff
  %set = load i64, ptr %set.p.gep
  %m$2Ek = bitcast i64 -1 to i64
  %m = add i64 %cap, %m$2Ek
  %i0 = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSlot(i64 %p, i64 %cap)
  br label %bb.loop
bb.loop:
  %i = phi i64 [ %i0, %bb.entry ], [ %i2, %bb.next ]
  %a$2Em$2Ek = bitcast i64 8 to i64
  %a$2Em = mul i64 %i, %a$2Em$2Ek
  %a = add i64 %set, %a$2Em
  %e$2Eptr = inttoptr i64 %a to ptr
  %e$2Eoff = bitcast i64 0 to i64
  %e.p.gep = getelementptr inbounds i8, ptr %e$2Eptr, i64 %e$2Eoff
  %e = load i64, ptr %e.p.gep
  %empty$2Ek = bitcast i64 0 to i64
  %empty = icmp eq i64 %e, %empty$2Ek
  br i1 %empty, label %bb.put, label %bb.check
bb.check:
  %same = icmp eq i64 %e, %p
  br i1 %same, label %bb.done, label %bb.next
bb.next:
  %i1$2Ek = bitcast i64 1 to i64
  %i1 = add i64 %i, %i1$2Ek
  %i2 = and i64 %i1, %m
  br label %bb.loop
bb.put:
  %w$2Eptr = inttoptr i64 %a to ptr
  %w$2Eoff = bitcast i64 0 to i64
  %w.p.gep = getelementptr inbounds i8, ptr %w$2Eptr, i64 %w$2Eoff
  store i64 %p, ptr %w.p.gep
  %w = bitcast i1 true to i1
  %cnt$2Eby = bitcast i64 1 to i64
  %cnt$2Eold$2Eptr = inttoptr i64 %s to ptr
  %cnt$2Eold$2Eoff = bitcast i64 248 to i64
  %cnt$2Eold.p.gep = getelementptr inbounds i8, ptr %cnt$2Eold$2Eptr, i64 %cnt$2Eold$2Eoff
  %cnt$2Eold = load i64, ptr %cnt$2Eold.p.gep
  %cnt$2Enew = add i64 %cnt$2Eold, %cnt$2Eby
  %cnt$2Eptr = inttoptr i64 %s to ptr
  %cnt$2Eoff = bitcast i64 248 to i64
  %cnt.p.gep = getelementptr inbounds i8, ptr %cnt$2Eptr, i64 %cnt$2Eoff
  store i64 %cnt$2Enew, ptr %cnt.p.gep
  %cnt = bitcast i1 true to i1
  %put$2Ez = bitcast i64 0 to i64
  ret i64 %put$2Ez
bb.done:
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSetReserve() {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %cnt$2Eptr = inttoptr i64 %s to ptr
  %cnt$2Eoff = bitcast i64 248 to i64
  %cnt.p.gep = getelementptr inbounds i8, ptr %cnt$2Eptr, i64 %cnt$2Eoff
  %cnt = load i64, ptr %cnt.p.gep
  %cap$2Eptr = inttoptr i64 %s to ptr
  %cap$2Eoff = bitcast i64 240 to i64
  %cap.p.gep = getelementptr inbounds i8, ptr %cap$2Eptr, i64 %cap$2Eoff
  %cap = load i64, ptr %cap.p.gep
  %c1$2Ek = bitcast i64 1 to i64
  %c1 = add i64 %cnt, %c1$2Ek
  %need$2Ek = bitcast i64 2 to i64
  %need = mul i64 %c1, %need$2Ek
  %fits$2Ea$2Eone = bitcast i64 1 to i64
  %fits$2Ea$2Esh = bitcast i64 63 to i64
  %fits$2Ea$2Emin.p.m = and i64 %fits$2Ea$2Esh, 63
  %fits$2Ea$2Emin = shl i64 %fits$2Ea$2Eone, %fits$2Ea$2Emin.p.m
  %fits$2Ea = xor i64 %need, %fits$2Ea$2Emin
  %fits$2Eb$2Eone = bitcast i64 1 to i64
  %fits$2Eb$2Esh = bitcast i64 63 to i64
  %fits$2Eb$2Emin.p.m = and i64 %fits$2Eb$2Esh, 63
  %fits$2Eb$2Emin = shl i64 %fits$2Eb$2Eone, %fits$2Eb$2Emin.p.m
  %fits$2Eb = xor i64 %cap, %fits$2Eb$2Emin
  %fits = icmp sle i64 %fits$2Ea, %fits$2Eb
  br i1 %fits, label %bb.done, label %bb.grow
bb.grow:
  %z$2Ek = bitcast i64 0 to i64
  %z = icmp eq i64 %cap, %z$2Ek
  %first = bitcast i64 256 to i64
  %twice$2Ek = bitcast i64 2 to i64
  %twice = mul i64 %cap, %twice$2Ek
  br i1 %z, label %bb.grow.e0, label %bb.grow.e1
bb.grow.e0:
  br label %bb.sized
bb.grow.e1:
  br label %bb.sized
bb.sized:
  %nc = phi i64 [ %first, %bb.grow.e0 ], [ %twice, %bb.grow.e1 ]
  %fail$2Eptr = inttoptr i64 %s to ptr
  %fail$2Eoff = bitcast i64 312 to i64
  %fail.p.gep = getelementptr inbounds i8, ptr %fail$2Eptr, i64 %fail$2Eoff
  %fail = load i64, ptr %fail.p.gep
  %wf$2Ev = bitcast i64 0 to i64
  %wf$2Eptr = inttoptr i64 %s to ptr
  %wf$2Eoff = bitcast i64 312 to i64
  %wf.p.gep = getelementptr inbounds i8, ptr %wf$2Eptr, i64 %wf$2Eoff
  store i64 %wf$2Ev, ptr %wf.p.gep
  %wf = bitcast i1 true to i1
  %forced$2Ek = bitcast i64 0 to i64
  %forced = icmp ne i64 %fail, %forced$2Ek
  br i1 %forced, label %bb.oom, label %bb.alloc
bb.alloc:
  %eight = bitcast i64 8 to i64
  %r = call ptr (i64, i64) @calloc(i64 %nc, i64 %eight)
  %ri = ptrtoint ptr %r to i64
  %dead$2Ek = bitcast i64 0 to i64
  %dead = icmp eq i64 %ri, %dead$2Ek
  br i1 %dead, label %bb.oom, label %bb.rehash
bb.oom:
  %oom$2Ec = bitcast ptr @str.2 to ptr
  %oom$2Ef = bitcast ptr @str.3 to ptr
  %oom$2Ebi = call tailcc i64 @gcAslFailBuf()
  %oom$2Eb = inttoptr i64 %oom$2Ebi to ptr
  %oom$2Ecap = bitcast i64 1024 to i64
  %oom$2En = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %oom$2Eb, i64 %oom$2Ecap, ptr %oom$2Ef, i64 %nc)
  %oom$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %oom$2Ec, ptr %oom$2Eb)
  %oom$2Ez = bitcast i64 0 to i64
  ret i64 %oom$2Ez
bb.rehash:
  %old$2Eptr = inttoptr i64 %s to ptr
  %old$2Eoff = bitcast i64 232 to i64
  %old.p.gep = getelementptr inbounds i8, ptr %old$2Eptr, i64 %old$2Eoff
  %old = load i64, ptr %old.p.gep
  %w1$2Eptr = inttoptr i64 %s to ptr
  %w1$2Eoff = bitcast i64 232 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %ri, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  %w2$2Eptr = inttoptr i64 %s to ptr
  %w2$2Eoff = bitcast i64 240 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %nc, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  %w3$2Ev = bitcast i64 0 to i64
  %w3$2Eptr = inttoptr i64 %s to ptr
  %w3$2Eoff = bitcast i64 248 to i64
  %w3.p.gep = getelementptr inbounds i8, ptr %w3$2Eptr, i64 %w3$2Eoff
  store i64 %w3$2Ev, ptr %w3.p.gep
  %w3 = bitcast i1 true to i1
  %i0 = bitcast i64 0 to i64
  br label %bb.hloop
bb.hloop:
  %i = phi i64 [ %i0, %bb.rehash ], [ %i1, %bb.hnext ]
  %more = icmp slt i64 %i, %cap
  br i1 %more, label %bb.hbody, label %bb.release
bb.hbody:
  %at$2Em$2Ek = bitcast i64 8 to i64
  %at$2Em = mul i64 %i, %at$2Em$2Ek
  %at = add i64 %old, %at$2Em
  %e$2Eptr = inttoptr i64 %at to ptr
  %e$2Eoff = bitcast i64 0 to i64
  %e.p.gep = getelementptr inbounds i8, ptr %e$2Eptr, i64 %e$2Eoff
  %e = load i64, ptr %e.p.gep
  %ez$2Ek = bitcast i64 0 to i64
  %ez = icmp eq i64 %e, %ez$2Ek
  br i1 %ez, label %bb.hnext, label %bb.hput
bb.hput:
  %pp = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSetPut(i64 %e)
  br label %bb.hnext
bb.hnext:
  %i1$2Ek = bitcast i64 1 to i64
  %i1 = add i64 %i, %i1$2Ek
  br label %bb.hloop
bb.release:
  %oldp = inttoptr i64 %old to ptr
  %fr = call i64 (ptr) @free(ptr %oldp)
  %release$2Ez = bitcast i64 0 to i64
  ret i64 %release$2Ez
bb.done:
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSetGet(i64 %base) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %cap$2Eptr = inttoptr i64 %s to ptr
  %cap$2Eoff = bitcast i64 240 to i64
  %cap.p.gep = getelementptr inbounds i8, ptr %cap$2Eptr, i64 %cap$2Eoff
  %cap = load i64, ptr %cap.p.gep
  %z$2Ek = bitcast i64 0 to i64
  %z = icmp eq i64 %cap, %z$2Ek
  br i1 %z, label %bb.none, label %bb.start
bb.start:
  %set$2Eptr = inttoptr i64 %s to ptr
  %set$2Eoff = bitcast i64 232 to i64
  %set.p.gep = getelementptr inbounds i8, ptr %set$2Eptr, i64 %set$2Eoff
  %set = load i64, ptr %set.p.gep
  %m$2Ek = bitcast i64 -1 to i64
  %m = add i64 %cap, %m$2Ek
  %i0 = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSlot(i64 %base, i64 %cap)
  br label %bb.loop
bb.loop:
  %i = phi i64 [ %i0, %bb.start ], [ %i2, %bb.next ]
  %a$2Em$2Ek = bitcast i64 8 to i64
  %a$2Em = mul i64 %i, %a$2Em$2Ek
  %a = add i64 %set, %a$2Em
  %e$2Eptr = inttoptr i64 %a to ptr
  %e$2Eoff = bitcast i64 0 to i64
  %e.p.gep = getelementptr inbounds i8, ptr %e$2Eptr, i64 %e$2Eoff
  %e = load i64, ptr %e.p.gep
  %empty$2Ek = bitcast i64 0 to i64
  %empty = icmp eq i64 %e, %empty$2Ek
  br i1 %empty, label %bb.none, label %bb.check
bb.check:
  %hit = icmp eq i64 %e, %base
  br i1 %hit, label %bb.found, label %bb.next
bb.found:
  ret i64 %e
bb.next:
  %i1$2Ek = bitcast i64 1 to i64
  %i1 = add i64 %i, %i1$2Ek
  %i2 = and i64 %i1, %m
  br label %bb.loop
bb.none:
  %none$2Ez = bitcast i64 0 to i64
  ret i64 %none$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSetDel(i64 %p) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %cap$2Eptr = inttoptr i64 %s to ptr
  %cap$2Eoff = bitcast i64 240 to i64
  %cap.p.gep = getelementptr inbounds i8, ptr %cap$2Eptr, i64 %cap$2Eoff
  %cap = load i64, ptr %cap.p.gep
  %z$2Ek = bitcast i64 0 to i64
  %z = icmp eq i64 %cap, %z$2Ek
  br i1 %z, label %bb.empty, label %bb.start
bb.empty:
  %empty$2Ec = bitcast ptr @str.0 to ptr
  %empty$2Ef = bitcast ptr @str.4 to ptr
  %empty$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %empty$2Ec, ptr %empty$2Ef)
  %empty$2Ez = bitcast i64 0 to i64
  ret i64 %empty$2Ez
bb.start:
  %set$2Eptr = inttoptr i64 %s to ptr
  %set$2Eoff = bitcast i64 232 to i64
  %set.p.gep = getelementptr inbounds i8, ptr %set$2Eptr, i64 %set$2Eoff
  %set = load i64, ptr %set.p.gep
  %m$2Ek = bitcast i64 -1 to i64
  %m = add i64 %cap, %m$2Ek
  %i0 = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSlot(i64 %p, i64 %cap)
  br label %bb.find
bb.find:
  %i = phi i64 [ %i0, %bb.start ], [ %i2, %bb.step ]
  %a$2Em$2Ek = bitcast i64 8 to i64
  %a$2Em = mul i64 %i, %a$2Em$2Ek
  %a = add i64 %set, %a$2Em
  %e$2Eptr = inttoptr i64 %a to ptr
  %e$2Eoff = bitcast i64 0 to i64
  %e.p.gep = getelementptr inbounds i8, ptr %e$2Eptr, i64 %e$2Eoff
  %e = load i64, ptr %e.p.gep
  %hit = icmp eq i64 %e, %p
  br i1 %hit, label %bb.clear, label %bb.miss
bb.miss:
  %ez$2Ek = bitcast i64 0 to i64
  %ez = icmp eq i64 %e, %ez$2Ek
  br i1 %ez, label %bb.missing, label %bb.step
bb.missing:
  %pp = inttoptr i64 %p to ptr
  %missing$2Ec = bitcast ptr @str.0 to ptr
  %missing$2Ef = bitcast ptr @str.5 to ptr
  %missing$2Ebi = call tailcc i64 @gcAslFailBuf()
  %missing$2Eb = inttoptr i64 %missing$2Ebi to ptr
  %missing$2Ecap = bitcast i64 1024 to i64
  %missing$2En = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %missing$2Eb, i64 %missing$2Ecap, ptr %missing$2Ef, ptr %pp)
  %missing$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %missing$2Ec, ptr %missing$2Eb)
  %missing$2Ez = bitcast i64 0 to i64
  ret i64 %missing$2Ez
bb.step:
  %i1$2Ek = bitcast i64 1 to i64
  %i1 = add i64 %i, %i1$2Ek
  %i2 = and i64 %i1, %m
  br label %bb.find
bb.clear:
  %w0$2Ev = bitcast i64 0 to i64
  %w0$2Eptr = inttoptr i64 %a to ptr
  %w0$2Eoff = bitcast i64 0 to i64
  %w0.p.gep = getelementptr inbounds i8, ptr %w0$2Eptr, i64 %w0$2Eoff
  store i64 %w0$2Ev, ptr %w0.p.gep
  %w0 = bitcast i1 true to i1
  %cnt$2Eby = bitcast i64 -1 to i64
  %cnt$2Eold$2Eptr = inttoptr i64 %s to ptr
  %cnt$2Eold$2Eoff = bitcast i64 248 to i64
  %cnt$2Eold.p.gep = getelementptr inbounds i8, ptr %cnt$2Eold$2Eptr, i64 %cnt$2Eold$2Eoff
  %cnt$2Eold = load i64, ptr %cnt$2Eold.p.gep
  %cnt$2Enew = add i64 %cnt$2Eold, %cnt$2Eby
  %cnt$2Eptr = inttoptr i64 %s to ptr
  %cnt$2Eoff = bitcast i64 248 to i64
  %cnt.p.gep = getelementptr inbounds i8, ptr %cnt$2Eptr, i64 %cnt$2Eoff
  store i64 %cnt$2Enew, ptr %cnt.p.gep
  %cnt = bitcast i1 true to i1
  %j1$2Ek = bitcast i64 1 to i64
  %j1 = add i64 %i, %j1$2Ek
  %j0 = and i64 %j1, %m
  br label %bb.shift
bb.shift:
  %hole = phi i64 [ %i, %bb.clear ], [ %nh, %bb.snext ]
  %j = phi i64 [ %j0, %bb.clear ], [ %jn2, %bb.snext ]
  %ja$2Em$2Ek = bitcast i64 8 to i64
  %ja$2Em = mul i64 %j, %ja$2Em$2Ek
  %ja = add i64 %set, %ja$2Em
  %ej$2Eptr = inttoptr i64 %ja to ptr
  %ej$2Eoff = bitcast i64 0 to i64
  %ej.p.gep = getelementptr inbounds i8, ptr %ej$2Eptr, i64 %ej$2Eoff
  %ej = load i64, ptr %ej.p.gep
  %jz$2Ek = bitcast i64 0 to i64
  %jz = icmp eq i64 %ej, %jz$2Ek
  br i1 %jz, label %bb.done, label %bb.test
bb.test:
  %h = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSlot(i64 %ej, i64 %cap)
  %jgt = icmp sgt i64 %j, %hole
  %hle = icmp sle i64 %h, %hole
  %hgt = icmp sgt i64 %h, %j
  %out1 = or i1 %hle, %hgt
  %c1 = and i1 %jgt, %out1
  %jlt = icmp slt i64 %j, %hole
  %c2a = and i1 %jlt, %hle
  %c2 = and i1 %c2a, %hgt
  %move = or i1 %c1, %c2
  br i1 %move, label %bb.moved, label %bb.snext
bb.moved:
  %ha$2Em$2Ek = bitcast i64 8 to i64
  %ha$2Em = mul i64 %hole, %ha$2Em$2Ek
  %ha = add i64 %set, %ha$2Em
  %wm$2Eptr = inttoptr i64 %ha to ptr
  %wm$2Eoff = bitcast i64 0 to i64
  %wm.p.gep = getelementptr inbounds i8, ptr %wm$2Eptr, i64 %wm$2Eoff
  store i64 %ej, ptr %wm.p.gep
  %wm = bitcast i1 true to i1
  %wz$2Ev = bitcast i64 0 to i64
  %wz$2Eptr = inttoptr i64 %ja to ptr
  %wz$2Eoff = bitcast i64 0 to i64
  %wz.p.gep = getelementptr inbounds i8, ptr %wz$2Eptr, i64 %wz$2Eoff
  store i64 %wz$2Ev, ptr %wz.p.gep
  %wz = bitcast i1 true to i1
  br label %bb.snext
bb.snext:
  %nh = phi i64 [ %hole, %bb.test ], [ %j, %bb.moved ]
  %jn$2Ek = bitcast i64 1 to i64
  %jn = add i64 %j, %jn$2Ek
  %jn2 = and i64 %jn, %m
  br label %bb.shift
bb.done:
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Eunmap(i64 %addr, i64 %len) {
bb.entry:
  %ap = inttoptr i64 %addr to ptr
  %r = call i32 (ptr, i64) @munmap(ptr %ap, i64 %len)
  %r64 = sext i32 %r to i64
  %bad$2Ek = bitcast i64 0 to i64
  %bad = icmp ne i64 %r64, %bad$2Ek
  br i1 %bad, label %bb.fail, label %bb.done
bb.fail:
  %fail$2Ec = bitcast ptr @str.0 to ptr
  %fail$2Ef = bitcast ptr @str.28 to ptr
  %fail$2Ebi = call tailcc i64 @gcAslFailBuf()
  %fail$2Eb = inttoptr i64 %fail$2Ebi to ptr
  %fail$2Ecap = bitcast i64 1024 to i64
  %fail$2En = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %fail$2Eb, i64 %fail$2Ecap, ptr %fail$2Ef, ptr %ap)
  %fail$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %fail$2Ec, ptr %fail$2Eb)
  %fail$2Ez = bitcast i64 0 to i64
  ret i64 %fail$2Ez
bb.done:
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EfreshPage() {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %nx$2Eptr = inttoptr i64 %s to ptr
  %nx$2Eoff = bitcast i64 320 to i64
  %nx.p.gep = getelementptr inbounds i8, ptr %nx$2Eptr, i64 %nx$2Eoff
  %nx = load i64, ptr %nx.p.gep
  %end$2Eptr = inttoptr i64 %s to ptr
  %end$2Eoff = bitcast i64 328 to i64
  %end.p.gep = getelementptr inbounds i8, ptr %end$2Eptr, i64 %end$2Eoff
  %end = load i64, ptr %end.p.gep
  %have = icmp slt i64 %nx, %end
  br i1 %have, label %bb.take, label %bb.map
bb.take:
  %nx1$2Ek = bitcast i64 16384 to i64
  %nx1 = add i64 %nx, %nx1$2Ek
  %w$2Eptr = inttoptr i64 %s to ptr
  %w$2Eoff = bitcast i64 320 to i64
  %w.p.gep = getelementptr inbounds i8, ptr %w$2Eptr, i64 %w$2Eoff
  store i64 %nx1, ptr %w.p.gep
  %w = bitcast i1 true to i1
  ret i64 %nx
bb.map:
  %len = bitcast i64 1048576 to i64
  %zero = bitcast i64 0 to i64
  %nul = inttoptr i64 %zero to ptr
  %pr = bitcast i64 1 to i64
  %pw = bitcast i64 2 to i64
  %prot64 = or i64 %pr, %pw
  %prot.p.low = icmp sge i64 %prot64, -2147483648
  %prot.p.high = icmp sle i64 %prot64, 2147483647
  %prot.p.fits = and i1 %prot.p.low, %prot.p.high
  %prot.p.bad = xor i1 %prot.p.fits, true
  br i1 %prot.p.bad, label %prot.p.trap, label %prot.p.ok
prot.p.trap:
  call void @rterr.int(i32 7)
  unreachable
prot.p.ok:
  %prot = trunc i64 %prot64 to i32
  %mp = bitcast i64 2 to i64
  %ma = bitcast i64 4096 to i64
  %flags64 = or i64 %mp, %ma
  %flags.p.low = icmp sge i64 %flags64, -2147483648
  %flags.p.high = icmp sle i64 %flags64, 2147483647
  %flags.p.fits = and i1 %flags.p.low, %flags.p.high
  %flags.p.bad = xor i1 %flags.p.fits, true
  br i1 %flags.p.bad, label %flags.p.trap, label %flags.p.ok
flags.p.trap:
  call void @rterr.int(i32 7)
  unreachable
flags.p.ok:
  %flags = trunc i64 %flags64 to i32
  %fd = bitcast i32 -1 to i32
  %r = call ptr (ptr, i64, i32, i32, i32, i64) @mmap(ptr %nul, i64 %len, i32 %prot, i32 %flags, i32 %fd, i64 %zero)
  %ri = ptrtoint ptr %r to i64
  %failed$2Ek = bitcast i64 -1 to i64
  %failed = icmp eq i64 %ri, %failed$2Ek
  br i1 %failed, label %bb.oom, label %bb.mapped
bb.oom:
  %oom$2Ec = bitcast ptr @str.2 to ptr
  %oom$2Ef = bitcast ptr @str.6 to ptr
  %oom$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %oom$2Ec, ptr %oom$2Ef)
  %oom$2Ez = bitcast i64 0 to i64
  ret i64 %oom$2Ez
bb.mapped:
  %low$2Ek = bitcast i64 16383 to i64
  %low = and i64 %ri, %low$2Ek
  %aligned$2Ek = bitcast i64 0 to i64
  %aligned = icmp eq i64 %low, %aligned$2Ek
  br i1 %aligned, label %bb.use, label %bb.remap
bb.remap:
  %u0 = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Eunmap(i64 %ri, i64 %len)
  %len2 = bitcast i64 1064960 to i64
  %r2 = call ptr (ptr, i64, i32, i32, i32, i64) @mmap(ptr %nul, i64 %len2, i32 %prot, i32 %flags, i32 %fd, i64 %zero)
  %r2i = ptrtoint ptr %r2 to i64
  %failed2$2Ek = bitcast i64 -1 to i64
  %failed2 = icmp eq i64 %r2i, %failed2$2Ek
  br i1 %failed2, label %bb.oom, label %bb.trim
bb.trim:
  %up$2Ek = bitcast i64 16383 to i64
  %up = add i64 %r2i, %up$2Ek
  %a$2Ek = bitcast i64 -16384 to i64
  %a = and i64 %up, %a$2Ek
  %head = sub i64 %a, %r2i
  %hz$2Ek = bitcast i64 0 to i64
  %hz = icmp eq i64 %head, %hz$2Ek
  br i1 %hz, label %bb.cuttail, label %bb.cuthead
bb.cuthead:
  %u1 = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Eunmap(i64 %r2i, i64 %head)
  br label %bb.cuttail
bb.cuttail:
  %tailAt = add i64 %a, %len
  %mapEnd = add i64 %r2i, %len2
  %tail = sub i64 %mapEnd, %tailAt
  %tz$2Ek = bitcast i64 0 to i64
  %tz = icmp eq i64 %tail, %tz$2Ek
  br i1 %tz, label %bb.use, label %bb.cut2
bb.cut2:
  %u2 = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Eunmap(i64 %tailAt, i64 %tail)
  br label %bb.use
bb.use:
  %base = phi i64 [ %ri, %bb.mapped ], [ %a, %bb.cuttail ], [ %a, %bb.cut2 ]
  %b1$2Ek = bitcast i64 16384 to i64
  %b1 = add i64 %base, %b1$2Ek
  %w1$2Eptr = inttoptr i64 %s to ptr
  %w1$2Eoff = bitcast i64 320 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %b1, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  %be = add i64 %base, %len
  %w2$2Eptr = inttoptr i64 %s to ptr
  %w2$2Eoff = bitcast i64 328 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %be, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  %pm$2Eby = bitcast i64 64 to i64
  %pm$2Eold$2Eptr = inttoptr i64 %s to ptr
  %pm$2Eold$2Eoff = bitcast i64 424 to i64
  %pm$2Eold.p.gep = getelementptr inbounds i8, ptr %pm$2Eold$2Eptr, i64 %pm$2Eold$2Eoff
  %pm$2Eold = load i64, ptr %pm$2Eold.p.gep
  %pm$2Enew = add i64 %pm$2Eold, %pm$2Eby
  %pm$2Eptr = inttoptr i64 %s to ptr
  %pm$2Eoff = bitcast i64 424 to i64
  %pm.p.gep = getelementptr inbounds i8, ptr %pm$2Eptr, i64 %pm$2Eoff
  store i64 %pm$2Enew, ptr %pm.p.gep
  %pm = bitcast i1 true to i1
  ret i64 %base
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EwidenHeap(i64 %lo, i64 %hi) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %hl$2Eptr = inttoptr i64 %s to ptr
  %hl$2Eoff = bitcast i64 288 to i64
  %hl.p.gep = getelementptr inbounds i8, ptr %hl$2Eptr, i64 %hl$2Eoff
  %hl = load i64, ptr %hl.p.gep
  %below$2Ea$2Eone = bitcast i64 1 to i64
  %below$2Ea$2Esh = bitcast i64 63 to i64
  %below$2Ea$2Emin.p.m = and i64 %below$2Ea$2Esh, 63
  %below$2Ea$2Emin = shl i64 %below$2Ea$2Eone, %below$2Ea$2Emin.p.m
  %below$2Ea = xor i64 %lo, %below$2Ea$2Emin
  %below$2Eb$2Eone = bitcast i64 1 to i64
  %below$2Eb$2Esh = bitcast i64 63 to i64
  %below$2Eb$2Emin.p.m = and i64 %below$2Eb$2Esh, 63
  %below$2Eb$2Emin = shl i64 %below$2Eb$2Eone, %below$2Eb$2Emin.p.m
  %below$2Eb = xor i64 %hl, %below$2Eb$2Emin
  %below = icmp slt i64 %below$2Ea, %below$2Eb
  br i1 %below, label %bb.setlo, label %bb.high
bb.setlo:
  %w1$2Eptr = inttoptr i64 %s to ptr
  %w1$2Eoff = bitcast i64 288 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %lo, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  br label %bb.high
bb.high:
  %hh$2Eptr = inttoptr i64 %s to ptr
  %hh$2Eoff = bitcast i64 296 to i64
  %hh.p.gep = getelementptr inbounds i8, ptr %hh$2Eptr, i64 %hh$2Eoff
  %hh = load i64, ptr %hh.p.gep
  %above$2Ea$2Eone = bitcast i64 1 to i64
  %above$2Ea$2Esh = bitcast i64 63 to i64
  %above$2Ea$2Emin.p.m = and i64 %above$2Ea$2Esh, 63
  %above$2Ea$2Emin = shl i64 %above$2Ea$2Eone, %above$2Ea$2Emin.p.m
  %above$2Ea = xor i64 %hh, %above$2Ea$2Emin
  %above$2Eb$2Eone = bitcast i64 1 to i64
  %above$2Eb$2Esh = bitcast i64 63 to i64
  %above$2Eb$2Emin.p.m = and i64 %above$2Eb$2Esh, 63
  %above$2Eb$2Emin = shl i64 %above$2Eb$2Eone, %above$2Eb$2Emin.p.m
  %above$2Eb = xor i64 %hi, %above$2Eb$2Emin
  %above = icmp slt i64 %above$2Ea, %above$2Eb
  br i1 %above, label %bb.sethi, label %bb.done
bb.sethi:
  %w2$2Eptr = inttoptr i64 %s to ptr
  %w2$2Eoff = bitcast i64 296 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %hi, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  %sethi$2Ez = bitcast i64 0 to i64
  ret i64 %sethi$2Ez
bb.done:
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EnewPage(i64 %sc) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %rs = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSetReserve()
  %pa$2Eby = bitcast i64 1 to i64
  %pa$2Eold$2Eptr = inttoptr i64 %s to ptr
  %pa$2Eold$2Eoff = bitcast i64 120 to i64
  %pa$2Eold.p.gep = getelementptr inbounds i8, ptr %pa$2Eold$2Eptr, i64 %pa$2Eold$2Eoff
  %pa$2Eold = load i64, ptr %pa$2Eold.p.gep
  %pa$2Enew = add i64 %pa$2Eold, %pa$2Eby
  %pa$2Eptr = inttoptr i64 %s to ptr
  %pa$2Eoff = bitcast i64 120 to i64
  %pa.p.gep = getelementptr inbounds i8, ptr %pa$2Eptr, i64 %pa$2Eoff
  store i64 %pa$2Enew, ptr %pa.p.gep
  %pa = bitcast i1 true to i1
  %cc$2Eptr = inttoptr i64 %s to ptr
  %cc$2Eoff = bitcast i64 216 to i64
  %cc.p.gep = getelementptr inbounds i8, ptr %cc$2Eptr, i64 %cc$2Eoff
  %cc = load i64, ptr %cc.p.gep
  %has$2Ek = bitcast i64 0 to i64
  %has = icmp sgt i64 %cc, %has$2Ek
  br i1 %has, label %bb.cached, label %bb.fresh
bb.cached:
  %cp$2Eptr = inttoptr i64 %s to ptr
  %cp$2Eoff = bitcast i64 208 to i64
  %cp.p.gep = getelementptr inbounds i8, ptr %cp$2Eptr, i64 %cp$2Eoff
  %cp = load i64, ptr %cp.p.gep
  %cnx$2Eptr = inttoptr i64 %cp to ptr
  %cnx$2Eoff = bitcast i64 0 to i64
  %cnx.p.gep = getelementptr inbounds i8, ptr %cnx$2Eptr, i64 %cnx$2Eoff
  %cnx = load i64, ptr %cnx.p.gep
  %w1$2Eptr = inttoptr i64 %s to ptr
  %w1$2Eoff = bitcast i64 208 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %cnx, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  %cc1$2Ek = bitcast i64 -1 to i64
  %cc1 = add i64 %cc, %cc1$2Ek
  %w2$2Eptr = inttoptr i64 %s to ptr
  %w2$2Eoff = bitcast i64 216 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %cc1, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  br label %bb.got
bb.fresh:
  %fp = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EfreshPage()
  br label %bb.got
bb.got:
  %p = phi i64 [ %cp, %bb.cached ], [ %fp, %bb.fresh ]
  %pp = inttoptr i64 %p to ptr
  %z32 = bitcast i32 0 to i32
  %hb = bitcast i64 328 to i64
  %ms = call ptr (ptr, i32, i64) @memset(ptr %pp, i32 %z32, i64 %hb)
  %sc2$2Ek = bitcast i64 2 to i64
  %sc2 = add i64 %sc, %sc2$2Ek
  %ss$2Ek = bitcast i64 8 to i64
  %ss = mul i64 %sc2, %ss$2Ek
  %wss$2Eptr = inttoptr i64 %p to ptr
  %wss$2Eoff = bitcast i64 24 to i64
  %wss.p.gep = getelementptr inbounds i8, ptr %wss$2Eptr, i64 %wss$2Eoff
  store i64 %ss, ptr %wss.p.gep
  %wss = bitcast i1 true to i1
  %room = bitcast i64 15872 to i64
  %cnt.p.zero = icmp eq i64 %ss, 0
  %cnt.p.min = icmp eq i64 %room, -9223372036854775808
  %cnt.p.neg = icmp eq i64 %ss, -1
  %cnt.p.over = and i1 %cnt.p.min, %cnt.p.neg
  %cnt.p.bad = or i1 %cnt.p.zero, %cnt.p.over
  br i1 %cnt.p.bad, label %cnt.p.trap, label %cnt.p.ok
cnt.p.trap:
  call void @llvm.trap()
  unreachable
cnt.p.ok:
  %cnt = sdiv i64 %room, %ss
  %wcnt$2Eptr = inttoptr i64 %p to ptr
  %wcnt$2Eoff = bitcast i64 32 to i64
  %wcnt.p.gep = getelementptr inbounds i8, ptr %wcnt$2Eptr, i64 %wcnt$2Eoff
  store i64 %cnt, ptr %wcnt.p.gep
  %wcnt = bitcast i1 true to i1
  %two32 = bitcast i64 4294967296 to i64
  %rq.p.zero = icmp eq i64 %ss, 0
  %rq.p.min = icmp eq i64 %two32, -9223372036854775808
  %rq.p.neg = icmp eq i64 %ss, -1
  %rq.p.over = and i1 %rq.p.min, %rq.p.neg
  %rq.p.bad = or i1 %rq.p.zero, %rq.p.over
  br i1 %rq.p.bad, label %rq.p.trap, label %rq.p.ok
rq.p.trap:
  call void @llvm.trap()
  unreachable
rq.p.ok:
  %rq = sdiv i64 %two32, %ss
  %rc$2Ek = bitcast i64 1 to i64
  %rc = add i64 %rq, %rc$2Ek
  %wrc$2Eptr = inttoptr i64 %p to ptr
  %wrc$2Eoff = bitcast i64 16 to i64
  %wrc.p.gep = getelementptr inbounds i8, ptr %wrc$2Eptr, i64 %wrc$2Eoff
  store i64 %rc, ptr %wrc.p.gep
  %wrc = bitcast i1 true to i1
  %put = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSetPut(i64 %p)
  %pe$2Ek = bitcast i64 16384 to i64
  %pe = add i64 %p, %pe$2Ek
  %wh = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EwidenHeap(i64 %p, i64 %pe)
  ret i64 %p
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EfreePage(i64 %p) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %d = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSetDel(i64 %p)
  %pf$2Eby = bitcast i64 1 to i64
  %pf$2Eold$2Eptr = inttoptr i64 %s to ptr
  %pf$2Eold$2Eoff = bitcast i64 112 to i64
  %pf$2Eold.p.gep = getelementptr inbounds i8, ptr %pf$2Eold$2Eptr, i64 %pf$2Eold$2Eoff
  %pf$2Eold = load i64, ptr %pf$2Eold.p.gep
  %pf$2Enew = add i64 %pf$2Eold, %pf$2Eby
  %pf$2Eptr = inttoptr i64 %s to ptr
  %pf$2Eoff = bitcast i64 112 to i64
  %pf.p.gep = getelementptr inbounds i8, ptr %pf$2Eptr, i64 %pf$2Eoff
  store i64 %pf$2Enew, ptr %pf.p.gep
  %pf = bitcast i1 true to i1
  %cp$2Eptr = inttoptr i64 %s to ptr
  %cp$2Eoff = bitcast i64 208 to i64
  %cp.p.gep = getelementptr inbounds i8, ptr %cp$2Eptr, i64 %cp$2Eoff
  %cp = load i64, ptr %cp.p.gep
  %w0$2Eptr = inttoptr i64 %p to ptr
  %w0$2Eoff = bitcast i64 0 to i64
  %w0.p.gep = getelementptr inbounds i8, ptr %w0$2Eptr, i64 %w0$2Eoff
  store i64 %cp, ptr %w0.p.gep
  %w0 = bitcast i1 true to i1
  %w1$2Eptr = inttoptr i64 %s to ptr
  %w1$2Eoff = bitcast i64 208 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %p, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  %cc$2Eptr = inttoptr i64 %s to ptr
  %cc$2Eoff = bitcast i64 216 to i64
  %cc.p.gep = getelementptr inbounds i8, ptr %cc$2Eptr, i64 %cc$2Eoff
  %cc = load i64, ptr %cc.p.gep
  %cc1$2Ek = bitcast i64 1 to i64
  %cc1 = add i64 %cc, %cc1$2Ek
  %w2$2Eptr = inttoptr i64 %s to ptr
  %w2$2Eoff = bitcast i64 216 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %cc1, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  %entry$2Ez = bitcast i64 0 to i64
  ret i64 %entry$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EreleaseCache(i64 %limit) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %cc$2Eptr = inttoptr i64 %s to ptr
  %cc$2Eoff = bitcast i64 216 to i64
  %cc.p.gep = getelementptr inbounds i8, ptr %cc$2Eptr, i64 %cc$2Eoff
  %cc = load i64, ptr %cc.p.gep
  %over$2Ea$2Eone = bitcast i64 1 to i64
  %over$2Ea$2Esh = bitcast i64 63 to i64
  %over$2Ea$2Emin.p.m = and i64 %over$2Ea$2Esh, 63
  %over$2Ea$2Emin = shl i64 %over$2Ea$2Eone, %over$2Ea$2Emin.p.m
  %over$2Ea = xor i64 %limit, %over$2Ea$2Emin
  %over$2Eb$2Eone = bitcast i64 1 to i64
  %over$2Eb$2Esh = bitcast i64 63 to i64
  %over$2Eb$2Emin.p.m = and i64 %over$2Eb$2Esh, 63
  %over$2Eb$2Emin = shl i64 %over$2Eb$2Eone, %over$2Eb$2Emin.p.m
  %over$2Eb = xor i64 %cc, %over$2Eb$2Emin
  %over = icmp slt i64 %over$2Ea, %over$2Eb
  br i1 %over, label %bb.size, label %bb.done
bb.size:
  %n = sub i64 %cc, %limit
  %cap$2Eptr = inttoptr i64 %s to ptr
  %cap$2Eoff = bitcast i64 384 to i64
  %cap.p.gep = getelementptr inbounds i8, ptr %cap$2Eptr, i64 %cap$2Eoff
  %cap = load i64, ptr %cap.p.gep
  %small$2Ea$2Eone = bitcast i64 1 to i64
  %small$2Ea$2Esh = bitcast i64 63 to i64
  %small$2Ea$2Emin.p.m = and i64 %small$2Ea$2Esh, 63
  %small$2Ea$2Emin = shl i64 %small$2Ea$2Eone, %small$2Ea$2Emin.p.m
  %small$2Ea = xor i64 %cap, %small$2Ea$2Emin
  %small$2Eb$2Eone = bitcast i64 1 to i64
  %small$2Eb$2Esh = bitcast i64 63 to i64
  %small$2Eb$2Emin.p.m = and i64 %small$2Eb$2Esh, 63
  %small$2Eb$2Emin = shl i64 %small$2Eb$2Eone, %small$2Eb$2Emin.p.m
  %small$2Eb = xor i64 %n, %small$2Eb$2Emin
  %small = icmp slt i64 %small$2Ea, %small$2Eb
  br i1 %small, label %bb.grow, label %bb.fill
bb.grow:
  %bytes$2Ek = bitcast i64 8 to i64
  %bytes = mul i64 %n, %bytes$2Ek
  %old$2Eptr = inttoptr i64 %s to ptr
  %old$2Eoff = bitcast i64 376 to i64
  %old.p.gep = getelementptr inbounds i8, ptr %old$2Eptr, i64 %old$2Eoff
  %old = load i64, ptr %old.p.gep
  %oldp = inttoptr i64 %old to ptr
  %r = call ptr (ptr, i64) @realloc(ptr %oldp, i64 %bytes)
  %ri = ptrtoint ptr %r to i64
  %dead$2Ek = bitcast i64 0 to i64
  %dead = icmp eq i64 %ri, %dead$2Ek
  br i1 %dead, label %bb.oom, label %bb.grown
bb.oom:
  %oom$2Ec = bitcast ptr @str.2 to ptr
  %oom$2Ef = bitcast ptr @str.30 to ptr
  %oom$2Ebi = call tailcc i64 @gcAslFailBuf()
  %oom$2Eb = inttoptr i64 %oom$2Ebi to ptr
  %oom$2Ecap = bitcast i64 1024 to i64
  %oom$2En = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %oom$2Eb, i64 %oom$2Ecap, ptr %oom$2Ef, i64 %n)
  %oom$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %oom$2Ec, ptr %oom$2Eb)
  %oom$2Ez = bitcast i64 0 to i64
  ret i64 %oom$2Ez
bb.grown:
  %w1$2Eptr = inttoptr i64 %s to ptr
  %w1$2Eoff = bitcast i64 376 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %ri, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  %w2$2Eptr = inttoptr i64 %s to ptr
  %w2$2Eoff = bitcast i64 384 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %n, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  br label %bb.fill
bb.fill:
  %buf$2Eptr = inttoptr i64 %s to ptr
  %buf$2Eoff = bitcast i64 376 to i64
  %buf.p.gep = getelementptr inbounds i8, ptr %buf$2Eptr, i64 %buf$2Eoff
  %buf = load i64, ptr %buf.p.gep
  %head$2Eptr = inttoptr i64 %s to ptr
  %head$2Eoff = bitcast i64 208 to i64
  %head.p.gep = getelementptr inbounds i8, ptr %head$2Eptr, i64 %head$2Eoff
  %head = load i64, ptr %head.p.gep
  %i0 = bitcast i64 0 to i64
  br label %bb.floop
bb.floop:
  %i = phi i64 [ %i0, %bb.fill ], [ %i1, %bb.fbody ]
  %p = phi i64 [ %head, %bb.fill ], [ %nx, %bb.fbody ]
  %more = icmp slt i64 %i, %n
  br i1 %more, label %bb.fbody, label %bb.sort
bb.fbody:
  %at$2Em$2Ek = bitcast i64 8 to i64
  %at$2Em = mul i64 %i, %at$2Em$2Ek
  %at = add i64 %buf, %at$2Em
  %w3$2Eptr = inttoptr i64 %at to ptr
  %w3$2Eoff = bitcast i64 0 to i64
  %w3.p.gep = getelementptr inbounds i8, ptr %w3$2Eptr, i64 %w3$2Eoff
  store i64 %p, ptr %w3.p.gep
  %w3 = bitcast i1 true to i1
  %nx$2Eptr = inttoptr i64 %p to ptr
  %nx$2Eoff = bitcast i64 0 to i64
  %nx.p.gep = getelementptr inbounds i8, ptr %nx$2Eptr, i64 %nx$2Eoff
  %nx = load i64, ptr %nx.p.gep
  %i1$2Ek = bitcast i64 1 to i64
  %i1 = add i64 %i, %i1$2Ek
  br label %bb.floop
bb.sort:
  %w4$2Eptr = inttoptr i64 %s to ptr
  %w4$2Eoff = bitcast i64 208 to i64
  %w4.p.gep = getelementptr inbounds i8, ptr %w4$2Eptr, i64 %w4$2Eoff
  store i64 %p, ptr %w4.p.gep
  %w4 = bitcast i1 true to i1
  %w5$2Eptr = inttoptr i64 %s to ptr
  %w5$2Eoff = bitcast i64 216 to i64
  %w5.p.gep = getelementptr inbounds i8, ptr %w5$2Eptr, i64 %w5$2Eoff
  store i64 %limit, ptr %w5.p.gep
  %w5 = bitcast i1 true to i1
  %q = call tailcc i64 @gcAslSortLarge(i64 %buf, i64 %n)
  %pu$2Eold$2Eptr = inttoptr i64 %s to ptr
  %pu$2Eold$2Eoff = bitcast i64 432 to i64
  %pu$2Eold.p.gep = getelementptr inbounds i8, ptr %pu$2Eold$2Eptr, i64 %pu$2Eold$2Eoff
  %pu$2Eold = load i64, ptr %pu$2Eold.p.gep
  %pu$2Enew = add i64 %pu$2Eold, %n
  %pu$2Eptr = inttoptr i64 %s to ptr
  %pu$2Eoff = bitcast i64 432 to i64
  %pu.p.gep = getelementptr inbounds i8, ptr %pu$2Eptr, i64 %pu$2Eoff
  store i64 %pu$2Enew, ptr %pu.p.gep
  %pu = bitcast i1 true to i1
  %first$2Eptr = inttoptr i64 %buf to ptr
  %first$2Eoff = bitcast i64 0 to i64
  %first.p.gep = getelementptr inbounds i8, ptr %first$2Eptr, i64 %first$2Eoff
  %first = load i64, ptr %first.p.gep
  %j0 = bitcast i64 1 to i64
  %ps = bitcast i64 16384 to i64
  br label %bb.rloop
bb.rloop:
  %j = phi i64 [ %j0, %bb.sort ], [ %j1, %bb.extend ], [ %j1, %bb.cut ]
  %start = phi i64 [ %first, %bb.sort ], [ %start, %bb.extend ], [ %pg, %bb.cut ]
  %len = phi i64 [ %ps, %bb.sort ], [ %len1, %bb.extend ], [ %ps, %bb.cut ]
  %rmore = icmp slt i64 %j, %n
  br i1 %rmore, label %bb.rbody, label %bb.last
bb.rbody:
  %jat$2Em$2Ek = bitcast i64 8 to i64
  %jat$2Em = mul i64 %j, %jat$2Em$2Ek
  %jat = add i64 %buf, %jat$2Em
  %pg$2Eptr = inttoptr i64 %jat to ptr
  %pg$2Eoff = bitcast i64 0 to i64
  %pg.p.gep = getelementptr inbounds i8, ptr %pg$2Eptr, i64 %pg$2Eoff
  %pg = load i64, ptr %pg.p.gep
  %end = add i64 %start, %len
  %adjacent = icmp eq i64 %pg, %end
  %j1$2Ek = bitcast i64 1 to i64
  %j1 = add i64 %j, %j1$2Ek
  br i1 %adjacent, label %bb.extend, label %bb.cut
bb.extend:
  %len1$2Ek = bitcast i64 16384 to i64
  %len1 = add i64 %len, %len1$2Ek
  br label %bb.rloop
bb.cut:
  %u = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Eunmap(i64 %start, i64 %len)
  %uc$2Eby = bitcast i64 1 to i64
  %uc$2Eold$2Eptr = inttoptr i64 %s to ptr
  %uc$2Eold$2Eoff = bitcast i64 440 to i64
  %uc$2Eold.p.gep = getelementptr inbounds i8, ptr %uc$2Eold$2Eptr, i64 %uc$2Eold$2Eoff
  %uc$2Eold = load i64, ptr %uc$2Eold.p.gep
  %uc$2Enew = add i64 %uc$2Eold, %uc$2Eby
  %uc$2Eptr = inttoptr i64 %s to ptr
  %uc$2Eoff = bitcast i64 440 to i64
  %uc.p.gep = getelementptr inbounds i8, ptr %uc$2Eptr, i64 %uc$2Eoff
  store i64 %uc$2Enew, ptr %uc.p.gep
  %uc = bitcast i1 true to i1
  br label %bb.rloop
bb.last:
  %ul = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Eunmap(i64 %start, i64 %len)
  %ucl$2Eby = bitcast i64 1 to i64
  %ucl$2Eold$2Eptr = inttoptr i64 %s to ptr
  %ucl$2Eold$2Eoff = bitcast i64 440 to i64
  %ucl$2Eold.p.gep = getelementptr inbounds i8, ptr %ucl$2Eold$2Eptr, i64 %ucl$2Eold$2Eoff
  %ucl$2Eold = load i64, ptr %ucl$2Eold.p.gep
  %ucl$2Enew = add i64 %ucl$2Eold, %ucl$2Eby
  %ucl$2Eptr = inttoptr i64 %s to ptr
  %ucl$2Eoff = bitcast i64 440 to i64
  %ucl.p.gep = getelementptr inbounds i8, ptr %ucl$2Eptr, i64 %ucl$2Eoff
  store i64 %ucl$2Enew, ptr %ucl.p.gep
  %ucl = bitcast i1 true to i1
  %last$2Ez = bitcast i64 0 to i64
  ret i64 %last$2Ez
bb.done:
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpoolAlloc(i64 %sc, i64 %ss) alwaysinline {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %ca$2Em$2Ek = bitcast i64 24 to i64
  %ca$2Em = mul i64 %sc, %ca$2Em$2Ek
  %ca$2Ea = add i64 %s, %ca$2Em
  %ca$2Ek = bitcast i64 512 to i64
  %ca = add i64 %ca$2Ea, %ca$2Ek
  br label %bb.top
bb.top:
  %fp$2Eptr = inttoptr i64 %ca to ptr
  %fp$2Eoff = bitcast i64 8 to i64
  %fp.p.gep = getelementptr inbounds i8, ptr %fp$2Eptr, i64 %fp$2Eoff
  %fp = load i64, ptr %fp.p.gep
  %has$2Ek = bitcast i64 0 to i64
  %has = icmp ne i64 %fp, %has$2Ek
  br i1 %has, label %bb.fromFree, label %bb.fromBump
bb.fromFree:
  %lim$2Eptr = inttoptr i64 %fp to ptr
  %lim$2Eoff = bitcast i64 56 to i64
  %lim.p.gep = getelementptr inbounds i8, ptr %lim$2Eptr, i64 %lim$2Eoff
  %lim = load i64, ptr %lim.p.gep
  %cur$2Eptr = inttoptr i64 %fp to ptr
  %cur$2Eoff = bitcast i64 64 to i64
  %cur.p.gep = getelementptr inbounds i8, ptr %cur$2Eptr, i64 %cur$2Eoff
  %cur = load i64, ptr %cur.p.gep
  %tw$2Ek = bitcast i64 6 to i64
  %tw.p.m = and i64 %tw$2Ek, 63
  %tw = lshr i64 %lim, %tw.p.m
  %tb$2Ek = bitcast i64 63 to i64
  %tb = and i64 %lim, %tb$2Ek
  %one = bitcast i64 1 to i64
  %tp.p.m = and i64 %tb, 63
  %tp = shl i64 %one, %tp.p.m
  %tmask$2Ek = bitcast i64 -1 to i64
  %tmask = add i64 %tp, %tmask$2Ek
  %all = bitcast i64 -1 to i64
  br label %bb.scan
bb.scan:
  %c = phi i64 [ %cur, %bb.fromFree ], [ %c1, %bb.down ]
  %co$2Ek = bitcast i64 3 to i64
  %co.p.m = and i64 %co$2Ek, 63
  %co = shl i64 %c, %co.p.m
  %cb = add i64 %fp, %co
  %w$2Eptr = inttoptr i64 %cb to ptr
  %w$2Eoff = bitcast i64 72 to i64
  %w.p.gep = getelementptr inbounds i8, ptr %w$2Eptr, i64 %w$2Eoff
  %w = load i64, ptr %w.p.gep
  %below$2Ea$2Eone = bitcast i64 1 to i64
  %below$2Ea$2Esh = bitcast i64 63 to i64
  %below$2Ea$2Emin.p.m = and i64 %below$2Ea$2Esh, 63
  %below$2Ea$2Emin = shl i64 %below$2Ea$2Eone, %below$2Ea$2Emin.p.m
  %below$2Ea = xor i64 %c, %below$2Ea$2Emin
  %below$2Eb$2Eone = bitcast i64 1 to i64
  %below$2Eb$2Esh = bitcast i64 63 to i64
  %below$2Eb$2Emin.p.m = and i64 %below$2Eb$2Esh, 63
  %below$2Eb$2Emin = shl i64 %below$2Eb$2Eone, %below$2Eb$2Emin.p.m
  %below$2Eb = xor i64 %tw, %below$2Eb$2Emin
  %below = icmp slt i64 %below$2Ea, %below$2Eb
  br i1 %below, label %bb.scan.e0, label %bb.scan.e1
bb.scan.e0:
  br label %bb.masked
bb.scan.e1:
  br label %bb.masked
bb.masked:
  %m = phi i64 [ %all, %bb.scan.e0 ], [ %tmask, %bb.scan.e1 ]
  %inv0 = xor i64 %w, %all
  %inv = and i64 %inv0, %m
  %none$2Ek = bitcast i64 0 to i64
  %none = icmp eq i64 %inv, %none$2Ek
  br i1 %none, label %bb.next, label %bb.take
bb.next:
  %bottom$2Ek = bitcast i64 0 to i64
  %bottom = icmp eq i64 %c, %bottom$2Ek
  br i1 %bottom, label %bb.unlink, label %bb.down
bb.down:
  %c1$2Ek = bitcast i64 -1 to i64
  %c1 = add i64 %c, %c1$2Ek
  %wc$2Eptr = inttoptr i64 %fp to ptr
  %wc$2Eoff = bitcast i64 64 to i64
  %wc.p.gep = getelementptr inbounds i8, ptr %wc$2Eptr, i64 %wc$2Eoff
  store i64 %c1, ptr %wc.p.gep
  %wc = bitcast i1 true to i1
  br label %bb.scan
bb.unlink:
  %nf$2Eptr = inttoptr i64 %fp to ptr
  %nf$2Eoff = bitcast i64 8 to i64
  %nf.p.gep = getelementptr inbounds i8, ptr %nf$2Eptr, i64 %nf$2Eoff
  %nf = load i64, ptr %nf.p.gep
  %w2$2Eptr = inttoptr i64 %ca to ptr
  %w2$2Eoff = bitcast i64 8 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %nf, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  %w3$2Ev = bitcast i64 0 to i64
  %w3$2Eptr = inttoptr i64 %fp to ptr
  %w3$2Eoff = bitcast i64 8 to i64
  %w3.p.gep = getelementptr inbounds i8, ptr %w3$2Eptr, i64 %w3$2Eoff
  store i64 %w3$2Ev, ptr %w3.p.gep
  %w3 = bitcast i1 true to i1
  br label %bb.top
bb.take:
  %lz = call tailcc i64 @gcAslClz(i64 %inv)
  %k63 = bitcast i64 63 to i64
  %hb = sub i64 %k63, %lz
  %cw$2Ek = bitcast i64 6 to i64
  %cw.p.m = and i64 %cw$2Ek, 63
  %cw = shl i64 %c, %cw.p.m
  %fi = add i64 %cw, %hb
  br label %bb.have
bb.fromBump:
  %ap$2Eptr = inttoptr i64 %ca to ptr
  %ap$2Eoff = bitcast i64 16 to i64
  %ap.p.gep = getelementptr inbounds i8, ptr %ap$2Eptr, i64 %ap$2Eoff
  %ap = load i64, ptr %ap.p.gep
  %noActive$2Ek = bitcast i64 0 to i64
  %noActive = icmp eq i64 %ap, %noActive$2Ek
  br i1 %noActive, label %bb.fresh, label %bb.room
bb.room:
  %bi$2Eptr = inttoptr i64 %ap to ptr
  %bi$2Eoff = bitcast i64 56 to i64
  %bi.p.gep = getelementptr inbounds i8, ptr %bi$2Eptr, i64 %bi$2Eoff
  %bi = load i64, ptr %bi.p.gep
  %cnt$2Eptr = inttoptr i64 %ap to ptr
  %cnt$2Eoff = bitcast i64 32 to i64
  %cnt.p.gep = getelementptr inbounds i8, ptr %cnt$2Eptr, i64 %cnt$2Eoff
  %cnt = load i64, ptr %cnt.p.gep
  %fits = icmp slt i64 %bi, %cnt
  br i1 %fits, label %bb.bumpIt, label %bb.fresh
bb.fresh:
  %np = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EnewPage(i64 %sc)
  %head$2Eptr = inttoptr i64 %ca to ptr
  %head$2Eoff = bitcast i64 0 to i64
  %head.p.gep = getelementptr inbounds i8, ptr %head$2Eptr, i64 %head$2Eoff
  %head = load i64, ptr %head.p.gep
  %w4$2Eptr = inttoptr i64 %np to ptr
  %w4$2Eoff = bitcast i64 0 to i64
  %w4.p.gep = getelementptr inbounds i8, ptr %w4$2Eptr, i64 %w4$2Eoff
  store i64 %head, ptr %w4.p.gep
  %w4 = bitcast i1 true to i1
  %w5$2Eptr = inttoptr i64 %ca to ptr
  %w5$2Eoff = bitcast i64 0 to i64
  %w5.p.gep = getelementptr inbounds i8, ptr %w5$2Eptr, i64 %w5$2Eoff
  store i64 %np, ptr %w5.p.gep
  %w5 = bitcast i1 true to i1
  %w6$2Eptr = inttoptr i64 %ca to ptr
  %w6$2Eoff = bitcast i64 16 to i64
  %w6.p.gep = getelementptr inbounds i8, ptr %w6$2Eptr, i64 %w6$2Eoff
  store i64 %np, ptr %w6.p.gep
  %w6 = bitcast i1 true to i1
  br label %bb.bumpIt
bb.bumpIt:
  %bp = phi i64 [ %ap, %bb.room ], [ %np, %bb.fresh ]
  %b$2Eptr = inttoptr i64 %bp to ptr
  %b$2Eoff = bitcast i64 56 to i64
  %b.p.gep = getelementptr inbounds i8, ptr %b$2Eptr, i64 %b$2Eoff
  %b = load i64, ptr %b.p.gep
  %b1$2Ek = bitcast i64 1 to i64
  %b1 = add i64 %b, %b1$2Ek
  %w7$2Eptr = inttoptr i64 %bp to ptr
  %w7$2Eoff = bitcast i64 56 to i64
  %w7.p.gep = getelementptr inbounds i8, ptr %w7$2Eptr, i64 %w7$2Eoff
  store i64 %b1, ptr %w7.p.gep
  %w7 = bitcast i1 true to i1
  br label %bb.have
bb.have:
  %hp = phi i64 [ %fp, %bb.take ], [ %bp, %bb.bumpIt ]
  %idx = phi i64 [ %fi, %bb.take ], [ %b, %bb.bumpIt ]
  %word$2Ek = bitcast i64 6 to i64
  %word.p.m = and i64 %word$2Ek, 63
  %word = lshr i64 %idx, %word.p.m
  %wo$2Ek = bitcast i64 3 to i64
  %wo.p.m = and i64 %wo$2Ek, 63
  %wo = shl i64 %word, %wo.p.m
  %wb = add i64 %hp, %wo
  %wat$2Ek = bitcast i64 72 to i64
  %wat = add i64 %wb, %wat$2Ek
  %bitn$2Ek = bitcast i64 63 to i64
  %bitn = and i64 %idx, %bitn$2Ek
  %hone = bitcast i64 1 to i64
  %bit.p.m = and i64 %bitn, 63
  %bit = shl i64 %hone, %bit.p.m
  %wv$2Eptr = inttoptr i64 %wat to ptr
  %wv$2Eoff = bitcast i64 0 to i64
  %wv.p.gep = getelementptr inbounds i8, ptr %wv$2Eptr, i64 %wv$2Eoff
  %wv = load i64, ptr %wv.p.gep
  %wv1 = or i64 %wv, %bit
  %w8$2Eptr = inttoptr i64 %wat to ptr
  %w8$2Eoff = bitcast i64 0 to i64
  %w8.p.gep = getelementptr inbounds i8, ptr %w8$2Eptr, i64 %w8$2Eoff
  store i64 %wv1, ptr %w8.p.gep
  %w8 = bitcast i1 true to i1
  %ac$2Eptr = inttoptr i64 %hp to ptr
  %ac$2Eoff = bitcast i64 40 to i64
  %ac.p.gep = getelementptr inbounds i8, ptr %ac$2Eptr, i64 %ac$2Eoff
  %ac = load i64, ptr %ac.p.gep
  %ac1$2Ek = bitcast i64 1 to i64
  %ac1 = add i64 %ac, %ac1$2Ek
  %w9$2Eptr = inttoptr i64 %hp to ptr
  %w9$2Eoff = bitcast i64 40 to i64
  %w9.p.gep = getelementptr inbounds i8, ptr %w9$2Eptr, i64 %w9$2Eoff
  store i64 %ac1, ptr %w9.p.gep
  %w9 = bitcast i1 true to i1
  %off = mul i64 %idx, %ss
  %first = add i64 %hp, %off
  %hs$2Ek = bitcast i64 512 to i64
  %hs = add i64 %first, %hs$2Ek
  ret i64 %hs
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Ealloc(i64 %type, i64 %bytes) {
bb.entry:
  %none = bitcast i64 0 to i64
  br label %bb.check
bb.check:
  %s = call tailcc i64 @gcAslState()
  %stress$2Eptr = inttoptr i64 %s to ptr
  %stress$2Eoff = bitcast i64 40 to i64
  %stress.p.gep = getelementptr inbounds i8, ptr %stress$2Eptr, i64 %stress$2Eoff
  %stress = load i64, ptr %stress.p.gep
  %al$2Eptr = inttoptr i64 %s to ptr
  %al$2Eoff = bitcast i64 0 to i64
  %al.p.gep = getelementptr inbounds i8, ptr %al$2Eptr, i64 %al$2Eoff
  %al = load i64, ptr %al.p.gep
  %al2 = add i64 %al, %none
  %th$2Eptr = inttoptr i64 %s to ptr
  %th$2Eoff = bitcast i64 8 to i64
  %th.p.gep = getelementptr inbounds i8, ptr %th$2Eptr, i64 %th$2Eoff
  %th = load i64, ptr %th.p.gep
  %over$2Ea$2Eone = bitcast i64 1 to i64
  %over$2Ea$2Esh = bitcast i64 63 to i64
  %over$2Ea$2Emin.p.m = and i64 %over$2Ea$2Esh, 63
  %over$2Ea$2Emin = shl i64 %over$2Ea$2Eone, %over$2Ea$2Emin.p.m
  %over$2Ea = xor i64 %th, %over$2Ea$2Emin
  %over$2Eb$2Eone = bitcast i64 1 to i64
  %over$2Eb$2Esh = bitcast i64 63 to i64
  %over$2Eb$2Emin.p.m = and i64 %over$2Eb$2Esh, 63
  %over$2Eb$2Emin = shl i64 %over$2Eb$2Eone, %over$2Eb$2Emin.p.m
  %over$2Eb = xor i64 %al2, %over$2Eb$2Emin
  %over = icmp slt i64 %over$2Ea, %over$2Eb
  %st1$2Ek = bitcast i64 0 to i64
  %st1 = icmp ne i64 %stress, %st1$2Ek
  %need = or i1 %st1, %over
  br i1 %need, label %bb.collect, label %bb.sized
bb.collect:
  %gc = call tailcc i64 @gcAslCollect()
  br label %bb.sized
bb.sized:
  %max = bitcast i64 512 to i64
  %big$2Ea$2Eone = bitcast i64 1 to i64
  %big$2Ea$2Esh = bitcast i64 63 to i64
  %big$2Ea$2Emin.p.m = and i64 %big$2Ea$2Esh, 63
  %big$2Ea$2Emin = shl i64 %big$2Ea$2Eone, %big$2Ea$2Emin.p.m
  %big$2Ea = xor i64 %max, %big$2Ea$2Emin
  %big$2Eb$2Eone = bitcast i64 1 to i64
  %big$2Eb$2Esh = bitcast i64 63 to i64
  %big$2Eb$2Emin.p.m = and i64 %big$2Eb$2Esh, 63
  %big$2Eb$2Emin = shl i64 %big$2Eb$2Eone, %big$2Eb$2Emin.p.m
  %big$2Eb = xor i64 %bytes, %big$2Eb$2Emin
  %big = icmp slt i64 %big$2Ea, %big$2Eb
  %arr$2Ek = bitcast i64 6 to i64
  %arr = icmp eq i64 %type, %arr$2Ek
  %hnd$2Ek = bitcast i64 7 to i64
  %hnd = icmp eq i64 %type, %hnd$2Ek
  %o1 = or i1 %big, %arr
  %large = or i1 %o1, %hnd
  br i1 %large, label %bb.large, label %bb.small
bb.large:
  %lo = musttail call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EallocLarge(i64 %type, i64 %bytes)
  ret i64 %lo
bb.small:
  %tiny$2Ek = bitcast i64 16 to i64
  %tiny = icmp slt i64 %bytes, %tiny$2Ek
  %sixteen = bitcast i64 16 to i64
  br i1 %tiny, label %bb.small.e0, label %bb.small.e1
bb.small.e0:
  br label %bb.fit
bb.small.e1:
  br label %bb.fit
bb.fit:
  %b = phi i64 [ %sixteen, %bb.small.e0 ], [ %bytes, %bb.small.e1 ]
  %b7$2Ek = bitcast i64 7 to i64
  %b7 = add i64 %b, %b7$2Ek
  %b8$2Ek = bitcast i64 3 to i64
  %b8.p.m = and i64 %b8$2Ek, 63
  %b8 = lshr i64 %b7, %b8.p.m
  %sc$2Ek = bitcast i64 -2 to i64
  %sc = add i64 %b8, %sc$2Ek
  %sc2$2Ek = bitcast i64 2 to i64
  %sc2 = add i64 %sc, %sc2$2Ek
  %ss$2Ek = bitcast i64 8 to i64
  %ss = mul i64 %sc2, %ss$2Ek
  %o = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpoolAlloc(i64 %sc, i64 %ss)
  %op = inttoptr i64 %o to ptr
  %z32 = bitcast i32 0 to i32
  %ms = call ptr (ptr, i32, i64) @memset(ptr %op, i32 %z32, i64 %ss)
  %ty$2Ek = bitcast i64 32 to i64
  %ty.p.m = and i64 %ty$2Ek, 63
  %ty = shl i64 %type, %ty.p.m
  %cls$2Ek = bitcast i64 56 to i64
  %cls.p.m = and i64 %cls$2Ek, 63
  %cls = shl i64 %sc, %cls.p.m
  %h1 = or i64 %bytes, %ty
  %h = or i64 %h1, %cls
  %wh$2Eptr = inttoptr i64 %o to ptr
  %wh$2Eoff = bitcast i64 0 to i64
  %wh.p.gep = getelementptr inbounds i8, ptr %wh$2Eptr, i64 %wh$2Eoff
  store i64 %h, ptr %wh.p.gep
  %wh = bitcast i1 true to i1
  %n$2Ea$2Eold$2Eptr = inttoptr i64 %s to ptr
  %n$2Ea$2Eold$2Eoff = bitcast i64 0 to i64
  %n$2Ea$2Eold.p.gep = getelementptr inbounds i8, ptr %n$2Ea$2Eold$2Eptr, i64 %n$2Ea$2Eold$2Eoff
  %n$2Ea$2Eold = load i64, ptr %n$2Ea$2Eold.p.gep
  %n$2Ea$2Enew = add i64 %n$2Ea$2Eold, %bytes
  %n$2Ea$2Eptr = inttoptr i64 %s to ptr
  %n$2Ea$2Eoff = bitcast i64 0 to i64
  %n$2Ea.p.gep = getelementptr inbounds i8, ptr %n$2Ea$2Eptr, i64 %n$2Ea$2Eoff
  store i64 %n$2Ea$2Enew, ptr %n$2Ea.p.gep
  %n$2Ea = bitcast i1 true to i1
  %n$2Eo$2Eby = bitcast i64 1 to i64
  %n$2Eo$2Eold$2Eptr = inttoptr i64 %s to ptr
  %n$2Eo$2Eold$2Eoff = bitcast i64 72 to i64
  %n$2Eo$2Eold.p.gep = getelementptr inbounds i8, ptr %n$2Eo$2Eold$2Eptr, i64 %n$2Eo$2Eold$2Eoff
  %n$2Eo$2Eold = load i64, ptr %n$2Eo$2Eold.p.gep
  %n$2Eo$2Enew = add i64 %n$2Eo$2Eold, %n$2Eo$2Eby
  %n$2Eo$2Eptr = inttoptr i64 %s to ptr
  %n$2Eo$2Eoff = bitcast i64 72 to i64
  %n$2Eo.p.gep = getelementptr inbounds i8, ptr %n$2Eo$2Eptr, i64 %n$2Eo$2Eoff
  store i64 %n$2Eo$2Enew, ptr %n$2Eo.p.gep
  %n$2Eo = bitcast i1 true to i1
  %n$2Eb$2Eold$2Eptr = inttoptr i64 %s to ptr
  %n$2Eb$2Eold$2Eoff = bitcast i64 88 to i64
  %n$2Eb$2Eold.p.gep = getelementptr inbounds i8, ptr %n$2Eb$2Eold$2Eptr, i64 %n$2Eb$2Eold$2Eoff
  %n$2Eb$2Eold = load i64, ptr %n$2Eb$2Eold.p.gep
  %n$2Eb$2Enew = add i64 %n$2Eb$2Eold, %bytes
  %n$2Eb$2Eptr = inttoptr i64 %s to ptr
  %n$2Eb$2Eoff = bitcast i64 88 to i64
  %n$2Eb.p.gep = getelementptr inbounds i8, ptr %n$2Eb$2Eptr, i64 %n$2Eb$2Eoff
  store i64 %n$2Eb$2Enew, ptr %n$2Eb.p.gep
  %n$2Eb = bitcast i1 true to i1
  ret i64 %o
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EallocRaw(i64 %type, i64 %bytes) {
bb.entry:
  %none = bitcast i64 0 to i64
  br label %bb.check
bb.check:
  %s = call tailcc i64 @gcAslState()
  %stress$2Eptr = inttoptr i64 %s to ptr
  %stress$2Eoff = bitcast i64 40 to i64
  %stress.p.gep = getelementptr inbounds i8, ptr %stress$2Eptr, i64 %stress$2Eoff
  %stress = load i64, ptr %stress.p.gep
  %al$2Eptr = inttoptr i64 %s to ptr
  %al$2Eoff = bitcast i64 0 to i64
  %al.p.gep = getelementptr inbounds i8, ptr %al$2Eptr, i64 %al$2Eoff
  %al = load i64, ptr %al.p.gep
  %al2 = add i64 %al, %none
  %th$2Eptr = inttoptr i64 %s to ptr
  %th$2Eoff = bitcast i64 8 to i64
  %th.p.gep = getelementptr inbounds i8, ptr %th$2Eptr, i64 %th$2Eoff
  %th = load i64, ptr %th.p.gep
  %over$2Ea$2Eone = bitcast i64 1 to i64
  %over$2Ea$2Esh = bitcast i64 63 to i64
  %over$2Ea$2Emin.p.m = and i64 %over$2Ea$2Esh, 63
  %over$2Ea$2Emin = shl i64 %over$2Ea$2Eone, %over$2Ea$2Emin.p.m
  %over$2Ea = xor i64 %th, %over$2Ea$2Emin
  %over$2Eb$2Eone = bitcast i64 1 to i64
  %over$2Eb$2Esh = bitcast i64 63 to i64
  %over$2Eb$2Emin.p.m = and i64 %over$2Eb$2Esh, 63
  %over$2Eb$2Emin = shl i64 %over$2Eb$2Eone, %over$2Eb$2Emin.p.m
  %over$2Eb = xor i64 %al2, %over$2Eb$2Emin
  %over = icmp slt i64 %over$2Ea, %over$2Eb
  %st1$2Ek = bitcast i64 0 to i64
  %st1 = icmp ne i64 %stress, %st1$2Ek
  %need = or i1 %st1, %over
  br i1 %need, label %bb.collect, label %bb.sized
bb.collect:
  %gc = call tailcc i64 @gcAslCollect()
  br label %bb.sized
bb.sized:
  %max = bitcast i64 512 to i64
  %big$2Ea$2Eone = bitcast i64 1 to i64
  %big$2Ea$2Esh = bitcast i64 63 to i64
  %big$2Ea$2Emin.p.m = and i64 %big$2Ea$2Esh, 63
  %big$2Ea$2Emin = shl i64 %big$2Ea$2Eone, %big$2Ea$2Emin.p.m
  %big$2Ea = xor i64 %max, %big$2Ea$2Emin
  %big$2Eb$2Eone = bitcast i64 1 to i64
  %big$2Eb$2Esh = bitcast i64 63 to i64
  %big$2Eb$2Emin.p.m = and i64 %big$2Eb$2Esh, 63
  %big$2Eb$2Emin = shl i64 %big$2Eb$2Eone, %big$2Eb$2Emin.p.m
  %big$2Eb = xor i64 %bytes, %big$2Eb$2Emin
  %big = icmp slt i64 %big$2Ea, %big$2Eb
  %arr$2Ek = bitcast i64 6 to i64
  %arr = icmp eq i64 %type, %arr$2Ek
  %hnd$2Ek = bitcast i64 7 to i64
  %hnd = icmp eq i64 %type, %hnd$2Ek
  %o1 = or i1 %big, %arr
  %large = or i1 %o1, %hnd
  br i1 %large, label %bb.large, label %bb.small
bb.large:
  %lo = musttail call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EallocLarge(i64 %type, i64 %bytes)
  ret i64 %lo
bb.small:
  %tiny$2Ek = bitcast i64 16 to i64
  %tiny = icmp slt i64 %bytes, %tiny$2Ek
  %sixteen = bitcast i64 16 to i64
  br i1 %tiny, label %bb.small.e0, label %bb.small.e1
bb.small.e0:
  br label %bb.fit
bb.small.e1:
  br label %bb.fit
bb.fit:
  %b = phi i64 [ %sixteen, %bb.small.e0 ], [ %bytes, %bb.small.e1 ]
  %b7$2Ek = bitcast i64 7 to i64
  %b7 = add i64 %b, %b7$2Ek
  %b8$2Ek = bitcast i64 3 to i64
  %b8.p.m = and i64 %b8$2Ek, 63
  %b8 = lshr i64 %b7, %b8.p.m
  %sc$2Ek = bitcast i64 -2 to i64
  %sc = add i64 %b8, %sc$2Ek
  %sc2$2Ek = bitcast i64 2 to i64
  %sc2 = add i64 %sc, %sc2$2Ek
  %ss$2Ek = bitcast i64 8 to i64
  %ss = mul i64 %sc2, %ss$2Ek
  %o = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpoolAlloc(i64 %sc, i64 %ss)
  %ty$2Ek = bitcast i64 32 to i64
  %ty.p.m = and i64 %ty$2Ek, 63
  %ty = shl i64 %type, %ty.p.m
  %cls$2Ek = bitcast i64 56 to i64
  %cls.p.m = and i64 %cls$2Ek, 63
  %cls = shl i64 %sc, %cls.p.m
  %h1 = or i64 %bytes, %ty
  %h = or i64 %h1, %cls
  %wh$2Eptr = inttoptr i64 %o to ptr
  %wh$2Eoff = bitcast i64 0 to i64
  %wh.p.gep = getelementptr inbounds i8, ptr %wh$2Eptr, i64 %wh$2Eoff
  store i64 %h, ptr %wh.p.gep
  %wh = bitcast i1 true to i1
  %n$2Ea$2Eold$2Eptr = inttoptr i64 %s to ptr
  %n$2Ea$2Eold$2Eoff = bitcast i64 0 to i64
  %n$2Ea$2Eold.p.gep = getelementptr inbounds i8, ptr %n$2Ea$2Eold$2Eptr, i64 %n$2Ea$2Eold$2Eoff
  %n$2Ea$2Eold = load i64, ptr %n$2Ea$2Eold.p.gep
  %n$2Ea$2Enew = add i64 %n$2Ea$2Eold, %bytes
  %n$2Ea$2Eptr = inttoptr i64 %s to ptr
  %n$2Ea$2Eoff = bitcast i64 0 to i64
  %n$2Ea.p.gep = getelementptr inbounds i8, ptr %n$2Ea$2Eptr, i64 %n$2Ea$2Eoff
  store i64 %n$2Ea$2Enew, ptr %n$2Ea.p.gep
  %n$2Ea = bitcast i1 true to i1
  %n$2Eo$2Eby = bitcast i64 1 to i64
  %n$2Eo$2Eold$2Eptr = inttoptr i64 %s to ptr
  %n$2Eo$2Eold$2Eoff = bitcast i64 72 to i64
  %n$2Eo$2Eold.p.gep = getelementptr inbounds i8, ptr %n$2Eo$2Eold$2Eptr, i64 %n$2Eo$2Eold$2Eoff
  %n$2Eo$2Eold = load i64, ptr %n$2Eo$2Eold.p.gep
  %n$2Eo$2Enew = add i64 %n$2Eo$2Eold, %n$2Eo$2Eby
  %n$2Eo$2Eptr = inttoptr i64 %s to ptr
  %n$2Eo$2Eoff = bitcast i64 72 to i64
  %n$2Eo.p.gep = getelementptr inbounds i8, ptr %n$2Eo$2Eptr, i64 %n$2Eo$2Eoff
  store i64 %n$2Eo$2Enew, ptr %n$2Eo.p.gep
  %n$2Eo = bitcast i1 true to i1
  %n$2Eb$2Eold$2Eptr = inttoptr i64 %s to ptr
  %n$2Eb$2Eold$2Eoff = bitcast i64 88 to i64
  %n$2Eb$2Eold.p.gep = getelementptr inbounds i8, ptr %n$2Eb$2Eold$2Eptr, i64 %n$2Eb$2Eold$2Eoff
  %n$2Eb$2Eold = load i64, ptr %n$2Eb$2Eold.p.gep
  %n$2Eb$2Enew = add i64 %n$2Eb$2Eold, %bytes
  %n$2Eb$2Eptr = inttoptr i64 %s to ptr
  %n$2Eb$2Eoff = bitcast i64 88 to i64
  %n$2Eb.p.gep = getelementptr inbounds i8, ptr %n$2Eb$2Eptr, i64 %n$2Eb$2Eoff
  store i64 %n$2Eb$2Enew, ptr %n$2Eb.p.gep
  %n$2Eb = bitcast i1 true to i1
  ret i64 %o
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EallocCons() {
bb.entry:
  %none = bitcast i64 0 to i64
  br label %bb.check
bb.check:
  %s = call tailcc i64 @gcAslState()
  %stress$2Eptr = inttoptr i64 %s to ptr
  %stress$2Eoff = bitcast i64 40 to i64
  %stress.p.gep = getelementptr inbounds i8, ptr %stress$2Eptr, i64 %stress$2Eoff
  %stress = load i64, ptr %stress.p.gep
  %al$2Eptr = inttoptr i64 %s to ptr
  %al$2Eoff = bitcast i64 0 to i64
  %al.p.gep = getelementptr inbounds i8, ptr %al$2Eptr, i64 %al$2Eoff
  %al = load i64, ptr %al.p.gep
  %al2 = add i64 %al, %none
  %th$2Eptr = inttoptr i64 %s to ptr
  %th$2Eoff = bitcast i64 8 to i64
  %th.p.gep = getelementptr inbounds i8, ptr %th$2Eptr, i64 %th$2Eoff
  %th = load i64, ptr %th.p.gep
  %over$2Ea$2Eone = bitcast i64 1 to i64
  %over$2Ea$2Esh = bitcast i64 63 to i64
  %over$2Ea$2Emin.p.m = and i64 %over$2Ea$2Esh, 63
  %over$2Ea$2Emin = shl i64 %over$2Ea$2Eone, %over$2Ea$2Emin.p.m
  %over$2Ea = xor i64 %th, %over$2Ea$2Emin
  %over$2Eb$2Eone = bitcast i64 1 to i64
  %over$2Eb$2Esh = bitcast i64 63 to i64
  %over$2Eb$2Emin.p.m = and i64 %over$2Eb$2Esh, 63
  %over$2Eb$2Emin = shl i64 %over$2Eb$2Eone, %over$2Eb$2Emin.p.m
  %over$2Eb = xor i64 %al2, %over$2Eb$2Emin
  %over = icmp slt i64 %over$2Ea, %over$2Eb
  %st1$2Ek = bitcast i64 0 to i64
  %st1 = icmp ne i64 %stress, %st1$2Ek
  %need = or i1 %st1, %over
  br i1 %need, label %bb.collect, label %bb.go
bb.collect:
  %gc = call tailcc i64 @gcAslCollect()
  br label %bb.go
bb.go:
  %sc = bitcast i64 3 to i64
  %ss = bitcast i64 40 to i64
  %o = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpoolAlloc(i64 %sc, i64 %ss)
  %h = bitcast i64 216172786408751144 to i64
  %wh$2Eptr = inttoptr i64 %o to ptr
  %wh$2Eoff = bitcast i64 0 to i64
  %wh.p.gep = getelementptr inbounds i8, ptr %wh$2Eptr, i64 %wh$2Eoff
  store i64 %h, ptr %wh.p.gep
  %wh = bitcast i1 true to i1
  %n$2Ea$2Eold$2Eptr = inttoptr i64 %s to ptr
  %n$2Ea$2Eold$2Eoff = bitcast i64 0 to i64
  %n$2Ea$2Eold.p.gep = getelementptr inbounds i8, ptr %n$2Ea$2Eold$2Eptr, i64 %n$2Ea$2Eold$2Eoff
  %n$2Ea$2Eold = load i64, ptr %n$2Ea$2Eold.p.gep
  %n$2Ea$2Enew = add i64 %n$2Ea$2Eold, %ss
  %n$2Ea$2Eptr = inttoptr i64 %s to ptr
  %n$2Ea$2Eoff = bitcast i64 0 to i64
  %n$2Ea.p.gep = getelementptr inbounds i8, ptr %n$2Ea$2Eptr, i64 %n$2Ea$2Eoff
  store i64 %n$2Ea$2Enew, ptr %n$2Ea.p.gep
  %n$2Ea = bitcast i1 true to i1
  %n$2Eo$2Eby = bitcast i64 1 to i64
  %n$2Eo$2Eold$2Eptr = inttoptr i64 %s to ptr
  %n$2Eo$2Eold$2Eoff = bitcast i64 72 to i64
  %n$2Eo$2Eold.p.gep = getelementptr inbounds i8, ptr %n$2Eo$2Eold$2Eptr, i64 %n$2Eo$2Eold$2Eoff
  %n$2Eo$2Eold = load i64, ptr %n$2Eo$2Eold.p.gep
  %n$2Eo$2Enew = add i64 %n$2Eo$2Eold, %n$2Eo$2Eby
  %n$2Eo$2Eptr = inttoptr i64 %s to ptr
  %n$2Eo$2Eoff = bitcast i64 72 to i64
  %n$2Eo.p.gep = getelementptr inbounds i8, ptr %n$2Eo$2Eptr, i64 %n$2Eo$2Eoff
  store i64 %n$2Eo$2Enew, ptr %n$2Eo.p.gep
  %n$2Eo = bitcast i1 true to i1
  %n$2Eb$2Eold$2Eptr = inttoptr i64 %s to ptr
  %n$2Eb$2Eold$2Eoff = bitcast i64 88 to i64
  %n$2Eb$2Eold.p.gep = getelementptr inbounds i8, ptr %n$2Eb$2Eold$2Eptr, i64 %n$2Eb$2Eold$2Eoff
  %n$2Eb$2Eold = load i64, ptr %n$2Eb$2Eold.p.gep
  %n$2Eb$2Enew = add i64 %n$2Eb$2Eold, %ss
  %n$2Eb$2Eptr = inttoptr i64 %s to ptr
  %n$2Eb$2Eoff = bitcast i64 88 to i64
  %n$2Eb.p.gep = getelementptr inbounds i8, ptr %n$2Eb$2Eptr, i64 %n$2Eb$2Eoff
  store i64 %n$2Eb$2Enew, ptr %n$2Eb.p.gep
  %n$2Eb = bitcast i1 true to i1
  ret i64 %o
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EallocPerm(i64 %type, i64 %bytes) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %one = bitcast i64 1 to i64
  %r = call ptr (i64, i64) @calloc(i64 %one, i64 %bytes)
  %o = ptrtoint ptr %r to i64
  %dead$2Ek = bitcast i64 0 to i64
  %dead = icmp eq i64 %o, %dead$2Ek
  br i1 %dead, label %bb.oom, label %bb.init
bb.oom:
  %oom$2Ec = bitcast ptr @str.2 to ptr
  %oom$2Ef = bitcast ptr @str.8 to ptr
  %oom$2Ebi = call tailcc i64 @gcAslFailBuf()
  %oom$2Eb = inttoptr i64 %oom$2Ebi to ptr
  %oom$2Ecap = bitcast i64 1024 to i64
  %oom$2En = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %oom$2Eb, i64 %oom$2Ecap, ptr %oom$2Ef, i64 %bytes)
  %oom$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %oom$2Ec, ptr %oom$2Eb)
  %oom$2Ez = bitcast i64 0 to i64
  ret i64 %oom$2Ez
bb.init:
  %size$2Ek = bitcast i64 4294967295 to i64
  %size = and i64 %bytes, %size$2Ek
  %ty$2Ek = bitcast i64 32 to i64
  %ty.p.m = and i64 %ty$2Ek, 63
  %ty = shl i64 %type, %ty.p.m
  %permBits = bitcast i64 -71776119061217280 to i64
  %h1 = or i64 %size, %ty
  %h = or i64 %h1, %permBits
  %wh$2Eptr = inttoptr i64 %o to ptr
  %wh$2Eoff = bitcast i64 0 to i64
  %wh.p.gep = getelementptr inbounds i8, ptr %wh$2Eptr, i64 %wh$2Eoff
  store i64 %h, ptr %wh.p.gep
  %wh = bitcast i1 true to i1
  %oa$2Eby = bitcast i64 1 to i64
  %oa$2Eold$2Eptr = inttoptr i64 %s to ptr
  %oa$2Eold$2Eoff = bitcast i64 72 to i64
  %oa$2Eold.p.gep = getelementptr inbounds i8, ptr %oa$2Eold$2Eptr, i64 %oa$2Eold$2Eoff
  %oa$2Eold = load i64, ptr %oa$2Eold.p.gep
  %oa$2Enew = add i64 %oa$2Eold, %oa$2Eby
  %oa$2Eptr = inttoptr i64 %s to ptr
  %oa$2Eoff = bitcast i64 72 to i64
  %oa.p.gep = getelementptr inbounds i8, ptr %oa$2Eptr, i64 %oa$2Eoff
  store i64 %oa$2Enew, ptr %oa.p.gep
  %oa = bitcast i1 true to i1
  %ba$2Eold$2Eptr = inttoptr i64 %s to ptr
  %ba$2Eold$2Eoff = bitcast i64 88 to i64
  %ba$2Eold.p.gep = getelementptr inbounds i8, ptr %ba$2Eold$2Eptr, i64 %ba$2Eold$2Eoff
  %ba$2Eold = load i64, ptr %ba$2Eold.p.gep
  %ba$2Enew = add i64 %ba$2Eold, %bytes
  %ba$2Eptr = inttoptr i64 %s to ptr
  %ba$2Eoff = bitcast i64 88 to i64
  %ba.p.gep = getelementptr inbounds i8, ptr %ba$2Eptr, i64 %ba$2Eoff
  store i64 %ba$2Enew, ptr %ba.p.gep
  %ba = bitcast i1 true to i1
  ret i64 %o
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EallocLarge(i64 %type, i64 %bytes) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %eight = bitcast i64 8 to i64
  %gt8$2Ea$2Eone = bitcast i64 1 to i64
  %gt8$2Ea$2Esh = bitcast i64 63 to i64
  %gt8$2Ea$2Emin.p.m = and i64 %gt8$2Ea$2Esh, 63
  %gt8$2Ea$2Emin = shl i64 %gt8$2Ea$2Eone, %gt8$2Ea$2Emin.p.m
  %gt8$2Ea = xor i64 %eight, %gt8$2Ea$2Emin
  %gt8$2Eb$2Eone = bitcast i64 1 to i64
  %gt8$2Eb$2Esh = bitcast i64 63 to i64
  %gt8$2Eb$2Emin.p.m = and i64 %gt8$2Eb$2Esh, 63
  %gt8$2Eb$2Emin = shl i64 %gt8$2Eb$2Eone, %gt8$2Eb$2Emin.p.m
  %gt8$2Eb = xor i64 %bytes, %gt8$2Eb$2Emin
  %gt8 = icmp slt i64 %gt8$2Ea, %gt8$2Eb
  %x = sub i64 %bytes, %eight
  %zero = bitcast i64 0 to i64
  br i1 %gt8, label %bb.entry.e0, label %bb.entry.e1
bb.entry.e0:
  br label %bb.extra
bb.entry.e1:
  br label %bb.extra
bb.extra:
  %ex = phi i64 [ %x, %bb.entry.e0 ], [ %zero, %bb.entry.e1 ]
  %total$2Ek = bitcast i64 32 to i64
  %total = add i64 %ex, %total$2Ek
  %wrapped$2Ea$2Eone = bitcast i64 1 to i64
  %wrapped$2Ea$2Esh = bitcast i64 63 to i64
  %wrapped$2Ea$2Emin.p.m = and i64 %wrapped$2Ea$2Esh, 63
  %wrapped$2Ea$2Emin = shl i64 %wrapped$2Ea$2Eone, %wrapped$2Ea$2Emin.p.m
  %wrapped$2Ea = xor i64 %total, %wrapped$2Ea$2Emin
  %wrapped$2Eb$2Eone = bitcast i64 1 to i64
  %wrapped$2Eb$2Esh = bitcast i64 63 to i64
  %wrapped$2Eb$2Emin.p.m = and i64 %wrapped$2Eb$2Esh, 63
  %wrapped$2Eb$2Emin = shl i64 %wrapped$2Eb$2Eone, %wrapped$2Eb$2Emin.p.m
  %wrapped$2Eb = xor i64 %ex, %wrapped$2Eb$2Emin
  %wrapped = icmp slt i64 %wrapped$2Ea, %wrapped$2Eb
  br i1 %wrapped, label %bb.oomBytes, label %bb.index
bb.index:
  %n$2Eptr = inttoptr i64 %s to ptr
  %n$2Eoff = bitcast i64 264 to i64
  %n.p.gep = getelementptr inbounds i8, ptr %n$2Eptr, i64 %n$2Eoff
  %n = load i64, ptr %n.p.gep
  %cap$2Eptr = inttoptr i64 %s to ptr
  %cap$2Eoff = bitcast i64 272 to i64
  %cap.p.gep = getelementptr inbounds i8, ptr %cap$2Eptr, i64 %cap$2Eoff
  %cap = load i64, ptr %cap.p.gep
  %full = icmp eq i64 %n, %cap
  br i1 %full, label %bb.grow, label %bb.alloc
bb.grow:
  %z$2Ek = bitcast i64 0 to i64
  %z = icmp eq i64 %cap, %z$2Ek
  %first = bitcast i64 256 to i64
  %twice$2Ek = bitcast i64 2 to i64
  %twice = mul i64 %cap, %twice$2Ek
  br i1 %z, label %bb.grow.e0, label %bb.grow.e1
bb.grow.e0:
  br label %bb.gsized
bb.grow.e1:
  br label %bb.gsized
bb.gsized:
  %nc = phi i64 [ %first, %bb.grow.e0 ], [ %twice, %bb.grow.e1 ]
  %nb$2Ek = bitcast i64 8 to i64
  %nb = mul i64 %nc, %nb$2Ek
  %old$2Eptr = inttoptr i64 %s to ptr
  %old$2Eoff = bitcast i64 256 to i64
  %old.p.gep = getelementptr inbounds i8, ptr %old$2Eptr, i64 %old$2Eoff
  %old = load i64, ptr %old.p.gep
  %oldp = inttoptr i64 %old to ptr
  %gr = call ptr (ptr, i64) @realloc(ptr %oldp, i64 %nb)
  %gri = ptrtoint ptr %gr to i64
  %gdead$2Ek = bitcast i64 0 to i64
  %gdead = icmp eq i64 %gri, %gdead$2Ek
  br i1 %gdead, label %bb.oomIndex, label %bb.gset
bb.oomIndex:
  %oomIndex$2Ec = bitcast ptr @str.2 to ptr
  %oomIndex$2Ef = bitcast ptr @str.7 to ptr
  %oomIndex$2Ebi = call tailcc i64 @gcAslFailBuf()
  %oomIndex$2Eb = inttoptr i64 %oomIndex$2Ebi to ptr
  %oomIndex$2Ecap = bitcast i64 1024 to i64
  %oomIndex$2En = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %oomIndex$2Eb, i64 %oomIndex$2Ecap, ptr %oomIndex$2Ef, i64 %nc)
  %oomIndex$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %oomIndex$2Ec, ptr %oomIndex$2Eb)
  %oomIndex$2Ez = bitcast i64 0 to i64
  ret i64 %oomIndex$2Ez
bb.gset:
  %w1$2Eptr = inttoptr i64 %s to ptr
  %w1$2Eoff = bitcast i64 256 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %gri, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  %w2$2Eptr = inttoptr i64 %s to ptr
  %w2$2Eoff = bitcast i64 272 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %nc, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  br label %bb.alloc
bb.alloc:
  %one = bitcast i64 1 to i64
  %r = call ptr (i64, i64) @calloc(i64 %one, i64 %total)
  %lo = ptrtoint ptr %r to i64
  %dead$2Ek = bitcast i64 0 to i64
  %dead = icmp eq i64 %lo, %dead$2Ek
  br i1 %dead, label %bb.oomBytes, label %bb.fill
bb.oomBytes:
  %oomBytes$2Ec = bitcast ptr @str.2 to ptr
  %oomBytes$2Ef = bitcast ptr @str.8 to ptr
  %oomBytes$2Ebi = call tailcc i64 @gcAslFailBuf()
  %oomBytes$2Eb = inttoptr i64 %oomBytes$2Ebi to ptr
  %oomBytes$2Ecap = bitcast i64 1024 to i64
  %oomBytes$2En = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %oomBytes$2Eb, i64 %oomBytes$2Ecap, ptr %oomBytes$2Ef, i64 %bytes)
  %oomBytes$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %oomBytes$2Ec, ptr %oomBytes$2Eb)
  %oomBytes$2Ez = bitcast i64 0 to i64
  ret i64 %oomBytes$2Ez
bb.fill:
  %span$2Ek = bitcast i64 -24 to i64
  %span = add i64 %total, %span$2Ek
  %w3$2Eptr = inttoptr i64 %lo to ptr
  %w3$2Eoff = bitcast i64 16 to i64
  %w3.p.gep = getelementptr inbounds i8, ptr %w3$2Eptr, i64 %w3$2Eoff
  store i64 %span, ptr %w3.p.gep
  %w3 = bitcast i1 true to i1
  %nz$2Ek = bitcast i64 0 to i64
  %nz = icmp ne i64 %n, %nz$2Ek
  br i1 %nz, label %bb.cmpLast, label %bb.push
bb.cmpLast:
  %idx0$2Eptr = inttoptr i64 %s to ptr
  %idx0$2Eoff = bitcast i64 256 to i64
  %idx0.p.gep = getelementptr inbounds i8, ptr %idx0$2Eptr, i64 %idx0$2Eoff
  %idx0 = load i64, ptr %idx0.p.gep
  %nm1$2Ek = bitcast i64 -1 to i64
  %nm1 = add i64 %n, %nm1$2Ek
  %lastAt$2Em$2Ek = bitcast i64 8 to i64
  %lastAt$2Em = mul i64 %nm1, %lastAt$2Em$2Ek
  %lastAt = add i64 %idx0, %lastAt$2Em
  %last$2Eptr = inttoptr i64 %lastAt to ptr
  %last$2Eoff = bitcast i64 0 to i64
  %last.p.gep = getelementptr inbounds i8, ptr %last$2Eptr, i64 %last$2Eoff
  %last = load i64, ptr %last.p.gep
  %below$2Ea$2Eone = bitcast i64 1 to i64
  %below$2Ea$2Esh = bitcast i64 63 to i64
  %below$2Ea$2Emin.p.m = and i64 %below$2Ea$2Esh, 63
  %below$2Ea$2Emin = shl i64 %below$2Ea$2Eone, %below$2Ea$2Emin.p.m
  %below$2Ea = xor i64 %lo, %below$2Ea$2Emin
  %below$2Eb$2Eone = bitcast i64 1 to i64
  %below$2Eb$2Esh = bitcast i64 63 to i64
  %below$2Eb$2Emin.p.m = and i64 %below$2Eb$2Esh, 63
  %below$2Eb$2Emin = shl i64 %below$2Eb$2Eone, %below$2Eb$2Emin.p.m
  %below$2Eb = xor i64 %last, %below$2Eb$2Emin
  %below = icmp slt i64 %below$2Ea, %below$2Eb
  br i1 %below, label %bb.unsorted, label %bb.push
bb.unsorted:
  %w4$2Ev = bitcast i64 0 to i64
  %w4$2Eptr = inttoptr i64 %s to ptr
  %w4$2Eoff = bitcast i64 280 to i64
  %w4.p.gep = getelementptr inbounds i8, ptr %w4$2Eptr, i64 %w4$2Eoff
  store i64 %w4$2Ev, ptr %w4.p.gep
  %w4 = bitcast i1 true to i1
  br label %bb.push
bb.push:
  %idx$2Eptr = inttoptr i64 %s to ptr
  %idx$2Eoff = bitcast i64 256 to i64
  %idx.p.gep = getelementptr inbounds i8, ptr %idx$2Eptr, i64 %idx$2Eoff
  %idx = load i64, ptr %idx.p.gep
  %at$2Em$2Ek = bitcast i64 8 to i64
  %at$2Em = mul i64 %n, %at$2Em$2Ek
  %at = add i64 %idx, %at$2Em
  %w5$2Eptr = inttoptr i64 %at to ptr
  %w5$2Eoff = bitcast i64 0 to i64
  %w5.p.gep = getelementptr inbounds i8, ptr %w5$2Eptr, i64 %w5$2Eoff
  store i64 %lo, ptr %w5.p.gep
  %w5 = bitcast i1 true to i1
  %n1$2Ek = bitcast i64 1 to i64
  %n1 = add i64 %n, %n1$2Ek
  %w6$2Eptr = inttoptr i64 %s to ptr
  %w6$2Eoff = bitcast i64 264 to i64
  %w6.p.gep = getelementptr inbounds i8, ptr %w6$2Eptr, i64 %w6$2Eoff
  store i64 %n1, ptr %w6.p.gep
  %w6 = bitcast i1 true to i1
  %loEnd = add i64 %lo, %total
  %wh = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EwidenHeap(i64 %lo, i64 %loEnd)
  %w7$2Eptr = inttoptr i64 %lo to ptr
  %w7$2Eoff = bitcast i64 8 to i64
  %w7.p.gep = getelementptr inbounds i8, ptr %w7$2Eptr, i64 %w7$2Eoff
  store i64 %bytes, ptr %w7.p.gep
  %w7 = bitcast i1 true to i1
  %u32 = bitcast i64 4294967295 to i64
  %huge$2Ea$2Eone = bitcast i64 1 to i64
  %huge$2Ea$2Esh = bitcast i64 63 to i64
  %huge$2Ea$2Emin.p.m = and i64 %huge$2Ea$2Esh, 63
  %huge$2Ea$2Emin = shl i64 %huge$2Ea$2Eone, %huge$2Ea$2Emin.p.m
  %huge$2Ea = xor i64 %u32, %huge$2Ea$2Emin
  %huge$2Eb$2Eone = bitcast i64 1 to i64
  %huge$2Eb$2Esh = bitcast i64 63 to i64
  %huge$2Eb$2Emin.p.m = and i64 %huge$2Eb$2Esh, 63
  %huge$2Eb$2Emin = shl i64 %huge$2Eb$2Eone, %huge$2Eb$2Emin.p.m
  %huge$2Eb = xor i64 %bytes, %huge$2Eb$2Emin
  %huge = icmp slt i64 %huge$2Ea, %huge$2Eb
  br i1 %huge, label %bb.push.e0, label %bb.push.e1
bb.push.e0:
  br label %bb.head
bb.push.e1:
  br label %bb.head
bb.head:
  %size = phi i64 [ %u32, %bb.push.e0 ], [ %bytes, %bb.push.e1 ]
  %ty$2Ek = bitcast i64 32 to i64
  %ty.p.m = and i64 %ty$2Ek, 63
  %ty = shl i64 %type, %ty.p.m
  %cls = bitcast i64 -72057594037927936 to i64
  %h1 = or i64 %size, %ty
  %h = or i64 %h1, %cls
  %w8$2Eptr = inttoptr i64 %lo to ptr
  %w8$2Eoff = bitcast i64 24 to i64
  %w8.p.gep = getelementptr inbounds i8, ptr %w8$2Eptr, i64 %w8$2Eoff
  store i64 %h, ptr %w8.p.gep
  %w8 = bitcast i1 true to i1
  %lhead$2Eptr = inttoptr i64 %s to ptr
  %lhead$2Eoff = bitcast i64 224 to i64
  %lhead.p.gep = getelementptr inbounds i8, ptr %lhead$2Eptr, i64 %lhead$2Eoff
  %lhead = load i64, ptr %lhead.p.gep
  %w9$2Eptr = inttoptr i64 %lo to ptr
  %w9$2Eoff = bitcast i64 0 to i64
  %w9.p.gep = getelementptr inbounds i8, ptr %w9$2Eptr, i64 %w9$2Eoff
  store i64 %lhead, ptr %w9.p.gep
  %w9 = bitcast i1 true to i1
  %w10$2Eptr = inttoptr i64 %s to ptr
  %w10$2Eoff = bitcast i64 224 to i64
  %w10.p.gep = getelementptr inbounds i8, ptr %w10$2Eptr, i64 %w10$2Eoff
  store i64 %lo, ptr %w10.p.gep
  %w10 = bitcast i1 true to i1
  %c$2Ea$2Eold$2Eptr = inttoptr i64 %s to ptr
  %c$2Ea$2Eold$2Eoff = bitcast i64 0 to i64
  %c$2Ea$2Eold.p.gep = getelementptr inbounds i8, ptr %c$2Ea$2Eold$2Eptr, i64 %c$2Ea$2Eold$2Eoff
  %c$2Ea$2Eold = load i64, ptr %c$2Ea$2Eold.p.gep
  %c$2Ea$2Enew = add i64 %c$2Ea$2Eold, %bytes
  %c$2Ea$2Eptr = inttoptr i64 %s to ptr
  %c$2Ea$2Eoff = bitcast i64 0 to i64
  %c$2Ea.p.gep = getelementptr inbounds i8, ptr %c$2Ea$2Eptr, i64 %c$2Ea$2Eoff
  store i64 %c$2Ea$2Enew, ptr %c$2Ea.p.gep
  %c$2Ea = bitcast i1 true to i1
  %c$2Eo$2Eby = bitcast i64 1 to i64
  %c$2Eo$2Eold$2Eptr = inttoptr i64 %s to ptr
  %c$2Eo$2Eold$2Eoff = bitcast i64 72 to i64
  %c$2Eo$2Eold.p.gep = getelementptr inbounds i8, ptr %c$2Eo$2Eold$2Eptr, i64 %c$2Eo$2Eold$2Eoff
  %c$2Eo$2Eold = load i64, ptr %c$2Eo$2Eold.p.gep
  %c$2Eo$2Enew = add i64 %c$2Eo$2Eold, %c$2Eo$2Eby
  %c$2Eo$2Eptr = inttoptr i64 %s to ptr
  %c$2Eo$2Eoff = bitcast i64 72 to i64
  %c$2Eo.p.gep = getelementptr inbounds i8, ptr %c$2Eo$2Eptr, i64 %c$2Eo$2Eoff
  store i64 %c$2Eo$2Enew, ptr %c$2Eo.p.gep
  %c$2Eo = bitcast i1 true to i1
  %c$2Eb$2Eold$2Eptr = inttoptr i64 %s to ptr
  %c$2Eb$2Eold$2Eoff = bitcast i64 88 to i64
  %c$2Eb$2Eold.p.gep = getelementptr inbounds i8, ptr %c$2Eb$2Eold$2Eptr, i64 %c$2Eb$2Eold$2Eoff
  %c$2Eb$2Eold = load i64, ptr %c$2Eb$2Eold.p.gep
  %c$2Eb$2Enew = add i64 %c$2Eb$2Eold, %bytes
  %c$2Eb$2Eptr = inttoptr i64 %s to ptr
  %c$2Eb$2Eoff = bitcast i64 88 to i64
  %c$2Eb.p.gep = getelementptr inbounds i8, ptr %c$2Eb$2Eptr, i64 %c$2Eb$2Eoff
  store i64 %c$2Eb$2Enew, ptr %c$2Eb.p.gep
  %c$2Eb = bitcast i1 true to i1
  %o$2Ek = bitcast i64 24 to i64
  %o = add i64 %lo, %o$2Ek
  ret i64 %o
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Eaccount(i64 %o, i64 %bytes) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %h$2Eptr = inttoptr i64 %o to ptr
  %h$2Eoff = bitcast i64 0 to i64
  %h.p.gep = getelementptr inbounds i8, ptr %h$2Eptr, i64 %h$2Eoff
  %h = load i64, ptr %h.p.gep
  %cls$2Ek = bitcast i64 56 to i64
  %cls.p.m = and i64 %cls$2Ek, 63
  %cls = lshr i64 %h, %cls.p.m
  %perm$2Es$2Ek = bitcast i64 48 to i64
  %perm$2Es.p.m = and i64 %perm$2Es$2Ek, 63
  %perm$2Es = lshr i64 %h, %perm$2Es.p.m
  %perm$2Ek = bitcast i64 255 to i64
  %perm = and i64 %perm$2Es, %perm$2Ek
  %isLarge$2Ek = bitcast i64 255 to i64
  %isLarge = icmp eq i64 %cls, %isLarge$2Ek
  %notPerm$2Ek = bitcast i64 0 to i64
  %notPerm = icmp eq i64 %perm, %notPerm$2Ek
  %owned = and i1 %isLarge, %notPerm
  br i1 %owned, label %bb.large, label %bb.header
bb.large:
  %lo$2Ek = bitcast i64 -24 to i64
  %lo = add i64 %o, %lo$2Ek
  %lb$2Eptr = inttoptr i64 %lo to ptr
  %lb$2Eoff = bitcast i64 8 to i64
  %lb.p.gep = getelementptr inbounds i8, ptr %lb$2Eptr, i64 %lb$2Eoff
  %lb = load i64, ptr %lb.p.gep
  %lb1 = add i64 %lb, %bytes
  %w1$2Eptr = inttoptr i64 %lo to ptr
  %w1$2Eoff = bitcast i64 8 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %lb1, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  br label %bb.header
bb.header:
  %hs = add i64 %h, %bytes
  %low$2Ek = bitcast i64 4294967295 to i64
  %low = and i64 %hs, %low$2Ek
  %high$2Ek = bitcast i64 -4294967296 to i64
  %high = and i64 %h, %high$2Ek
  %h1 = or i64 %high, %low
  %w2$2Eptr = inttoptr i64 %o to ptr
  %w2$2Eoff = bitcast i64 0 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %h1, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  %a$2Eold$2Eptr = inttoptr i64 %s to ptr
  %a$2Eold$2Eoff = bitcast i64 0 to i64
  %a$2Eold.p.gep = getelementptr inbounds i8, ptr %a$2Eold$2Eptr, i64 %a$2Eold$2Eoff
  %a$2Eold = load i64, ptr %a$2Eold.p.gep
  %a$2Enew = add i64 %a$2Eold, %bytes
  %a$2Eptr = inttoptr i64 %s to ptr
  %a$2Eoff = bitcast i64 0 to i64
  %a.p.gep = getelementptr inbounds i8, ptr %a$2Eptr, i64 %a$2Eoff
  store i64 %a$2Enew, ptr %a.p.gep
  %a = bitcast i1 true to i1
  %b$2Eold$2Eptr = inttoptr i64 %s to ptr
  %b$2Eold$2Eoff = bitcast i64 88 to i64
  %b$2Eold.p.gep = getelementptr inbounds i8, ptr %b$2Eold$2Eptr, i64 %b$2Eold$2Eoff
  %b$2Eold = load i64, ptr %b$2Eold.p.gep
  %b$2Enew = add i64 %b$2Eold, %bytes
  %b$2Eptr = inttoptr i64 %s to ptr
  %b$2Eoff = bitcast i64 88 to i64
  %b.p.gep = getelementptr inbounds i8, ptr %b$2Eptr, i64 %b$2Eoff
  store i64 %b$2Enew, ptr %b.p.gep
  %b = bitcast i1 true to i1
  %header$2Ez = bitcast i64 0 to i64
  ret i64 %header$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EwillAllocate(i64 %bytes) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %stress$2Eptr = inttoptr i64 %s to ptr
  %stress$2Eoff = bitcast i64 40 to i64
  %stress.p.gep = getelementptr inbounds i8, ptr %stress$2Eptr, i64 %stress$2Eoff
  %stress = load i64, ptr %stress.p.gep
  %al$2Eptr = inttoptr i64 %s to ptr
  %al$2Eoff = bitcast i64 0 to i64
  %al.p.gep = getelementptr inbounds i8, ptr %al$2Eptr, i64 %al$2Eoff
  %al = load i64, ptr %al.p.gep
  %al2 = add i64 %al, %bytes
  %th$2Eptr = inttoptr i64 %s to ptr
  %th$2Eoff = bitcast i64 8 to i64
  %th.p.gep = getelementptr inbounds i8, ptr %th$2Eptr, i64 %th$2Eoff
  %th = load i64, ptr %th.p.gep
  %over$2Ea$2Eone = bitcast i64 1 to i64
  %over$2Ea$2Esh = bitcast i64 63 to i64
  %over$2Ea$2Emin.p.m = and i64 %over$2Ea$2Esh, 63
  %over$2Ea$2Emin = shl i64 %over$2Ea$2Eone, %over$2Ea$2Emin.p.m
  %over$2Ea = xor i64 %th, %over$2Ea$2Emin
  %over$2Eb$2Eone = bitcast i64 1 to i64
  %over$2Eb$2Esh = bitcast i64 63 to i64
  %over$2Eb$2Emin.p.m = and i64 %over$2Eb$2Esh, 63
  %over$2Eb$2Emin = shl i64 %over$2Eb$2Eone, %over$2Eb$2Emin.p.m
  %over$2Eb = xor i64 %al2, %over$2Eb$2Emin
  %over = icmp slt i64 %over$2Ea, %over$2Eb
  %st1$2Ek = bitcast i64 0 to i64
  %st1 = icmp ne i64 %stress, %st1$2Ek
  %need = or i1 %st1, %over
  br i1 %need, label %bb.collect, label %bb.done
bb.collect:
  %gc = call tailcc i64 @gcAslCollect()
  br label %bb.done
bb.done:
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EfreedObjects() {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %n$2Eptr = inttoptr i64 %s to ptr
  %n$2Eoff = bitcast i64 80 to i64
  %n.p.gep = getelementptr inbounds i8, ptr %n$2Eptr, i64 %n$2Eoff
  %n = load i64, ptr %n.p.gep
  ret i64 %n
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EfailNextGrow() {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %w$2Ev = bitcast i64 1 to i64
  %w$2Eptr = inttoptr i64 %s to ptr
  %w$2Eoff = bitcast i64 312 to i64
  %w.p.gep = getelementptr inbounds i8, ptr %w$2Eptr, i64 %w$2Eoff
  store i64 %w$2Ev, ptr %w.p.gep
  %w = bitcast i1 true to i1
  %entry$2Ez = bitcast i64 0 to i64
  ret i64 %entry$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EfindObj(i64 %w) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %hl$2Eptr = inttoptr i64 %s to ptr
  %hl$2Eoff = bitcast i64 288 to i64
  %hl.p.gep = getelementptr inbounds i8, ptr %hl$2Eptr, i64 %hl$2Eoff
  %hl = load i64, ptr %hl.p.gep
  %hh$2Eptr = inttoptr i64 %s to ptr
  %hh$2Eoff = bitcast i64 296 to i64
  %hh.p.gep = getelementptr inbounds i8, ptr %hh$2Eptr, i64 %hh$2Eoff
  %hh = load i64, ptr %hh.p.gep
  %below$2Ea$2Eone = bitcast i64 1 to i64
  %below$2Ea$2Esh = bitcast i64 63 to i64
  %below$2Ea$2Emin.p.m = and i64 %below$2Ea$2Esh, 63
  %below$2Ea$2Emin = shl i64 %below$2Ea$2Eone, %below$2Ea$2Emin.p.m
  %below$2Ea = xor i64 %w, %below$2Ea$2Emin
  %below$2Eb$2Eone = bitcast i64 1 to i64
  %below$2Eb$2Esh = bitcast i64 63 to i64
  %below$2Eb$2Emin.p.m = and i64 %below$2Eb$2Esh, 63
  %below$2Eb$2Emin = shl i64 %below$2Eb$2Eone, %below$2Eb$2Emin.p.m
  %below$2Eb = xor i64 %hl, %below$2Eb$2Emin
  %below = icmp slt i64 %below$2Ea, %below$2Eb
  %above$2Ea$2Eone = bitcast i64 1 to i64
  %above$2Ea$2Esh = bitcast i64 63 to i64
  %above$2Ea$2Emin.p.m = and i64 %above$2Ea$2Esh, 63
  %above$2Ea$2Emin = shl i64 %above$2Ea$2Eone, %above$2Ea$2Emin.p.m
  %above$2Ea = xor i64 %hh, %above$2Ea$2Emin
  %above$2Eb$2Eone = bitcast i64 1 to i64
  %above$2Eb$2Esh = bitcast i64 63 to i64
  %above$2Eb$2Emin.p.m = and i64 %above$2Eb$2Esh, 63
  %above$2Eb$2Emin = shl i64 %above$2Eb$2Eone, %above$2Eb$2Emin.p.m
  %above$2Eb = xor i64 %w, %above$2Eb$2Emin
  %above = icmp sle i64 %above$2Ea, %above$2Eb
  %out = or i1 %below, %above
  br i1 %out, label %bb.none, label %bb.page
bb.page:
  %base$2Ek = bitcast i64 -16384 to i64
  %base = and i64 %w, %base$2Ek
  %p = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EpageSetGet(i64 %base)
  %pz$2Ek = bitcast i64 0 to i64
  %pz = icmp eq i64 %p, %pz$2Ek
  br i1 %pz, label %bb.large, label %bb.inPage
bb.inPage:
  %first$2Ek = bitcast i64 512 to i64
  %first = add i64 %p, %first$2Ek
  %bel$2Ea$2Eone = bitcast i64 1 to i64
  %bel$2Ea$2Esh = bitcast i64 63 to i64
  %bel$2Ea$2Emin.p.m = and i64 %bel$2Ea$2Esh, 63
  %bel$2Ea$2Emin = shl i64 %bel$2Ea$2Eone, %bel$2Ea$2Emin.p.m
  %bel$2Ea = xor i64 %w, %bel$2Ea$2Emin
  %bel$2Eb$2Eone = bitcast i64 1 to i64
  %bel$2Eb$2Esh = bitcast i64 63 to i64
  %bel$2Eb$2Emin.p.m = and i64 %bel$2Eb$2Esh, 63
  %bel$2Eb$2Emin = shl i64 %bel$2Eb$2Eone, %bel$2Eb$2Emin.p.m
  %bel$2Eb = xor i64 %first, %bel$2Eb$2Emin
  %bel = icmp slt i64 %bel$2Ea, %bel$2Eb
  br i1 %bel, label %bb.none, label %bb.slot
bb.slot:
  %ss$2Eptr = inttoptr i64 %p to ptr
  %ss$2Eoff = bitcast i64 24 to i64
  %ss.p.gep = getelementptr inbounds i8, ptr %ss$2Eptr, i64 %ss$2Eoff
  %ss = load i64, ptr %ss.p.gep
  %rel = sub i64 %w, %first
  %idx.p.zero = icmp eq i64 %ss, 0
  %idx.p.min = icmp eq i64 %rel, -9223372036854775808
  %idx.p.neg = icmp eq i64 %ss, -1
  %idx.p.over = and i1 %idx.p.min, %idx.p.neg
  %idx.p.bad = or i1 %idx.p.zero, %idx.p.over
  br i1 %idx.p.bad, label %idx.p.trap, label %idx.p.ok
idx.p.trap:
  call void @llvm.trap()
  unreachable
idx.p.ok:
  %idx = sdiv i64 %rel, %ss
  %cnt$2Eptr = inttoptr i64 %p to ptr
  %cnt$2Eoff = bitcast i64 32 to i64
  %cnt.p.gep = getelementptr inbounds i8, ptr %cnt$2Eptr, i64 %cnt$2Eoff
  %cnt = load i64, ptr %cnt.p.gep
  %oob = icmp sge i64 %idx, %cnt
  br i1 %oob, label %bb.none, label %bb.bit
bb.bit:
  %word$2Ek = bitcast i64 6 to i64
  %word.p.m = and i64 %word$2Ek, 63
  %word = lshr i64 %idx, %word.p.m
  %wbase$2Ek = bitcast i64 72 to i64
  %wbase = add i64 %p, %wbase$2Ek
  %wat$2Em$2Ek = bitcast i64 8 to i64
  %wat$2Em = mul i64 %word, %wat$2Em$2Ek
  %wat = add i64 %wbase, %wat$2Em
  %wv$2Eptr = inttoptr i64 %wat to ptr
  %wv$2Eoff = bitcast i64 0 to i64
  %wv.p.gep = getelementptr inbounds i8, ptr %wv$2Eptr, i64 %wv$2Eoff
  %wv = load i64, ptr %wv.p.gep
  %bn$2Ek = bitcast i64 63 to i64
  %bn = and i64 %idx, %bn$2Ek
  %sh.p.m = and i64 %bn, 63
  %sh = lshr i64 %wv, %sh.p.m
  %b$2Ek = bitcast i64 1 to i64
  %b = and i64 %sh, %b$2Ek
  %clear$2Ek = bitcast i64 0 to i64
  %clear = icmp eq i64 %b, %clear$2Ek
  br i1 %clear, label %bb.none, label %bb.hit
bb.hit:
  %off = mul i64 %idx, %ss
  %o = add i64 %first, %off
  ret i64 %o
bb.large:
  %n$2Eptr = inttoptr i64 %s to ptr
  %n$2Eoff = bitcast i64 264 to i64
  %n.p.gep = getelementptr inbounds i8, ptr %n$2Eptr, i64 %n$2Eoff
  %n = load i64, ptr %n.p.gep
  %nz$2Ek = bitcast i64 0 to i64
  %nz = icmp eq i64 %n, %nz$2Ek
  br i1 %nz, label %bb.none, label %bb.sorted
bb.sorted:
  %srt$2Eptr = inttoptr i64 %s to ptr
  %srt$2Eoff = bitcast i64 280 to i64
  %srt.p.gep = getelementptr inbounds i8, ptr %srt$2Eptr, i64 %srt$2Eoff
  %srt = load i64, ptr %srt.p.gep
  %unsorted$2Ek = bitcast i64 0 to i64
  %unsorted = icmp eq i64 %srt, %unsorted$2Ek
  br i1 %unsorted, label %bb.sort, label %bb.search
bb.sort:
  %ix$2Eptr = inttoptr i64 %s to ptr
  %ix$2Eoff = bitcast i64 256 to i64
  %ix.p.gep = getelementptr inbounds i8, ptr %ix$2Eptr, i64 %ix$2Eoff
  %ix = load i64, ptr %ix.p.gep
  %q = call tailcc i64 @gcAslSortLarge(i64 %ix, i64 %n)
  %w1$2Ev = bitcast i64 1 to i64
  %w1$2Eptr = inttoptr i64 %s to ptr
  %w1$2Eoff = bitcast i64 280 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %w1$2Ev, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  br label %bb.search
bb.search:
  %idxs$2Eptr = inttoptr i64 %s to ptr
  %idxs$2Eoff = bitcast i64 256 to i64
  %idxs.p.gep = getelementptr inbounds i8, ptr %idxs$2Eptr, i64 %idxs$2Eoff
  %idxs = load i64, ptr %idxs.p.gep
  %l0 = bitcast i64 0 to i64
  br label %bb.bs
bb.bs:
  %l = phi i64 [ %l0, %bb.search ], [ %mid1, %bb.bsBody.e0 ], [ %l, %bb.bsBody.e1 ]
  %h = phi i64 [ %n, %bb.search ], [ %h, %bb.bsBody.e0 ], [ %mid, %bb.bsBody.e1 ]
  %more = icmp slt i64 %l, %h
  br i1 %more, label %bb.bsBody, label %bb.bsDone
bb.bsBody:
  %span = sub i64 %h, %l
  %half$2Ek = bitcast i64 1 to i64
  %half.p.m = and i64 %half$2Ek, 63
  %half = lshr i64 %span, %half.p.m
  %mid = add i64 %l, %half
  %mat$2Em$2Ek = bitcast i64 8 to i64
  %mat$2Em = mul i64 %mid, %mat$2Em$2Ek
  %mat = add i64 %idxs, %mat$2Em
  %e$2Eptr = inttoptr i64 %mat to ptr
  %e$2Eoff = bitcast i64 0 to i64
  %e.p.gep = getelementptr inbounds i8, ptr %e$2Eptr, i64 %e$2Eoff
  %e = load i64, ptr %e.p.gep
  %le$2Ea$2Eone = bitcast i64 1 to i64
  %le$2Ea$2Esh = bitcast i64 63 to i64
  %le$2Ea$2Emin.p.m = and i64 %le$2Ea$2Esh, 63
  %le$2Ea$2Emin = shl i64 %le$2Ea$2Eone, %le$2Ea$2Emin.p.m
  %le$2Ea = xor i64 %e, %le$2Ea$2Emin
  %le$2Eb$2Eone = bitcast i64 1 to i64
  %le$2Eb$2Esh = bitcast i64 63 to i64
  %le$2Eb$2Emin.p.m = and i64 %le$2Eb$2Esh, 63
  %le$2Eb$2Emin = shl i64 %le$2Eb$2Eone, %le$2Eb$2Emin.p.m
  %le$2Eb = xor i64 %w, %le$2Eb$2Emin
  %le = icmp sle i64 %le$2Ea, %le$2Eb
  %mid1$2Ek = bitcast i64 1 to i64
  %mid1 = add i64 %mid, %mid1$2Ek
  br i1 %le, label %bb.bsBody.e0, label %bb.bsBody.e1
bb.bsBody.e0:
  br label %bb.bs
bb.bsBody.e1:
  br label %bb.bs
bb.bsDone:
  %lz$2Ek = bitcast i64 0 to i64
  %lz = icmp eq i64 %l, %lz$2Ek
  br i1 %lz, label %bb.none, label %bb.pick
bb.pick:
  %lm1$2Ek = bitcast i64 -1 to i64
  %lm1 = add i64 %l, %lm1$2Ek
  %pat$2Em$2Ek = bitcast i64 8 to i64
  %pat$2Em = mul i64 %lm1, %pat$2Em$2Ek
  %pat = add i64 %idxs, %pat$2Em
  %lob$2Eptr = inttoptr i64 %pat to ptr
  %lob$2Eoff = bitcast i64 0 to i64
  %lob.p.gep = getelementptr inbounds i8, ptr %lob$2Eptr, i64 %lob$2Eoff
  %lob = load i64, ptr %lob.p.gep
  %start$2Ek = bitcast i64 24 to i64
  %start = add i64 %lob, %start$2Ek
  %ge$2Ea$2Eone = bitcast i64 1 to i64
  %ge$2Ea$2Esh = bitcast i64 63 to i64
  %ge$2Ea$2Emin.p.m = and i64 %ge$2Ea$2Esh, 63
  %ge$2Ea$2Emin = shl i64 %ge$2Ea$2Eone, %ge$2Ea$2Emin.p.m
  %ge$2Ea = xor i64 %start, %ge$2Ea$2Emin
  %ge$2Eb$2Eone = bitcast i64 1 to i64
  %ge$2Eb$2Esh = bitcast i64 63 to i64
  %ge$2Eb$2Emin.p.m = and i64 %ge$2Eb$2Esh, 63
  %ge$2Eb$2Emin = shl i64 %ge$2Eb$2Eone, %ge$2Eb$2Emin.p.m
  %ge$2Eb = xor i64 %w, %ge$2Eb$2Emin
  %ge = icmp sle i64 %ge$2Ea, %ge$2Eb
  br i1 %ge, label %bb.spanCheck, label %bb.none
bb.spanCheck:
  %d = sub i64 %w, %start
  %lspan$2Eptr = inttoptr i64 %lob to ptr
  %lspan$2Eoff = bitcast i64 16 to i64
  %lspan.p.gep = getelementptr inbounds i8, ptr %lspan$2Eptr, i64 %lspan$2Eoff
  %lspan = load i64, ptr %lspan.p.gep
  %inside$2Ea$2Eone = bitcast i64 1 to i64
  %inside$2Ea$2Esh = bitcast i64 63 to i64
  %inside$2Ea$2Emin.p.m = and i64 %inside$2Ea$2Esh, 63
  %inside$2Ea$2Emin = shl i64 %inside$2Ea$2Eone, %inside$2Ea$2Emin.p.m
  %inside$2Ea = xor i64 %d, %inside$2Ea$2Emin
  %inside$2Eb$2Eone = bitcast i64 1 to i64
  %inside$2Eb$2Esh = bitcast i64 63 to i64
  %inside$2Eb$2Emin.p.m = and i64 %inside$2Eb$2Esh, 63
  %inside$2Eb$2Emin = shl i64 %inside$2Eb$2Eone, %inside$2Eb$2Emin.p.m
  %inside$2Eb = xor i64 %lspan, %inside$2Eb$2Emin
  %inside = icmp slt i64 %inside$2Ea, %inside$2Eb
  br i1 %inside, label %bb.retStart, label %bb.none
bb.retStart:
  ret i64 %start
bb.none:
  %none$2Ez = bitcast i64 0 to i64
  ret i64 %none$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EscanConservative(i64 %lo, i64 %hi) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %c$2Eptr = inttoptr i64 %s to ptr
  %c$2Eoff = bitcast i64 304 to i64
  %c.p.gep = getelementptr inbounds i8, ptr %c$2Eptr, i64 %c$2Eoff
  %c = load i64, ptr %c.p.gep
  %idle$2Ek = bitcast i64 0 to i64
  %idle = icmp eq i64 %c, %idle$2Ek
  br i1 %idle, label %bb.idle, label %bb.range
bb.idle:
  %idle$2Ec = bitcast ptr @str.0 to ptr
  %idle$2Ef = bitcast ptr @str.10 to ptr
  %idle$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %idle$2Ec, ptr %idle$2Ef)
  %idle$2Ez = bitcast i64 0 to i64
  ret i64 %idle$2Ez
bb.range:
  %inv$2Ea$2Eone = bitcast i64 1 to i64
  %inv$2Ea$2Esh = bitcast i64 63 to i64
  %inv$2Ea$2Emin.p.m = and i64 %inv$2Ea$2Esh, 63
  %inv$2Ea$2Emin = shl i64 %inv$2Ea$2Eone, %inv$2Ea$2Emin.p.m
  %inv$2Ea = xor i64 %hi, %inv$2Ea$2Emin
  %inv$2Eb$2Eone = bitcast i64 1 to i64
  %inv$2Eb$2Esh = bitcast i64 63 to i64
  %inv$2Eb$2Emin.p.m = and i64 %inv$2Eb$2Esh, 63
  %inv$2Eb$2Emin = shl i64 %inv$2Eb$2Eone, %inv$2Eb$2Emin.p.m
  %inv$2Eb = xor i64 %lo, %inv$2Eb$2Emin
  %inv = icmp slt i64 %inv$2Ea, %inv$2Eb
  br i1 %inv, label %bb.inverted, label %bb.scan
bb.inverted:
  %lop = inttoptr i64 %lo to ptr
  %hip = inttoptr i64 %hi to ptr
  %inverted$2Ec = bitcast ptr @str.0 to ptr
  %inverted$2Ef = bitcast ptr @str.11 to ptr
  %inverted$2Ebi = call tailcc i64 @gcAslFailBuf()
  %inverted$2Eb = inttoptr i64 %inverted$2Ebi to ptr
  %inverted$2Ecap = bitcast i64 1024 to i64
  %inverted$2En = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %inverted$2Eb, i64 %inverted$2Ecap, ptr %inverted$2Ef, ptr %lop, ptr %hip)
  %inverted$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %inverted$2Ec, ptr %inverted$2Eb)
  %inverted$2Ez = bitcast i64 0 to i64
  ret i64 %inverted$2Ez
bb.scan:
  %lo7$2Ek = bitcast i64 7 to i64
  %lo7 = add i64 %lo, %lo7$2Ek
  %a0$2Ek = bitcast i64 -8 to i64
  %a0 = and i64 %lo7, %a0$2Ek
  br label %bb.loop
bb.loop:
  %a = phi i64 [ %a0, %bb.scan ], [ %a1, %bb.next ]
  %end$2Ek = bitcast i64 8 to i64
  %end = add i64 %a, %end$2Ek
  %fits$2Ea$2Eone = bitcast i64 1 to i64
  %fits$2Ea$2Esh = bitcast i64 63 to i64
  %fits$2Ea$2Emin.p.m = and i64 %fits$2Ea$2Esh, 63
  %fits$2Ea$2Emin = shl i64 %fits$2Ea$2Eone, %fits$2Ea$2Emin.p.m
  %fits$2Ea = xor i64 %end, %fits$2Ea$2Emin
  %fits$2Eb$2Eone = bitcast i64 1 to i64
  %fits$2Eb$2Esh = bitcast i64 63 to i64
  %fits$2Eb$2Emin.p.m = and i64 %fits$2Eb$2Esh, 63
  %fits$2Eb$2Emin = shl i64 %fits$2Eb$2Eone, %fits$2Eb$2Emin.p.m
  %fits$2Eb = xor i64 %hi, %fits$2Eb$2Emin
  %fits = icmp sle i64 %fits$2Ea, %fits$2Eb
  br i1 %fits, label %bb.body, label %bb.done
bb.body:
  %w$2Eptr = inttoptr i64 %a to ptr
  %w$2Eoff = bitcast i64 0 to i64
  %w.p.gep = getelementptr inbounds i8, ptr %w$2Eptr, i64 %w$2Eoff
  %w = load i64, ptr %w.p.gep
  %o = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EfindObj(i64 %w)
  %oz$2Ek = bitcast i64 0 to i64
  %oz = icmp eq i64 %o, %oz$2Ek
  br i1 %oz, label %bb.next, label %bb.mark
bb.mark:
  %m = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmarkObj(i64 %o)
  %d = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Edrain()
  br label %bb.next
bb.next:
  %a1$2Ek = bitcast i64 8 to i64
  %a1 = add i64 %a, %a1$2Ek
  br label %bb.loop
bb.done:
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmonoNs() {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %ts$2Ek = bitcast i64 336 to i64
  %ts = add i64 %s, %ts$2Ek
  %tsp = inttoptr i64 %ts to ptr
  %clk = bitcast i32 6 to i32
  %r = call i32 (i32, ptr) @clock_gettime(i32 %clk, ptr %tsp)
  %sec$2Eptr = inttoptr i64 %ts to ptr
  %sec$2Eoff = bitcast i64 0 to i64
  %sec.p.gep = getelementptr inbounds i8, ptr %sec$2Eptr, i64 %sec$2Eoff
  %sec = load i64, ptr %sec.p.gep
  %nsec$2Eptr = inttoptr i64 %ts to ptr
  %nsec$2Eoff = bitcast i64 8 to i64
  %nsec.p.gep = getelementptr inbounds i8, ptr %nsec$2Eptr, i64 %nsec$2Eoff
  %nsec = load i64, ptr %nsec.p.gep
  %sns$2Ek = bitcast i64 1000000000 to i64
  %sns = mul i64 %sec, %sns$2Ek
  %t = add i64 %sns, %nsec
  ret i64 %t
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Ebegin() {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %on$2Eptr = inttoptr i64 %s to ptr
  %on$2Eoff = bitcast i64 48 to i64
  %on.p.gep = getelementptr inbounds i8, ptr %on$2Eptr, i64 %on$2Eoff
  %on = load i64, ptr %on.p.gep
  %c$2Eby = bitcast i64 1 to i64
  %c$2Eold$2Eptr = inttoptr i64 %s to ptr
  %c$2Eold$2Eoff = bitcast i64 64 to i64
  %c$2Eold.p.gep = getelementptr inbounds i8, ptr %c$2Eold$2Eptr, i64 %c$2Eold$2Eoff
  %c$2Eold = load i64, ptr %c$2Eold.p.gep
  %c$2Enew = add i64 %c$2Eold, %c$2Eby
  %c$2Eptr = inttoptr i64 %s to ptr
  %c$2Eoff = bitcast i64 64 to i64
  %c.p.gep = getelementptr inbounds i8, ptr %c$2Eptr, i64 %c$2Eoff
  store i64 %c$2Enew, ptr %c.p.gep
  %c = bitcast i1 true to i1
  %timed$2Ek = bitcast i64 0 to i64
  %timed = icmp ne i64 %on, %timed$2Ek
  br i1 %timed, label %bb.timed, label %bb.untimed
bb.timed:
  %t = musttail call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmonoNs()
  ret i64 %t
bb.untimed:
  %untimed$2Ez = bitcast i64 0 to i64
  ret i64 %untimed$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Estamp(i64 %slot, i64 %since) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %on$2Eptr = inttoptr i64 %s to ptr
  %on$2Eoff = bitcast i64 48 to i64
  %on.p.gep = getelementptr inbounds i8, ptr %on$2Eptr, i64 %on$2Eoff
  %on = load i64, ptr %on.p.gep
  %timed$2Ek = bitcast i64 0 to i64
  %timed = icmp ne i64 %on, %timed$2Ek
  br i1 %timed, label %bb.timed, label %bb.off
bb.timed:
  %now = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmonoNs()
  %dt = sub i64 %now, %since
  %off$2Ek = bitcast i64 8 to i64
  %off = mul i64 %slot, %off$2Ek
  %at = add i64 %s, %off
  %old$2Eptr = inttoptr i64 %at to ptr
  %old$2Eoff = bitcast i64 0 to i64
  %old.p.gep = getelementptr inbounds i8, ptr %old$2Eptr, i64 %old$2Eoff
  %old = load i64, ptr %old.p.gep
  %new = add i64 %old, %dt
  %w$2Eptr = inttoptr i64 %at to ptr
  %w$2Eoff = bitcast i64 0 to i64
  %w.p.gep = getelementptr inbounds i8, ptr %w$2Eptr, i64 %w$2Eoff
  store i64 %new, ptr %w.p.gep
  %w = bitcast i1 true to i1
  ret i64 %now
bb.off:
  %off$2Ez = bitcast i64 0 to i64
  ret i64 %off$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EsweepLarge(i64 %guard, i64 %fe) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %n$2Eptr = inttoptr i64 %s to ptr
  %n$2Eoff = bitcast i64 264 to i64
  %n.p.gep = getelementptr inbounds i8, ptr %n$2Eptr, i64 %n$2Eoff
  %n = load i64, ptr %n.p.gep
  %idx$2Eptr = inttoptr i64 %s to ptr
  %idx$2Eoff = bitcast i64 256 to i64
  %idx.p.gep = getelementptr inbounds i8, ptr %idx$2Eptr, i64 %idx$2Eoff
  %idx = load i64, ptr %idx.p.gep
  %z0 = bitcast i64 0 to i64
  br label %bb.cloop
bb.cloop:
  %i = phi i64 [ %z0, %bb.entry ], [ %i1, %bb.cnext ]
  %kept = phi i64 [ %z0, %bb.entry ], [ %kn, %bb.cnext ]
  %cmore = icmp slt i64 %i, %n
  br i1 %cmore, label %bb.cbody, label %bb.cdone
bb.cbody:
  %ia$2Em$2Ek = bitcast i64 8 to i64
  %ia$2Em = mul i64 %i, %ia$2Em$2Ek
  %ia = add i64 %idx, %ia$2Em
  %l$2Eptr = inttoptr i64 %ia to ptr
  %l$2Eoff = bitcast i64 0 to i64
  %l.p.gep = getelementptr inbounds i8, ptr %l$2Eptr, i64 %l$2Eoff
  %l = load i64, ptr %l.p.gep
  %lm$2Eptr = inttoptr i64 %l to ptr
  %lm$2Eoff = bitcast i64 29 to i64
  %lm$2Ew.p.gep = getelementptr inbounds i8, ptr %lm$2Eptr, i64 %lm$2Eoff
  %lm$2Ew.p.raw = load i8, ptr %lm$2Ew.p.gep
  %lm$2Ew = zext i8 %lm$2Ew.p.raw to i32
  %lm = sext i32 %lm$2Ew to i64
  %lmarked$2Ek = bitcast i64 0 to i64
  %lmarked = icmp ne i64 %lm, %lmarked$2Ek
  br i1 %lmarked, label %bb.keep, label %bb.cnext
bb.keep:
  %ka$2Em$2Ek = bitcast i64 8 to i64
  %ka$2Em = mul i64 %kept, %ka$2Em$2Ek
  %ka = add i64 %idx, %ka$2Em
  %wk$2Eptr = inttoptr i64 %ka to ptr
  %wk$2Eoff = bitcast i64 0 to i64
  %wk.p.gep = getelementptr inbounds i8, ptr %wk$2Eptr, i64 %wk$2Eoff
  store i64 %l, ptr %wk.p.gep
  %wk = bitcast i1 true to i1
  %kept1$2Ek = bitcast i64 1 to i64
  %kept1 = add i64 %kept, %kept1$2Ek
  br label %bb.cnext
bb.cnext:
  %kn = phi i64 [ %kept, %bb.cbody ], [ %kept1, %bb.keep ]
  %i1$2Ek = bitcast i64 1 to i64
  %i1 = add i64 %i, %i1$2Ek
  br label %bb.cloop
bb.cdone:
  %wn$2Eptr = inttoptr i64 %s to ptr
  %wn$2Eoff = bitcast i64 264 to i64
  %wn.p.gep = getelementptr inbounds i8, ptr %wn$2Eptr, i64 %wn$2Eoff
  store i64 %kept, ptr %wn.p.gep
  %wn = bitcast i1 true to i1
  %head$2Ek = bitcast i64 224 to i64
  %head = add i64 %s, %head$2Ek
  br label %bb.lloop
bb.lloop:
  %prev = phi i64 [ %head, %bb.cdone ], [ %lo, %bb.lkeep ], [ %prev, %bb.release ]
  %live = phi i64 [ %z0, %bb.cdone ], [ %live1, %bb.lkeep ], [ %live, %bb.release ]
  %lo$2Eptr = inttoptr i64 %prev to ptr
  %lo$2Eoff = bitcast i64 0 to i64
  %lo.p.gep = getelementptr inbounds i8, ptr %lo$2Eptr, i64 %lo$2Eoff
  %lo = load i64, ptr %lo.p.gep
  %lz$2Ek = bitcast i64 0 to i64
  %lz = icmp eq i64 %lo, %lz$2Ek
  br i1 %lz, label %bb.ldone, label %bb.lbody
bb.lbody:
  %m$2Eptr = inttoptr i64 %lo to ptr
  %m$2Eoff = bitcast i64 29 to i64
  %m$2Ew.p.gep = getelementptr inbounds i8, ptr %m$2Eptr, i64 %m$2Eoff
  %m$2Ew.p.raw = load i8, ptr %m$2Ew.p.gep
  %m$2Ew = zext i8 %m$2Ew.p.raw to i32
  %m = sext i32 %m$2Ew to i64
  %marked$2Ek = bitcast i64 0 to i64
  %marked = icmp ne i64 %m, %marked$2Ek
  br i1 %marked, label %bb.lkeep, label %bb.lfree
bb.lkeep:
  %um$2Eptr = inttoptr i64 %lo to ptr
  %um$2Eoff = bitcast i64 29 to i64
  %um$2Ev = bitcast i32 0 to i32
  %um.p.gep = getelementptr inbounds i8, ptr %um$2Eptr, i64 %um$2Eoff
  %um.p.trunc = trunc i32 %um$2Ev to i8
  store i8 %um.p.trunc, ptr %um.p.gep
  %um = bitcast i1 true to i1
  %lb$2Eptr = inttoptr i64 %lo to ptr
  %lb$2Eoff = bitcast i64 8 to i64
  %lb.p.gep = getelementptr inbounds i8, ptr %lb$2Eptr, i64 %lb$2Eoff
  %lb = load i64, ptr %lb.p.gep
  %live1 = add i64 %live, %lb
  br label %bb.lloop
bb.lfree:
  %lnx$2Eptr = inttoptr i64 %lo to ptr
  %lnx$2Eoff = bitcast i64 0 to i64
  %lnx.p.gep = getelementptr inbounds i8, ptr %lnx$2Eptr, i64 %lnx$2Eoff
  %lnx = load i64, ptr %lnx.p.gep
  %wu$2Eptr = inttoptr i64 %prev to ptr
  %wu$2Eoff = bitcast i64 0 to i64
  %wu.p.gep = getelementptr inbounds i8, ptr %wu$2Eptr, i64 %wu$2Eoff
  store i64 %lnx, ptr %wu.p.gep
  %wu = bitcast i1 true to i1
  %type$2Eptr = inttoptr i64 %lo to ptr
  %type$2Eoff = bitcast i64 28 to i64
  %type$2Ew.p.gep = getelementptr inbounds i8, ptr %type$2Eptr, i64 %type$2Eoff
  %type$2Ew.p.raw = load i8, ptr %type$2Ew.p.gep
  %type$2Ew = zext i8 %type$2Ew.p.raw to i32
  %type = sext i32 %type$2Ew to i64
  %isArr$2Ek = bitcast i64 6 to i64
  %isArr = icmp eq i64 %type, %isArr$2Ek
  br i1 %isArr, label %bb.freeData, label %bb.handle
bb.freeData:
  %data$2Eptr = inttoptr i64 %lo to ptr
  %data$2Eoff = bitcast i64 48 to i64
  %data.p.gep = getelementptr inbounds i8, ptr %data$2Eptr, i64 %data$2Eoff
  %data = load i64, ptr %data.p.gep
  %dp = inttoptr i64 %data to ptr
  %fd = call i64 (ptr) @free(ptr %dp)
  br label %bb.handle
bb.handle:
  %isHandle$2Ek = bitcast i64 7 to i64
  %isHandle = icmp eq i64 %type, %isHandle$2Ek
  br i1 %isHandle, label %bb.hfin, label %bb.release
bb.hfin:
  %fin$2Eptr = inttoptr i64 %lo to ptr
  %fin$2Eoff = bitcast i64 48 to i64
  %fin.p.gep = getelementptr inbounds i8, ptr %fin$2Eptr, i64 %fin$2Eoff
  %fin = load i64, ptr %fin.p.gep
  %nofin$2Ek = bitcast i64 0 to i64
  %nofin = icmp eq i64 %fin, %nofin$2Ek
  br i1 %nofin, label %bb.release, label %bb.hcall
bb.hcall:
  %harg$2Eptr = inttoptr i64 %lo to ptr
  %harg$2Eoff = bitcast i64 40 to i64
  %harg.p.gep = getelementptr inbounds i8, ptr %harg$2Eptr, i64 %harg$2Eoff
  %harg = load i64, ptr %harg.p.gep
  %plain$2Ek = bitcast i64 0 to i64
  %plain = icmp eq i64 %guard, %plain$2Ek
  br i1 %plain, label %bb.hplain, label %bb.hguard
bb.hplain:
  %fr = call tailcc i64 @gcAslCallFin(i64 %fin, i64 %harg)
  br label %bb.release
bb.hguard:
  %gr = call tailcc i64 @gcAslFinGuarded(i64 %fin, i64 %harg, i64 %guard)
  %raised$2Ek = bitcast i64 0 to i64
  %raised = icmp ne i64 %gr, %raised$2Ek
  br i1 %raised, label %bb.hraised, label %bb.release
bb.hraised:
  %f0$2Eptr = inttoptr i64 %fe to ptr
  %f0$2Eoff = bitcast i64 0 to i64
  %f0$2Ew.p.gep = getelementptr inbounds i8, ptr %f0$2Eptr, i64 %f0$2Eoff
  %f0$2Ew.p.raw = load i8, ptr %f0$2Ew.p.gep
  %f0$2Ew = zext i8 %f0$2Ew.p.raw to i32
  %f0 = sext i32 %f0$2Ew to i64
  %firstErr$2Ek = bitcast i64 0 to i64
  %firstErr = icmp eq i64 %f0, %firstErr$2Ek
  br i1 %firstErr, label %bb.hsize, label %bb.release
bb.hsize:
  %msz$2Eptr = inttoptr i64 %guard to ptr
  %msz$2Eoff = bitcast i64 32 to i64
  %msz.p.gep = getelementptr inbounds i8, ptr %msz$2Eptr, i64 %msz$2Eoff
  %msz = load i64, ptr %msz.p.gep
  %cap = bitcast i64 4096 to i64
  %smaller$2Ea$2Eone = bitcast i64 1 to i64
  %smaller$2Ea$2Esh = bitcast i64 63 to i64
  %smaller$2Ea$2Emin.p.m = and i64 %smaller$2Ea$2Esh, 63
  %smaller$2Ea$2Emin = shl i64 %smaller$2Ea$2Eone, %smaller$2Ea$2Emin.p.m
  %smaller$2Ea = xor i64 %msz, %smaller$2Ea$2Emin
  %smaller$2Eb$2Eone = bitcast i64 1 to i64
  %smaller$2Eb$2Esh = bitcast i64 63 to i64
  %smaller$2Eb$2Emin.p.m = and i64 %smaller$2Eb$2Esh, 63
  %smaller$2Eb$2Emin = shl i64 %smaller$2Eb$2Eone, %smaller$2Eb$2Emin.p.m
  %smaller$2Eb = xor i64 %cap, %smaller$2Eb$2Emin
  %smaller = icmp slt i64 %smaller$2Ea, %smaller$2Eb
  br i1 %smaller, label %bb.hsize.e0, label %bb.hsize.e1
bb.hsize.e0:
  br label %bb.hcopy
bb.hsize.e1:
  br label %bb.hcopy
bb.hcopy:
  %cn = phi i64 [ %msz, %bb.hsize.e0 ], [ %cap, %bb.hsize.e1 ]
  %cnz$2Ek = bitcast i64 0 to i64
  %cnz = icmp ne i64 %cn, %cnz$2Ek
  br i1 %cnz, label %bb.hcopy2, label %bb.release
bb.hcopy2:
  %msg$2Eptr = inttoptr i64 %guard to ptr
  %msg$2Eoff = bitcast i64 24 to i64
  %msg.p.gep = getelementptr inbounds i8, ptr %msg$2Eptr, i64 %msg$2Eoff
  %msg = load i64, ptr %msg.p.gep
  %fep = inttoptr i64 %fe to ptr
  %msgp = inttoptr i64 %msg to ptr
  %mc = call ptr (ptr, ptr, i64) @memcpy(ptr %fep, ptr %msgp, i64 %cn)
  %endAt = add i64 %fe, %cn
  %nul$2Eptr = inttoptr i64 %endAt to ptr
  %nul$2Eoff = bitcast i64 -1 to i64
  %nul$2Ev = bitcast i32 0 to i32
  %nul.p.gep = getelementptr inbounds i8, ptr %nul$2Eptr, i64 %nul$2Eoff
  %nul.p.trunc = trunc i32 %nul$2Ev to i8
  store i8 %nul.p.trunc, ptr %nul.p.gep
  %nul = bitcast i1 true to i1
  br label %bb.release
bb.release:
  %lop = inttoptr i64 %lo to ptr
  %fl = call i64 (ptr) @free(ptr %lop)
  %freed$2Eby = bitcast i64 1 to i64
  %freed$2Eold$2Eptr = inttoptr i64 %s to ptr
  %freed$2Eold$2Eoff = bitcast i64 80 to i64
  %freed$2Eold.p.gep = getelementptr inbounds i8, ptr %freed$2Eold$2Eptr, i64 %freed$2Eold$2Eoff
  %freed$2Eold = load i64, ptr %freed$2Eold.p.gep
  %freed$2Enew = add i64 %freed$2Eold, %freed$2Eby
  %freed$2Eptr = inttoptr i64 %s to ptr
  %freed$2Eoff = bitcast i64 80 to i64
  %freed.p.gep = getelementptr inbounds i8, ptr %freed$2Eptr, i64 %freed$2Eoff
  store i64 %freed$2Enew, ptr %freed.p.gep
  %freed = bitcast i1 true to i1
  br label %bb.lloop
bb.ldone:
  ret i64 %live
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EsweepPages(i64 %live) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %sc0 = bitcast i64 0 to i64
  br label %bb.cloop
bb.cloop:
  %sc = phi i64 [ %sc0, %bb.entry ], [ %sc1, %bb.cnext ]
  %lv = phi i64 [ %live, %bb.entry ], [ %lv7, %bb.cnext ]
  %cmore$2Ek = bitcast i64 63 to i64
  %cmore = icmp slt i64 %sc, %cmore$2Ek
  br i1 %cmore, label %bb.cbody, label %bb.done
bb.cbody:
  %ca$2Em$2Ek = bitcast i64 24 to i64
  %ca$2Em = mul i64 %sc, %ca$2Em$2Ek
  %ca$2Ea = add i64 %s, %ca$2Em
  %ca$2Ek = bitcast i64 512 to i64
  %ca = add i64 %ca$2Ea, %ca$2Ek
  %w1$2Ev = bitcast i64 0 to i64
  %w1$2Eptr = inttoptr i64 %ca to ptr
  %w1$2Eoff = bitcast i64 8 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %w1$2Ev, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  %w2$2Ev = bitcast i64 0 to i64
  %w2$2Eptr = inttoptr i64 %ca to ptr
  %w2$2Eoff = bitcast i64 16 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %w2$2Ev, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  br label %bb.ploop
bb.ploop:
  %pp = phi i64 [ %ca, %bb.cbody ], [ %pp, %bb.pfree ], [ %p, %bb.pnext ]
  %lv2 = phi i64 [ %lv, %bb.cbody ], [ %lv2, %bb.pfree ], [ %lv2, %bb.pnext ]
  %p$2Eptr = inttoptr i64 %pp to ptr
  %p$2Eoff = bitcast i64 0 to i64
  %p.p.gep = getelementptr inbounds i8, ptr %p$2Eptr, i64 %p$2Eoff
  %p = load i64, ptr %p.p.gep
  %pz$2Ek = bitcast i64 0 to i64
  %pz = icmp eq i64 %p, %pz$2Ek
  br i1 %pz, label %bb.cnext, label %bb.pbody
bb.pbody:
  %lim$2Eptr = inttoptr i64 %p to ptr
  %lim$2Eoff = bitcast i64 56 to i64
  %lim.p.gep = getelementptr inbounds i8, ptr %lim$2Eptr, i64 %lim$2Eoff
  %lim = load i64, ptr %lim.p.gep
  %lim63$2Ek = bitcast i64 63 to i64
  %lim63 = add i64 %lim, %lim63$2Ek
  %nw$2Ek = bitcast i64 6 to i64
  %nw.p.m = and i64 %nw$2Ek, 63
  %nw = lshr i64 %lim63, %nw.p.m
  %c0 = bitcast i64 0 to i64
  br label %bb.cntloop
bb.cntloop:
  %ck = phi i64 [ %c0, %bb.pbody ], [ %ck1, %bb.cntbody ]
  %cacc = phi i64 [ %c0, %bb.pbody ], [ %cacc1, %bb.cntbody ]
  %cmore2 = icmp slt i64 %ck, %nw
  br i1 %cmore2, label %bb.cntbody, label %bb.counted
bb.cntbody:
  %cko$2Ek = bitcast i64 3 to i64
  %cko.p.m = and i64 %cko$2Ek, 63
  %cko = shl i64 %ck, %cko.p.m
  %cua = add i64 %p, %cko
  %cmw$2Eptr = inttoptr i64 %cua to ptr
  %cmw$2Eoff = bitcast i64 200 to i64
  %cmw.p.gep = getelementptr inbounds i8, ptr %cmw$2Eptr, i64 %cmw$2Eoff
  %cmw = load i64, ptr %cmw.p.gep
  %cpc = call tailcc i64 @gcAslPopcount(i64 %cmw)
  %cacc1 = add i64 %cacc, %cpc
  %ck1$2Ek = bitcast i64 1 to i64
  %ck1 = add i64 %ck, %ck1$2Ek
  br label %bb.cntloop
bb.counted:
  %mc = phi i64 [ %cacc, %bb.cntloop ]
  %empty$2Ek = bitcast i64 0 to i64
  %empty = icmp eq i64 %mc, %empty$2Ek
  br i1 %empty, label %bb.pfree, label %bb.psweep
bb.pfree:
  %pnx$2Eptr = inttoptr i64 %p to ptr
  %pnx$2Eoff = bitcast i64 0 to i64
  %pnx.p.gep = getelementptr inbounds i8, ptr %pnx$2Eptr, i64 %pnx$2Eoff
  %pnx = load i64, ptr %pnx.p.gep
  %w3$2Eptr = inttoptr i64 %pp to ptr
  %w3$2Eoff = bitcast i64 0 to i64
  %w3.p.gep = getelementptr inbounds i8, ptr %w3$2Eptr, i64 %w3$2Eoff
  store i64 %pnx, ptr %w3.p.gep
  %w3 = bitcast i1 true to i1
  %ac$2Eptr = inttoptr i64 %p to ptr
  %ac$2Eoff = bitcast i64 40 to i64
  %ac.p.gep = getelementptr inbounds i8, ptr %ac$2Eptr, i64 %ac$2Eoff
  %ac = load i64, ptr %ac.p.gep
  %fr$2Eold$2Eptr = inttoptr i64 %s to ptr
  %fr$2Eold$2Eoff = bitcast i64 80 to i64
  %fr$2Eold.p.gep = getelementptr inbounds i8, ptr %fr$2Eold$2Eptr, i64 %fr$2Eold$2Eoff
  %fr$2Eold = load i64, ptr %fr$2Eold.p.gep
  %fr$2Enew = add i64 %fr$2Eold, %ac
  %fr$2Eptr = inttoptr i64 %s to ptr
  %fr$2Eoff = bitcast i64 80 to i64
  %fr.p.gep = getelementptr inbounds i8, ptr %fr$2Eptr, i64 %fr$2Eoff
  store i64 %fr$2Enew, ptr %fr.p.gep
  %fr = bitcast i1 true to i1
  %fp = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EfreePage(i64 %p)
  br label %bb.ploop
bb.psweep:
  %pac$2Eptr = inttoptr i64 %p to ptr
  %pac$2Eoff = bitcast i64 40 to i64
  %pac.p.gep = getelementptr inbounds i8, ptr %pac$2Eptr, i64 %pac$2Eoff
  %pac = load i64, ptr %pac.p.gep
  %dead = sub i64 %pac, %mc
  %fr2$2Eold$2Eptr = inttoptr i64 %s to ptr
  %fr2$2Eold$2Eoff = bitcast i64 80 to i64
  %fr2$2Eold.p.gep = getelementptr inbounds i8, ptr %fr2$2Eold$2Eptr, i64 %fr2$2Eold$2Eoff
  %fr2$2Eold = load i64, ptr %fr2$2Eold.p.gep
  %fr2$2Enew = add i64 %fr2$2Eold, %dead
  %fr2$2Eptr = inttoptr i64 %s to ptr
  %fr2$2Eoff = bitcast i64 80 to i64
  %fr2.p.gep = getelementptr inbounds i8, ptr %fr2$2Eptr, i64 %fr2$2Eoff
  store i64 %fr2$2Enew, ptr %fr2.p.gep
  %fr2 = bitcast i1 true to i1
  %k0 = bitcast i64 0 to i64
  br label %bb.wloop
bb.wloop:
  %kk = phi i64 [ %k0, %bb.psweep ], [ %kk1, %bb.wbody ]
  %wmore = icmp slt i64 %kk, %nw
  br i1 %wmore, label %bb.wbody, label %bb.sdone
bb.wbody:
  %ko$2Ek = bitcast i64 3 to i64
  %ko.p.m = and i64 %ko$2Ek, 63
  %ko = shl i64 %kk, %ko.p.m
  %ua = add i64 %p, %ko
  %u$2Eptr = inttoptr i64 %ua to ptr
  %u$2Eoff = bitcast i64 72 to i64
  %u.p.gep = getelementptr inbounds i8, ptr %u$2Eptr, i64 %u$2Eoff
  %u = load i64, ptr %u.p.gep
  %mk$2Eptr = inttoptr i64 %ua to ptr
  %mk$2Eoff = bitcast i64 200 to i64
  %mk.p.gep = getelementptr inbounds i8, ptr %mk$2Eptr, i64 %mk$2Eoff
  %mk = load i64, ptr %mk.p.gep
  %nu = and i64 %u, %mk
  %wu$2Eptr = inttoptr i64 %ua to ptr
  %wu$2Eoff = bitcast i64 72 to i64
  %wu.p.gep = getelementptr inbounds i8, ptr %wu$2Eptr, i64 %wu$2Eoff
  store i64 %nu, ptr %wu.p.gep
  %wu = bitcast i1 true to i1
  %wm$2Ev = bitcast i64 0 to i64
  %wm$2Eptr = inttoptr i64 %ua to ptr
  %wm$2Eoff = bitcast i64 200 to i64
  %wm.p.gep = getelementptr inbounds i8, ptr %wm$2Eptr, i64 %wm$2Eoff
  store i64 %wm$2Ev, ptr %wm.p.gep
  %wm = bitcast i1 true to i1
  %kk1$2Ek = bitcast i64 1 to i64
  %kk1 = add i64 %kk, %kk1$2Ek
  br label %bb.wloop
bb.sdone:
  %w8$2Eptr = inttoptr i64 %p to ptr
  %w8$2Eoff = bitcast i64 40 to i64
  %w8.p.gep = getelementptr inbounds i8, ptr %w8$2Eptr, i64 %w8$2Eoff
  store i64 %mc, ptr %w8.p.gep
  %w8 = bitcast i1 true to i1
  %limm1$2Ek = bitcast i64 -1 to i64
  %limm1 = add i64 %lim, %limm1$2Ek
  %cur$2Ek = bitcast i64 6 to i64
  %cur.p.m = and i64 %cur$2Ek, 63
  %cur = lshr i64 %limm1, %cur.p.m
  %w7$2Eptr = inttoptr i64 %p to ptr
  %w7$2Eoff = bitcast i64 64 to i64
  %w7.p.gep = getelementptr inbounds i8, ptr %w7$2Eptr, i64 %w7$2Eoff
  store i64 %cur, ptr %w7.p.gep
  %w7 = bitcast i1 true to i1
  %hasFree = icmp slt i64 %mc, %lim
  br i1 %hasFree, label %bb.pushFree, label %bb.activeCheck
bb.pushFree:
  %ffp$2Eptr = inttoptr i64 %ca to ptr
  %ffp$2Eoff = bitcast i64 8 to i64
  %ffp.p.gep = getelementptr inbounds i8, ptr %ffp$2Eptr, i64 %ffp$2Eoff
  %ffp = load i64, ptr %ffp.p.gep
  %w10$2Eptr = inttoptr i64 %p to ptr
  %w10$2Eoff = bitcast i64 8 to i64
  %w10.p.gep = getelementptr inbounds i8, ptr %w10$2Eptr, i64 %w10$2Eoff
  store i64 %ffp, ptr %w10.p.gep
  %w10 = bitcast i1 true to i1
  %w11$2Eptr = inttoptr i64 %ca to ptr
  %w11$2Eoff = bitcast i64 8 to i64
  %w11.p.gep = getelementptr inbounds i8, ptr %w11$2Eptr, i64 %w11$2Eoff
  store i64 %p, ptr %w11.p.gep
  %w11 = bitcast i1 true to i1
  br label %bb.pnext
bb.activeCheck:
  %act$2Eptr = inttoptr i64 %ca to ptr
  %act$2Eoff = bitcast i64 16 to i64
  %act.p.gep = getelementptr inbounds i8, ptr %act$2Eptr, i64 %act$2Eoff
  %act = load i64, ptr %act.p.gep
  %noAct$2Ek = bitcast i64 0 to i64
  %noAct = icmp eq i64 %act, %noAct$2Ek
  %cnt$2Eptr = inttoptr i64 %p to ptr
  %cnt$2Eoff = bitcast i64 32 to i64
  %cnt.p.gep = getelementptr inbounds i8, ptr %cnt$2Eptr, i64 %cnt$2Eoff
  %cnt = load i64, ptr %cnt.p.gep
  %roomy = icmp slt i64 %lim, %cnt
  %mkAct = and i1 %noAct, %roomy
  br i1 %mkAct, label %bb.setActive, label %bb.pnext
bb.setActive:
  %w12$2Eptr = inttoptr i64 %ca to ptr
  %w12$2Eoff = bitcast i64 16 to i64
  %w12.p.gep = getelementptr inbounds i8, ptr %w12$2Eptr, i64 %w12$2Eoff
  store i64 %p, ptr %w12.p.gep
  %w12 = bitcast i1 true to i1
  br label %bb.pnext
bb.pnext:
  br label %bb.ploop
bb.cnext:
  %lv7 = phi i64 [ %lv2, %bb.ploop ]
  %sc1$2Ek = bitcast i64 1 to i64
  %sc1 = add i64 %sc, %sc1$2Ek
  br label %bb.cloop
bb.done:
  %mb$2Eptr = inttoptr i64 %s to ptr
  %mb$2Eoff = bitcast i64 448 to i64
  %mb.p.gep = getelementptr inbounds i8, ptr %mb$2Eptr, i64 %mb$2Eoff
  %mb = load i64, ptr %mb.p.gep
  %lvAll = add i64 %lv, %mb
  %mb0$2Ev = bitcast i64 0 to i64
  %mb0$2Eptr = inttoptr i64 %s to ptr
  %mb0$2Eoff = bitcast i64 448 to i64
  %mb0.p.gep = getelementptr inbounds i8, ptr %mb0$2Eptr, i64 %mb0$2Eoff
  store i64 %mb0$2Ev, ptr %mb0.p.gep
  %mb0 = bitcast i1 true to i1
  %ep$2Eptr = inttoptr i64 %s to ptr
  %ep$2Eoff = bitcast i64 456 to i64
  %ep.p.gep = getelementptr inbounds i8, ptr %ep$2Eptr, i64 %ep$2Eoff
  %ep = load i64, ptr %ep.p.gep
  %k3 = bitcast i64 3 to i64
  %ep1 = sub i64 %k3, %ep
  %wep$2Eptr = inttoptr i64 %s to ptr
  %wep$2Eoff = bitcast i64 456 to i64
  %wep.p.gep = getelementptr inbounds i8, ptr %wep$2Eptr, i64 %wep$2Eoff
  store i64 %ep1, ptr %wep.p.gep
  %wep = bitcast i1 true to i1
  ret i64 %lvAll
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EsweepPhase(i64 %t0, i64 %guard, i64 %fe) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %slm = bitcast i64 49 to i64
  %tm = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Estamp(i64 %slm, i64 %t0)
  %live1 = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EsweepLarge(i64 %guard, i64 %fe)
  %sll = bitcast i64 50 to i64
  %tl = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Estamp(i64 %sll, i64 %tm)
  %live = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EsweepPages(i64 %live1)
  %slp = bitcast i64 51 to i64
  %tp = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Estamp(i64 %slp, i64 %tl)
  %w1$2Ev = bitcast i64 0 to i64
  %w1$2Eptr = inttoptr i64 %s to ptr
  %w1$2Eoff = bitcast i64 0 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %w1$2Ev, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  %w2$2Eptr = inttoptr i64 %s to ptr
  %w2$2Eoff = bitcast i64 96 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %live, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  %gb$2Eptr = inttoptr i64 %s to ptr
  %gb$2Eoff = bitcast i64 32 to i64
  %gb.p.gep = getelementptr inbounds i8, ptr %gb$2Eptr, i64 %gb$2Eoff
  %gb = load i64, ptr %gb.p.gep
  %growth = call tailcc double @gcAslBitsF64(i64 %gb)
  %lf = sitofp i64 %live to double
  %next = fmul double %lf, %growth
  %capF = bitcast double 70368744177664.0 to double
  %big = fcmp oge double %next, %capF
  %capI = bitcast i64 70368744177664 to i64
  br i1 %big, label %bb.floor, label %bb.conv
bb.conv:
  %nexti = call tailcc i64 @gcAslF64ToU64(double %next)
  br label %bb.floor
bb.floor:
  %t = phi i64 [ %capI, %bb.entry ], [ %nexti, %bb.conv ]
  %minb$2Eptr = inttoptr i64 %s to ptr
  %minb$2Eoff = bitcast i64 16 to i64
  %minb.p.gep = getelementptr inbounds i8, ptr %minb$2Eptr, i64 %minb$2Eoff
  %minb = load i64, ptr %minb.p.gep
  %low$2Ea$2Eone = bitcast i64 1 to i64
  %low$2Ea$2Esh = bitcast i64 63 to i64
  %low$2Ea$2Emin.p.m = and i64 %low$2Ea$2Esh, 63
  %low$2Ea$2Emin = shl i64 %low$2Ea$2Eone, %low$2Ea$2Emin.p.m
  %low$2Ea = xor i64 %t, %low$2Ea$2Emin
  %low$2Eb$2Eone = bitcast i64 1 to i64
  %low$2Eb$2Esh = bitcast i64 63 to i64
  %low$2Eb$2Emin.p.m = and i64 %low$2Eb$2Esh, 63
  %low$2Eb$2Emin = shl i64 %low$2Eb$2Eone, %low$2Eb$2Emin.p.m
  %low$2Eb = xor i64 %minb, %low$2Eb$2Emin
  %low = icmp slt i64 %low$2Ea, %low$2Eb
  br i1 %low, label %bb.floor.e0, label %bb.floor.e1
bb.floor.e0:
  br label %bb.cap
bb.floor.e1:
  br label %bb.cap
bb.cap:
  %t2 = phi i64 [ %minb, %bb.floor.e0 ], [ %t, %bb.floor.e1 ]
  %maxb$2Eptr = inttoptr i64 %s to ptr
  %maxb$2Eoff = bitcast i64 24 to i64
  %maxb.p.gep = getelementptr inbounds i8, ptr %maxb$2Eptr, i64 %maxb$2Eoff
  %maxb = load i64, ptr %maxb.p.gep
  %nomax$2Ek = bitcast i64 0 to i64
  %nomax = icmp eq i64 %maxb, %nomax$2Ek
  br i1 %nomax, label %bb.set, label %bb.room
bb.room:
  %under$2Ea$2Eone = bitcast i64 1 to i64
  %under$2Ea$2Esh = bitcast i64 63 to i64
  %under$2Ea$2Emin.p.m = and i64 %under$2Ea$2Esh, 63
  %under$2Ea$2Emin = shl i64 %under$2Ea$2Eone, %under$2Ea$2Emin.p.m
  %under$2Ea = xor i64 %live, %under$2Ea$2Emin
  %under$2Eb$2Eone = bitcast i64 1 to i64
  %under$2Eb$2Esh = bitcast i64 63 to i64
  %under$2Eb$2Emin.p.m = and i64 %under$2Eb$2Esh, 63
  %under$2Eb$2Emin = shl i64 %under$2Eb$2Eone, %under$2Eb$2Emin.p.m
  %under$2Eb = xor i64 %maxb, %under$2Eb$2Emin
  %under = icmp slt i64 %under$2Ea, %under$2Eb
  %left = sub i64 %maxb, %live
  %none = bitcast i64 0 to i64
  br i1 %under, label %bb.room.e0, label %bb.room.e1
bb.room.e0:
  br label %bb.roomed
bb.room.e1:
  br label %bb.roomed
bb.roomed:
  %rm = phi i64 [ %left, %bb.room.e0 ], [ %none, %bb.room.e1 ]
  %tight$2Ea$2Eone = bitcast i64 1 to i64
  %tight$2Ea$2Esh = bitcast i64 63 to i64
  %tight$2Ea$2Emin.p.m = and i64 %tight$2Ea$2Esh, 63
  %tight$2Ea$2Emin = shl i64 %tight$2Ea$2Eone, %tight$2Ea$2Emin.p.m
  %tight$2Ea = xor i64 %rm, %tight$2Ea$2Emin
  %tight$2Eb$2Eone = bitcast i64 1 to i64
  %tight$2Eb$2Esh = bitcast i64 63 to i64
  %tight$2Eb$2Emin.p.m = and i64 %tight$2Eb$2Esh, 63
  %tight$2Eb$2Emin = shl i64 %tight$2Eb$2Eone, %tight$2Eb$2Emin.p.m
  %tight$2Eb = xor i64 %t2, %tight$2Eb$2Emin
  %tight = icmp slt i64 %tight$2Ea, %tight$2Eb
  br i1 %tight, label %bb.roomed.e0, label %bb.roomed.e1
bb.roomed.e0:
  br label %bb.set
bb.roomed.e1:
  br label %bb.set
bb.set:
  %t3 = phi i64 [ %t2, %bb.cap ], [ %rm, %bb.roomed.e0 ], [ %t2, %bb.roomed.e1 ]
  %w3$2Eptr = inttoptr i64 %s to ptr
  %w3$2Eoff = bitcast i64 8 to i64
  %w3.p.gep = getelementptr inbounds i8, ptr %w3$2Eptr, i64 %w3$2Eoff
  store i64 %t3, ptr %w3.p.gep
  %w3 = bitcast i1 true to i1
  %usable = bitcast i64 15872 to i64
  %need.p.zero = icmp eq i64 %usable, 0
  %need.p.min = icmp eq i64 %t3, -9223372036854775808
  %need.p.neg = icmp eq i64 %usable, -1
  %need.p.over = and i1 %need.p.min, %need.p.neg
  %need.p.bad = or i1 %need.p.zero, %need.p.over
  br i1 %need.p.bad, label %need.p.trap, label %need.p.ok
need.p.trap:
  call void @llvm.trap()
  unreachable
need.p.ok:
  %need = sdiv i64 %t3, %usable
  %keep$2Ek = bitcast i64 63 to i64
  %keep = add i64 %need, %keep$2Ek
  %rc = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EreleaseCache(i64 %keep)
  %slr = bitcast i64 52 to i64
  %tr = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Estamp(i64 %slr, i64 %tp)
  %ver$2Eptr = inttoptr i64 %s to ptr
  %ver$2Eoff = bitcast i64 56 to i64
  %ver.p.gep = getelementptr inbounds i8, ptr %ver$2Eptr, i64 %ver$2Eoff
  %ver = load i64, ptr %ver.p.gep
  %verifying$2Ek = bitcast i64 0 to i64
  %verifying = icmp ne i64 %ver, %verifying$2Ek
  br i1 %verifying, label %bb.verify, label %bb.stats
bb.verify:
  %vh = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EverifyHeap()
  br label %bb.stats
bb.stats:
  %on$2Eptr = inttoptr i64 %s to ptr
  %on$2Eoff = bitcast i64 48 to i64
  %on.p.gep = getelementptr inbounds i8, ptr %on$2Eptr, i64 %on$2Eoff
  %on = load i64, ptr %on.p.gep
  %timed$2Ek = bitcast i64 0 to i64
  %timed = icmp ne i64 %on, %timed$2Ek
  br i1 %timed, label %bb.time, label %bb.finErr
bb.time:
  %t1 = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmonoNs()
  %dt = sub i64 %t1, %t0
  %tn$2Eold$2Eptr = inttoptr i64 %s to ptr
  %tn$2Eold$2Eoff = bitcast i64 104 to i64
  %tn$2Eold.p.gep = getelementptr inbounds i8, ptr %tn$2Eold$2Eptr, i64 %tn$2Eold$2Eoff
  %tn$2Eold = load i64, ptr %tn$2Eold.p.gep
  %tn$2Enew = add i64 %tn$2Eold, %dt
  %tn$2Eptr = inttoptr i64 %s to ptr
  %tn$2Eoff = bitcast i64 104 to i64
  %tn.p.gep = getelementptr inbounds i8, ptr %tn$2Eptr, i64 %tn$2Eoff
  store i64 %tn$2Enew, ptr %tn.p.gep
  %tn = bitcast i1 true to i1
  br label %bb.finErr
bb.finErr:
  %f0$2Eptr = inttoptr i64 %fe to ptr
  %f0$2Eoff = bitcast i64 0 to i64
  %f0$2Ew.p.gep = getelementptr inbounds i8, ptr %f0$2Eptr, i64 %f0$2Eoff
  %f0$2Ew.p.raw = load i8, ptr %f0$2Ew.p.gep
  %f0$2Ew = zext i8 %f0$2Ew.p.raw to i32
  %f0 = sext i32 %f0$2Ew to i64
  %raised$2Ek = bitcast i64 0 to i64
  %raised = icmp ne i64 %f0, %raised$2Ek
  br i1 %raised, label %bb.rethrow, label %bb.heapCap
bb.rethrow:
  %fep = inttoptr i64 %fe to ptr
  %len = call i64 (ptr) @strlen(ptr %fep)
  %n0$2Ek = bitcast i64 1 to i64
  %n0 = add i64 %len, %n0$2Ek
  %msz$2Eptr = inttoptr i64 %guard to ptr
  %msz$2Eoff = bitcast i64 32 to i64
  %msz.p.gep = getelementptr inbounds i8, ptr %msz$2Eptr, i64 %msz$2Eoff
  %msz = load i64, ptr %msz.p.gep
  %fits$2Ea$2Eone = bitcast i64 1 to i64
  %fits$2Ea$2Esh = bitcast i64 63 to i64
  %fits$2Ea$2Emin.p.m = and i64 %fits$2Ea$2Esh, 63
  %fits$2Ea$2Emin = shl i64 %fits$2Ea$2Eone, %fits$2Ea$2Emin.p.m
  %fits$2Ea = xor i64 %n0, %fits$2Ea$2Emin
  %fits$2Eb$2Eone = bitcast i64 1 to i64
  %fits$2Eb$2Esh = bitcast i64 63 to i64
  %fits$2Eb$2Emin.p.m = and i64 %fits$2Eb$2Esh, 63
  %fits$2Eb$2Emin = shl i64 %fits$2Eb$2Eone, %fits$2Eb$2Emin.p.m
  %fits$2Eb = xor i64 %msz, %fits$2Eb$2Emin
  %fits = icmp slt i64 %fits$2Ea, %fits$2Eb
  br i1 %fits, label %bb.rethrow.e0, label %bb.rethrow.e1
bb.rethrow.e0:
  br label %bb.copy
bb.rethrow.e1:
  br label %bb.copy
bb.copy:
  %n = phi i64 [ %n0, %bb.rethrow.e0 ], [ %msz, %bb.rethrow.e1 ]
  %nz$2Ek = bitcast i64 0 to i64
  %nz = icmp ne i64 %n, %nz$2Ek
  br i1 %nz, label %bb.copy2, label %bb.throw
bb.copy2:
  %msg$2Eptr = inttoptr i64 %guard to ptr
  %msg$2Eoff = bitcast i64 24 to i64
  %msg.p.gep = getelementptr inbounds i8, ptr %msg$2Eptr, i64 %msg$2Eoff
  %msg = load i64, ptr %msg.p.gep
  %msgp = inttoptr i64 %msg to ptr
  %mc = call ptr (ptr, ptr, i64) @memcpy(ptr %msgp, ptr %fep, i64 %n)
  %endAt = add i64 %msg, %n
  %nul$2Eptr = inttoptr i64 %endAt to ptr
  %nul$2Eoff = bitcast i64 -1 to i64
  %nul$2Ev = bitcast i32 0 to i32
  %nul.p.gep = getelementptr inbounds i8, ptr %nul$2Eptr, i64 %nul$2Eoff
  %nul.p.trunc = trunc i32 %nul$2Ev to i8
  store i8 %nul.p.trunc, ptr %nul.p.gep
  %nul = bitcast i1 true to i1
  br label %bb.throw
bb.throw:
  %rt = call tailcc i64 @gcAslRethrow(i64 %guard)
  %throw$2Ez = bitcast i64 0 to i64
  ret i64 %throw$2Ez
bb.heapCap:
  %maxc$2Eptr = inttoptr i64 %s to ptr
  %maxc$2Eoff = bitcast i64 24 to i64
  %maxc.p.gep = getelementptr inbounds i8, ptr %maxc$2Eptr, i64 %maxc$2Eoff
  %maxc = load i64, ptr %maxc.p.gep
  %capped$2Ek = bitcast i64 0 to i64
  %capped = icmp ne i64 %maxc, %capped$2Ek
  br i1 %capped, label %bb.capCheck, label %bb.done
bb.capCheck:
  %over$2Ea$2Eone = bitcast i64 1 to i64
  %over$2Ea$2Esh = bitcast i64 63 to i64
  %over$2Ea$2Emin.p.m = and i64 %over$2Ea$2Esh, 63
  %over$2Ea$2Emin = shl i64 %over$2Ea$2Eone, %over$2Ea$2Emin.p.m
  %over$2Ea = xor i64 %maxc, %over$2Ea$2Emin
  %over$2Eb$2Eone = bitcast i64 1 to i64
  %over$2Eb$2Esh = bitcast i64 63 to i64
  %over$2Eb$2Emin.p.m = and i64 %over$2Eb$2Esh, 63
  %over$2Eb$2Emin = shl i64 %over$2Eb$2Eone, %over$2Eb$2Emin.p.m
  %over$2Eb = xor i64 %live, %over$2Eb$2Emin
  %over = icmp slt i64 %over$2Ea, %over$2Eb
  br i1 %over, label %bb.oom, label %bb.done
bb.oom:
  %mib$2Ek = bitcast i64 20 to i64
  %mib.p.m = and i64 %mib$2Ek, 63
  %mib = lshr i64 %maxc, %mib.p.m
  %oom$2Ec = bitcast ptr @str.2 to ptr
  %oom$2Ef = bitcast ptr @str.9 to ptr
  %oom$2Ebi = call tailcc i64 @gcAslFailBuf()
  %oom$2Eb = inttoptr i64 %oom$2Ebi to ptr
  %oom$2Ecap = bitcast i64 1024 to i64
  %oom$2En = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %oom$2Eb, i64 %oom$2Ecap, ptr %oom$2Ef, i64 %mib)
  %oom$2Er = call i64 (ptr, ptr, ...) @gcFloorFail(ptr %oom$2Ec, ptr %oom$2Eb)
  %oom$2Ez = bitcast i64 0 to i64
  ret i64 %oom$2Ez
bb.done:
  %done$2Ez = bitcast i64 0 to i64
  ret i64 %done$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EisOne(i64 %addr) {
bb.entry:
  %z$2Ek = bitcast i64 0 to i64
  %z = icmp eq i64 %addr, %z$2Ek
  br i1 %z, label %bb.no, label %bb.check
bb.check:
  %c$2Eptr = inttoptr i64 %addr to ptr
  %c$2Eoff = bitcast i64 0 to i64
  %c$2Ew.p.gep = getelementptr inbounds i8, ptr %c$2Eptr, i64 %c$2Eoff
  %c$2Ew.p.raw = load i8, ptr %c$2Ew.p.gep
  %c$2Ew = zext i8 %c$2Ew.p.raw to i32
  %c = sext i32 %c$2Ew to i64
  %one$2Ek = bitcast i64 49 to i64
  %one = icmp eq i64 %c, %one$2Ek
  br i1 %one, label %bb.yes, label %bb.no
bb.yes:
  %y = bitcast i64 1 to i64
  ret i64 %y
bb.no:
  %no$2Ez = bitcast i64 0 to i64
  ret i64 %no$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Epresent(i64 %addr) {
bb.entry:
  %z$2Ek = bitcast i64 0 to i64
  %z = icmp eq i64 %addr, %z$2Ek
  br i1 %z, label %bb.no, label %bb.check
bb.check:
  %c$2Eptr = inttoptr i64 %addr to ptr
  %c$2Eoff = bitcast i64 0 to i64
  %c$2Ew.p.gep = getelementptr inbounds i8, ptr %c$2Eptr, i64 %c$2Eoff
  %c$2Ew.p.raw = load i8, ptr %c$2Ew.p.gep
  %c$2Ew = zext i8 %c$2Ew.p.raw to i32
  %c = sext i32 %c$2Ew to i64
  %empty$2Ek = bitcast i64 0 to i64
  %empty = icmp eq i64 %c, %empty$2Ek
  br i1 %empty, label %bb.no, label %bb.yes
bb.yes:
  %y = bitcast i64 1 to i64
  ret i64 %y
bb.no:
  %no$2Ez = bitcast i64 0 to i64
  ret i64 %no$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmibOf(i64 %addr) {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %ez$2Eloc = call ptr () @__error()
  %ez$2Eo = bitcast i64 0 to i64
  %ez$2Ez = bitcast i32 0 to i32
  %ez.p.gep = getelementptr inbounds i8, ptr %ez$2Eloc, i64 %ez$2Eo
  store i32 %ez$2Ez, ptr %ez.p.gep
  %ez = bitcast i1 true to i1
  %ap = inttoptr i64 %addr to ptr
  %endAt$2Ek = bitcast i64 368 to i64
  %endAt = add i64 %s, %endAt$2Ek
  %endp = inttoptr i64 %endAt to ptr
  %ten = bitcast i32 10 to i32
  %v = call i64 (ptr, ptr, i32) @strtoull(ptr %ap, ptr %endp, i32 %ten)
  %er$2Eloc = call ptr () @__error()
  %er$2Ei = ptrtoint ptr %er$2Eloc to i64
  %er$2Eptr = inttoptr i64 %er$2Ei to ptr
  %er$2Eoff = bitcast i64 0 to i64
  %er$2Ew.p.gep = getelementptr inbounds i8, ptr %er$2Eptr, i64 %er$2Eoff
  %er$2Ew = load i32, ptr %er$2Ew.p.gep
  %er = sext i32 %er$2Ew to i64
  %end$2Eptr = inttoptr i64 %endAt to ptr
  %end$2Eoff = bitcast i64 0 to i64
  %end.p.gep = getelementptr inbounds i8, ptr %end$2Eptr, i64 %end$2Eoff
  %end = load i64, ptr %end.p.gep
  %endc$2Eptr = inttoptr i64 %end to ptr
  %endc$2Eoff = bitcast i64 0 to i64
  %endc$2Ew.p.gep = getelementptr inbounds i8, ptr %endc$2Eptr, i64 %endc$2Eoff
  %endc$2Ew.p.raw = load i8, ptr %endc$2Ew.p.gep
  %endc$2Ew = zext i8 %endc$2Ew.p.raw to i32
  %endc = sext i32 %endc$2Ew to i64
  %c0$2Eptr = inttoptr i64 %addr to ptr
  %c0$2Eoff = bitcast i64 0 to i64
  %c0$2Ew.p.gep = getelementptr inbounds i8, ptr %c0$2Eptr, i64 %c0$2Eoff
  %c0$2Ew.p.raw = load i8, ptr %c0$2Ew.p.gep
  %c0$2Ew = zext i8 %c0$2Ew.p.raw to i32
  %c0 = sext i32 %c0$2Ew to i64
  %e1$2Ek = bitcast i64 0 to i64
  %e1 = icmp ne i64 %er, %e1$2Ek
  %e2$2Ek = bitcast i64 0 to i64
  %e2 = icmp ne i64 %endc, %e2$2Ek
  %e3$2Ek = bitcast i64 45 to i64
  %e3 = icmp eq i64 %c0, %e3$2Ek
  %e4$2En = bitcast i64 1 to i64
  %e4$2Ea$2Eone = bitcast i64 1 to i64
  %e4$2Ea$2Esh = bitcast i64 63 to i64
  %e4$2Ea$2Emin.p.m = and i64 %e4$2Ea$2Esh, 63
  %e4$2Ea$2Emin = shl i64 %e4$2Ea$2Eone, %e4$2Ea$2Emin.p.m
  %e4$2Ea = xor i64 %v, %e4$2Ea$2Emin
  %e4$2Eb$2Eone = bitcast i64 1 to i64
  %e4$2Eb$2Esh = bitcast i64 63 to i64
  %e4$2Eb$2Emin.p.m = and i64 %e4$2Eb$2Esh, 63
  %e4$2Eb$2Emin = shl i64 %e4$2Eb$2Eone, %e4$2Eb$2Emin.p.m
  %e4$2Eb = xor i64 %e4$2En, %e4$2Eb$2Emin
  %e4 = icmp slt i64 %e4$2Ea, %e4$2Eb
  %most = bitcast i64 65536 to i64
  %e5$2Ea$2Eone = bitcast i64 1 to i64
  %e5$2Ea$2Esh = bitcast i64 63 to i64
  %e5$2Ea$2Emin.p.m = and i64 %e5$2Ea$2Esh, 63
  %e5$2Ea$2Emin = shl i64 %e5$2Ea$2Eone, %e5$2Ea$2Emin.p.m
  %e5$2Ea = xor i64 %most, %e5$2Ea$2Emin
  %e5$2Eb$2Eone = bitcast i64 1 to i64
  %e5$2Eb$2Esh = bitcast i64 63 to i64
  %e5$2Eb$2Emin.p.m = and i64 %e5$2Eb$2Esh, 63
  %e5$2Eb$2Emin = shl i64 %e5$2Eb$2Eone, %e5$2Eb$2Emin.p.m
  %e5$2Eb = xor i64 %v, %e5$2Eb$2Emin
  %e5 = icmp slt i64 %e5$2Ea, %e5$2Eb
  %b1 = or i1 %e1, %e2
  %b2 = or i1 %b1, %e3
  %b3 = or i1 %b2, %e4
  %bad = or i1 %b3, %e5
  br i1 %bad, label %bb.bad, label %bb.good
bb.good:
  ret i64 %v
bb.bad:
  %bad$2Ez = bitcast i64 0 to i64
  ret i64 %bad$2Ez
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Einit() {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %pub = call tailcc i64 @gcAslPublish()
  %es$2En = bitcast ptr @str.19 to ptr
  %es$2Ep = call ptr (ptr) @getenv(ptr %es$2En)
  %es = ptrtoint ptr %es$2Ep to i64
  %stress = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EisOne(i64 %es)
  %w1$2Eptr = inttoptr i64 %s to ptr
  %w1$2Eoff = bitcast i64 40 to i64
  %w1.p.gep = getelementptr inbounds i8, ptr %w1$2Eptr, i64 %w1$2Eoff
  store i64 %stress, ptr %w1.p.gep
  %w1 = bitcast i1 true to i1
  %et$2En = bitcast ptr @str.20 to ptr
  %et$2Ep = call ptr (ptr) @getenv(ptr %et$2En)
  %et = ptrtoint ptr %et$2Ep to i64
  %stats = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EisOne(i64 %et)
  %statsOn$2Ek = bitcast i64 0 to i64
  %statsOn = icmp ne i64 %stats, %statsOn$2Ek
  br i1 %statsOn, label %bb.statsOn, label %bb.growth
bb.statsOn:
  %w2$2Ev = bitcast i64 1 to i64
  %w2$2Eptr = inttoptr i64 %s to ptr
  %w2$2Eoff = bitcast i64 48 to i64
  %w2.p.gep = getelementptr inbounds i8, ptr %w2$2Eptr, i64 %w2$2Eoff
  store i64 %w2$2Ev, ptr %w2.p.gep
  %w2 = bitcast i1 true to i1
  %ax = call tailcc i64 @gcAslAtexitStats()
  br label %bb.growth
bb.growth:
  %eg$2En = bitcast ptr @str.21 to ptr
  %eg$2Ep = call ptr (ptr) @getenv(ptr %eg$2En)
  %eg = ptrtoint ptr %eg$2Ep to i64
  %gp = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Epresent(i64 %eg)
  %hasG$2Ek = bitcast i64 0 to i64
  %hasG = icmp ne i64 %gp, %hasG$2Ek
  br i1 %hasG, label %bb.gparse, label %bb.minMib
bb.gparse:
  %gz$2Eloc = call ptr () @__error()
  %gz$2Eo = bitcast i64 0 to i64
  %gz$2Ez = bitcast i32 0 to i32
  %gz.p.gep = getelementptr inbounds i8, ptr %gz$2Eloc, i64 %gz$2Eo
  store i32 %gz$2Ez, ptr %gz.p.gep
  %gz = bitcast i1 true to i1
  %egp = inttoptr i64 %eg to ptr
  %endAt$2Ek = bitcast i64 368 to i64
  %endAt = add i64 %s, %endAt$2Ek
  %endp = inttoptr i64 %endAt to ptr
  %d = call double (ptr, ptr) @strtod(ptr %egp, ptr %endp)
  %ger$2Eloc = call ptr () @__error()
  %ger$2Ei = ptrtoint ptr %ger$2Eloc to i64
  %ger$2Eptr = inttoptr i64 %ger$2Ei to ptr
  %ger$2Eoff = bitcast i64 0 to i64
  %ger$2Ew.p.gep = getelementptr inbounds i8, ptr %ger$2Eptr, i64 %ger$2Eoff
  %ger$2Ew = load i32, ptr %ger$2Ew.p.gep
  %ger = sext i32 %ger$2Ew to i64
  %end$2Eptr = inttoptr i64 %endAt to ptr
  %end$2Eoff = bitcast i64 0 to i64
  %end.p.gep = getelementptr inbounds i8, ptr %end$2Eptr, i64 %end$2Eoff
  %end = load i64, ptr %end.p.gep
  %endc$2Eptr = inttoptr i64 %end to ptr
  %endc$2Eoff = bitcast i64 0 to i64
  %endc$2Ew.p.gep = getelementptr inbounds i8, ptr %endc$2Eptr, i64 %endc$2Eoff
  %endc$2Ew.p.raw = load i8, ptr %endc$2Ew.p.gep
  %endc$2Ew = zext i8 %endc$2Ew.p.raw to i32
  %endc = sext i32 %endc$2Ew to i64
  %dd = fsub double %d, %d
  %zf = bitcast double 0.0 to double
  %finite = fcmp oeq double %dd, %zf
  %lof = bitcast double 0.25 to double
  %hif = bitcast double 64.0 to double
  %low = fcmp olt double %d, %lof
  %high = fcmp ogt double %d, %hif
  %g1$2Ek = bitcast i64 0 to i64
  %g1 = icmp ne i64 %ger, %g1$2Ek
  %g2$2Ek = bitcast i64 0 to i64
  %g2 = icmp ne i64 %endc, %g2$2Ek
  %g3 = xor i1 %finite, true
  %gb1 = or i1 %g1, %g2
  %gb2 = or i1 %gb1, %g3
  %gb3 = or i1 %gb2, %low
  %gbad = or i1 %gb3, %high
  br i1 %gbad, label %bb.gbad, label %bb.gok
bb.gbad:
  %gbad$2Efd = bitcast i32 2 to i32
  %gbad$2Ef = bitcast ptr @str.25 to ptr
  %gbad$2Et = inttoptr i64 %eg to ptr
  %gbad$2Ep = call i32 (i32, ptr, ...) @dprintf(i32 %gbad$2Efd, ptr %gbad$2Ef, ptr %gbad$2Et)
  %gbad$2Ec = bitcast i32 2 to i32
  %gbad$2Ex = call i64 (i32) @exit(i32 %gbad$2Ec)
  %gbad$2Ez = bitcast i64 0 to i64
  ret i64 %gbad$2Ez
bb.gok:
  %bits = call tailcc i64 @gcAslF64Bits(double %d)
  %w3$2Eptr = inttoptr i64 %s to ptr
  %w3$2Eoff = bitcast i64 32 to i64
  %w3.p.gep = getelementptr inbounds i8, ptr %w3$2Eptr, i64 %w3$2Eoff
  store i64 %bits, ptr %w3.p.gep
  %w3 = bitcast i1 true to i1
  br label %bb.minMib
bb.minMib:
  %em$2En = bitcast ptr @str.22 to ptr
  %em$2Ep = call ptr (ptr) @getenv(ptr %em$2En)
  %em = ptrtoint ptr %em$2Ep to i64
  %mp = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Epresent(i64 %em)
  %hasM$2Ek = bitcast i64 0 to i64
  %hasM = icmp ne i64 %mp, %hasM$2Ek
  br i1 %hasM, label %bb.mparse, label %bb.maxMib
bb.mparse:
  %mv = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmibOf(i64 %em)
  %mbad$2Ek = bitcast i64 0 to i64
  %mbad = icmp eq i64 %mv, %mbad$2Ek
  br i1 %mbad, label %bb.mbad, label %bb.mok
bb.mbad:
  %mbad$2Efd = bitcast i32 2 to i32
  %mbad$2Ef = bitcast ptr @str.26 to ptr
  %mbad$2Et = inttoptr i64 %em to ptr
  %mbad$2Ep = call i32 (i32, ptr, ...) @dprintf(i32 %mbad$2Efd, ptr %mbad$2Ef, ptr %mbad$2Et)
  %mbad$2Ec = bitcast i32 2 to i32
  %mbad$2Ex = call i64 (i32) @exit(i32 %mbad$2Ec)
  %mbad$2Ez = bitcast i64 0 to i64
  ret i64 %mbad$2Ez
bb.mok:
  %mb$2Ek = bitcast i64 20 to i64
  %mb.p.m = and i64 %mb$2Ek, 63
  %mb = shl i64 %mv, %mb.p.m
  %w4$2Eptr = inttoptr i64 %s to ptr
  %w4$2Eoff = bitcast i64 16 to i64
  %w4.p.gep = getelementptr inbounds i8, ptr %w4$2Eptr, i64 %w4$2Eoff
  store i64 %mb, ptr %w4.p.gep
  %w4 = bitcast i1 true to i1
  br label %bb.maxMib
bb.maxMib:
  %ex$2En = bitcast ptr @str.23 to ptr
  %ex$2Ep = call ptr (ptr) @getenv(ptr %ex$2En)
  %ex = ptrtoint ptr %ex$2Ep to i64
  %xp = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Epresent(i64 %ex)
  %hasX$2Ek = bitcast i64 0 to i64
  %hasX = icmp ne i64 %xp, %hasX$2Ek
  br i1 %hasX, label %bb.xparse, label %bb.thresh
bb.xparse:
  %xv = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmibOf(i64 %ex)
  %xbad$2Ek = bitcast i64 0 to i64
  %xbad = icmp eq i64 %xv, %xbad$2Ek
  br i1 %xbad, label %bb.xbad, label %bb.xok
bb.xbad:
  %xbad$2Efd = bitcast i32 2 to i32
  %xbad$2Ef = bitcast ptr @str.27 to ptr
  %xbad$2Et = inttoptr i64 %ex to ptr
  %xbad$2Ep = call i32 (i32, ptr, ...) @dprintf(i32 %xbad$2Efd, ptr %xbad$2Ef, ptr %xbad$2Et)
  %xbad$2Ec = bitcast i32 2 to i32
  %xbad$2Ex = call i64 (i32) @exit(i32 %xbad$2Ec)
  %xbad$2Ez = bitcast i64 0 to i64
  ret i64 %xbad$2Ez
bb.xok:
  %xb$2Ek = bitcast i64 20 to i64
  %xb.p.m = and i64 %xb$2Ek, 63
  %xb = shl i64 %xv, %xb.p.m
  %w5$2Eptr = inttoptr i64 %s to ptr
  %w5$2Eoff = bitcast i64 24 to i64
  %w5.p.gep = getelementptr inbounds i8, ptr %w5$2Eptr, i64 %w5$2Eoff
  store i64 %xb, ptr %w5.p.gep
  %w5 = bitcast i1 true to i1
  br label %bb.thresh
bb.thresh:
  %maxb$2Eptr = inttoptr i64 %s to ptr
  %maxb$2Eoff = bitcast i64 24 to i64
  %maxb.p.gep = getelementptr inbounds i8, ptr %maxb$2Eptr, i64 %maxb$2Eoff
  %maxb = load i64, ptr %maxb.p.gep
  %minb$2Eptr = inttoptr i64 %s to ptr
  %minb$2Eoff = bitcast i64 16 to i64
  %minb.p.gep = getelementptr inbounds i8, ptr %minb$2Eptr, i64 %minb$2Eoff
  %minb = load i64, ptr %minb.p.gep
  %capped$2Ek = bitcast i64 0 to i64
  %capped = icmp ne i64 %maxb, %capped$2Ek
  %smaller$2Ea$2Eone = bitcast i64 1 to i64
  %smaller$2Ea$2Esh = bitcast i64 63 to i64
  %smaller$2Ea$2Emin.p.m = and i64 %smaller$2Ea$2Esh, 63
  %smaller$2Ea$2Emin = shl i64 %smaller$2Ea$2Eone, %smaller$2Ea$2Emin.p.m
  %smaller$2Ea = xor i64 %maxb, %smaller$2Ea$2Emin
  %smaller$2Eb$2Eone = bitcast i64 1 to i64
  %smaller$2Eb$2Esh = bitcast i64 63 to i64
  %smaller$2Eb$2Emin.p.m = and i64 %smaller$2Eb$2Esh, 63
  %smaller$2Eb$2Emin = shl i64 %smaller$2Eb$2Eone, %smaller$2Eb$2Emin.p.m
  %smaller$2Eb = xor i64 %minb, %smaller$2Eb$2Emin
  %smaller = icmp slt i64 %smaller$2Ea, %smaller$2Eb
  %useMax = and i1 %capped, %smaller
  br i1 %useMax, label %bb.thresh.e0, label %bb.thresh.e1
bb.thresh.e0:
  br label %bb.first
bb.thresh.e1:
  br label %bb.first
bb.first:
  %t = phi i64 [ %maxb, %bb.thresh.e0 ], [ %minb, %bb.thresh.e1 ]
  %w6$2Eptr = inttoptr i64 %s to ptr
  %w6$2Eoff = bitcast i64 8 to i64
  %w6.p.gep = getelementptr inbounds i8, ptr %w6$2Eptr, i64 %w6$2Eoff
  store i64 %t, ptr %w6.p.gep
  %w6 = bitcast i1 true to i1
  %ev$2En = bitcast ptr @str.24 to ptr
  %ev$2Ep = call ptr (ptr) @getenv(ptr %ev$2En)
  %ev = ptrtoint ptr %ev$2Ep to i64
  %ver = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EisOne(i64 %ev)
  %w7$2Eptr = inttoptr i64 %s to ptr
  %w7$2Eoff = bitcast i64 56 to i64
  %w7.p.gep = getelementptr inbounds i8, ptr %w7$2Eptr, i64 %w7$2Eoff
  store i64 %ver, ptr %w7.p.gep
  %w7 = bitcast i1 true to i1
  %z = bitcast i64 0 to i64
  ret i64 %z
}

define internal tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EprintStats() {
bb.entry:
  %s = call tailcc i64 @gcAslState()
  %fd = bitcast i32 2 to i32
  %fmt = bitcast ptr @str.18 to ptr
  %c$2Eptr = inttoptr i64 %s to ptr
  %c$2Eoff = bitcast i64 64 to i64
  %c.p.gep = getelementptr inbounds i8, ptr %c$2Eptr, i64 %c$2Eoff
  %c = load i64, ptr %c.p.gep
  %oa$2Eptr = inttoptr i64 %s to ptr
  %oa$2Eoff = bitcast i64 72 to i64
  %oa.p.gep = getelementptr inbounds i8, ptr %oa$2Eptr, i64 %oa$2Eoff
  %oa = load i64, ptr %oa.p.gep
  %of$2Eptr = inttoptr i64 %s to ptr
  %of$2Eoff = bitcast i64 80 to i64
  %of.p.gep = getelementptr inbounds i8, ptr %of$2Eptr, i64 %of$2Eoff
  %of = load i64, ptr %of.p.gep
  %ba$2Eptr = inttoptr i64 %s to ptr
  %ba$2Eoff = bitcast i64 88 to i64
  %ba.p.gep = getelementptr inbounds i8, ptr %ba$2Eptr, i64 %ba$2Eoff
  %ba = load i64, ptr %ba.p.gep
  %bl$2Eptr = inttoptr i64 %s to ptr
  %bl$2Eoff = bitcast i64 96 to i64
  %bl.p.gep = getelementptr inbounds i8, ptr %bl$2Eptr, i64 %bl$2Eoff
  %bl = load i64, ptr %bl.p.gep
  %tn$2Eptr = inttoptr i64 %s to ptr
  %tn$2Eoff = bitcast i64 104 to i64
  %tn.p.gep = getelementptr inbounds i8, ptr %tn$2Eptr, i64 %tn$2Eoff
  %tn = load i64, ptr %tn.p.gep
  %pf$2Eptr = inttoptr i64 %s to ptr
  %pf$2Eoff = bitcast i64 112 to i64
  %pf.p.gep = getelementptr inbounds i8, ptr %pf$2Eptr, i64 %pf$2Eoff
  %pf = load i64, ptr %pf.p.gep
  %pa$2Eptr = inttoptr i64 %s to ptr
  %pa$2Eoff = bitcast i64 120 to i64
  %pa.p.gep = getelementptr inbounds i8, ptr %pa$2Eptr, i64 %pa$2Eoff
  %pa = load i64, ptr %pa.p.gep
  %r = call i32 (i32, ptr, ...) @dprintf(i32 %fd, ptr %fmt, i64 %c, i64 %oa, i64 %of, i64 %ba, i64 %bl, i64 %tn, i64 %pf, i64 %pa)
  %pfmt = bitcast ptr @str.29 to ptr
  %mn$2Eptr = inttoptr i64 %s to ptr
  %mn$2Eoff = bitcast i64 392 to i64
  %mn.p.gep = getelementptr inbounds i8, ptr %mn$2Eptr, i64 %mn$2Eoff
  %mn = load i64, ptr %mn.p.gep
  %ln$2Eptr = inttoptr i64 %s to ptr
  %ln$2Eoff = bitcast i64 400 to i64
  %ln.p.gep = getelementptr inbounds i8, ptr %ln$2Eptr, i64 %ln$2Eoff
  %ln = load i64, ptr %ln.p.gep
  %sn$2Eptr = inttoptr i64 %s to ptr
  %sn$2Eoff = bitcast i64 408 to i64
  %sn.p.gep = getelementptr inbounds i8, ptr %sn$2Eptr, i64 %sn$2Eoff
  %sn = load i64, ptr %sn.p.gep
  %rn$2Eptr = inttoptr i64 %s to ptr
  %rn$2Eoff = bitcast i64 416 to i64
  %rn.p.gep = getelementptr inbounds i8, ptr %rn$2Eptr, i64 %rn$2Eoff
  %rn = load i64, ptr %rn.p.gep
  %pm$2Eptr = inttoptr i64 %s to ptr
  %pm$2Eoff = bitcast i64 424 to i64
  %pm.p.gep = getelementptr inbounds i8, ptr %pm$2Eptr, i64 %pm$2Eoff
  %pm = load i64, ptr %pm.p.gep
  %pu$2Eptr = inttoptr i64 %s to ptr
  %pu$2Eoff = bitcast i64 432 to i64
  %pu.p.gep = getelementptr inbounds i8, ptr %pu$2Eptr, i64 %pu$2Eoff
  %pu = load i64, ptr %pu.p.gep
  %uc$2Eptr = inttoptr i64 %s to ptr
  %uc$2Eoff = bitcast i64 440 to i64
  %uc.p.gep = getelementptr inbounds i8, ptr %uc$2Eptr, i64 %uc$2Eoff
  %uc = load i64, ptr %uc.p.gep
  %r2 = call i32 (i32, ptr, ...) @dprintf(i32 %fd, ptr %pfmt, i64 %mn, i64 %ln, i64 %sn, i64 %rn, i64 %pm, i64 %pu, i64 %uc)
  %entry$2Ez = bitcast i64 0 to i64
  ret i64 %entry$2Ez
}

@.rterr.c.ERR_INTERNAL = private unnamed_addr constant [13 x i8] c"ERR_INTERNAL\00"
@.rterr.c.ERR_INT_OVERFLOW = private unnamed_addr constant [17 x i8] c"ERR_INT_OVERFLOW\00"
@.rterr.c.ERR_DIV_ZERO = private unnamed_addr constant [13 x i8] c"ERR_DIV_ZERO\00"
@.rterr.m.add = private unnamed_addr constant [19 x i8] c"Int + leaves int64\00"
@.rterr.m.sub = private unnamed_addr constant [19 x i8] c"Int - leaves int64\00"
@.rterr.m.mul = private unnamed_addr constant [19 x i8] c"Int * leaves int64\00"
@.rterr.m.div = private unnamed_addr constant [19 x i8] c"Int / leaves int64\00"
@.rterr.m.divZero = private unnamed_addr constant [17 x i8] c"division by zero\00"
@.rterr.m.modZero = private unnamed_addr constant [12 x i8] c"mod by zero\00"
@.rterr.m.narrow = private unnamed_addr constant [24 x i8] c"Int narrow leaves int32\00"
@.rterr.m.floatInt = private unnamed_addr constant [26 x i8] c"Float to Int leaves int64\00"
@.rterr.m.intKind = private unnamed_addr constant [26 x i8] c"unknown integer trap %lld\00"
@.rterr.line = private unnamed_addr constant [9 x i8] c"%s: %.*s\00"

define internal void @rterr.writeAll(i32 %fd, ptr %data, i64 %length) {
entry:
  br label %loop
loop:
  %offset = phi i64 [ 0, %entry ], [ %next, %more ]
  %done = icmp uge i64 %offset, %length
  br i1 %done, label %finish, label %once
once:
  %at = getelementptr i8, ptr %data, i64 %offset
  %rest = sub i64 %length, %offset
  %wrote = call i64 @write(i32 %fd, ptr %at, i64 %rest)
  %progress = icmp sgt i64 %wrote, 0
  br i1 %progress, label %more, label %finish
more:
  %next = add i64 %offset, %wrote
  br label %loop
finish:
  ret void
}

define internal void @rterr.raise(ptr %code, ptr %msg, i64 %len) noreturn {
entry:
  %buf = alloca [4097 x i8]
  %big = icmp ugt i64 %len, 4096
  %clamped = select i1 %big, i64 4096, i64 %len
  %prec = trunc i64 %clamped to i32
  %slot = call ptr @aslHandlerSlot()
  %handler = load ptr, ptr %slot
  %nested = icmp ne ptr %handler, null
  br i1 %nested, label %rethrow, label %report
rethrow:
  %text = call ptr @aslErrorText()
  %kept = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %text, i64 4096, ptr @.rterr.line, ptr %code, i32 %prec, ptr %msg)
  call void @longjmp(ptr %handler, i32 1)
  unreachable
report:
  %written = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %buf, i64 4096, ptr @.rterr.line, ptr %code, i32 %prec, ptr %msg)
  %negative = icmp slt i32 %written, 0
  %wide = sext i32 %written to i64
  %over = icmp ugt i64 %wide, 4095
  %cut = select i1 %over, i64 4095, i64 %wide
  %count = select i1 %negative, i64 0, i64 %cut
  %end = getelementptr i8, ptr %buf, i64 %count
  store i8 10, ptr %end
  %total = add i64 %count, 1
  %flushed = call i32 @fflush(ptr null)
  call void @rterr.writeAll(i32 2, ptr %buf, i64 %total)
  call void @exit(i32 1)
  unreachable
}

define internal void @rterr.raiseNumber(ptr %code, ptr %format, i64 %arg) noreturn {
entry:
  %buf = alloca [4096 x i8]
  store i8 0, ptr %buf
  %written = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %buf, i64 4096, ptr %format, i64 %arg)
  %len = call i64 @strlen(ptr %buf)
  call void @rterr.raise(ptr %code, ptr %buf, i64 %len)
  unreachable
}

define internal void @rterr.int(i32 %kind) noreturn {
entry:
  switch i32 %kind, label %unknown [ i32 0, label %add i32 1, label %sub i32 2, label %mul i32 3, label %div i32 5, label %divZero i32 6, label %modZero i32 7, label %narrow i32 8, label %floatInt ]
add:
  call void @rterr.raise(ptr @.rterr.c.ERR_INT_OVERFLOW, ptr @.rterr.m.add, i64 18)
  unreachable
sub:
  call void @rterr.raise(ptr @.rterr.c.ERR_INT_OVERFLOW, ptr @.rterr.m.sub, i64 18)
  unreachable
mul:
  call void @rterr.raise(ptr @.rterr.c.ERR_INT_OVERFLOW, ptr @.rterr.m.mul, i64 18)
  unreachable
div:
  call void @rterr.raise(ptr @.rterr.c.ERR_INT_OVERFLOW, ptr @.rterr.m.div, i64 18)
  unreachable
divZero:
  call void @rterr.raise(ptr @.rterr.c.ERR_DIV_ZERO, ptr @.rterr.m.divZero, i64 16)
  unreachable
modZero:
  call void @rterr.raise(ptr @.rterr.c.ERR_DIV_ZERO, ptr @.rterr.m.modZero, i64 11)
  unreachable
narrow:
  call void @rterr.raise(ptr @.rterr.c.ERR_INT_OVERFLOW, ptr @.rterr.m.narrow, i64 23)
  unreachable
floatInt:
  call void @rterr.raise(ptr @.rterr.c.ERR_INT_OVERFLOW, ptr @.rterr.m.floatInt, i64 25)
  unreachable
unknown:
  %wide = sext i32 %kind to i64
  call void @rterr.raiseNumber(ptr @.rterr.c.ERR_INTERNAL, ptr @.rterr.m.intKind, i64 %wide)
  unreachable
}
@valrt.handler = weak global ptr null
@valrt.errorMsg = weak global [4096 x i8] zeroinitializer

define weak ptr @aslHandlerSlot() {
entry:
  ret ptr @valrt.handler
}

define weak ptr @aslErrorText() {
entry:
  ret ptr @valrt.errorMsg
}
define internal tailcc i64 @gcAslState() {
  %p = ptrtoint ptr @gcAsl.state to i64
  ret i64 %p
}
define internal tailcc i64 @gcAslCollect() {
  call void @asl_gc_collect()
  ret i64 0
}
define internal tailcc i64 @gcAslMutatorRoots() {
  call void @gcMutatorRoots(ptr @gcAslMarkRootC)
  ret i64 0
}
define internal tailcc i64 @gcAslExternalRoots() {
entry:
  %f = load ptr, ptr @gcExternalRoots
  %z = icmp eq ptr %f, null
  br i1 %z, label %done, label %call
call:
  call void %f(ptr @gcAslMarkRootC)
  br label %done
done:
  ret i64 0
}
define internal tailcc i64 @gcAslStackBase() {
  %p = load ptr, ptr @gcStackBase
  %i = ptrtoint ptr %p to i64
  ret i64 %i
}
define internal tailcc i64 @gcAslStackTop() {
  %p = load ptr, ptr @gcStackTop
  %i = ptrtoint ptr %p to i64
  ret i64 %i
}
define internal tailcc i64 @gcAslCallFin(i64 %f, i64 %a) {
  %fp = inttoptr i64 %f to ptr
  %ap = inttoptr i64 %a to ptr
  call void %fp(ptr %ap)
  ret i64 0
}
define internal tailcc i64 @gcAslFinGuarded(i64 %f, i64 %a, i64 %g) {
entry:
  %jb = alloca [128 x i64], align 16
  %gp = inttoptr i64 %g to ptr
  %getp = getelementptr inbounds i8, ptr %gp, i64 0
  %get = load ptr, ptr %getp
  %setp = getelementptr inbounds i8, ptr %gp, i64 8
  %set = load ptr, ptr %setp
  %prev = call ptr %get()
  %r = call i32 @setjmp(ptr %jb)
  %z = icmp eq i32 %r, 0
  br i1 %z, label %run, label %caught
run:
  call void %set(ptr %jb)
  %fp = inttoptr i64 %f to ptr
  %ap = inttoptr i64 %a to ptr
  call void %fp(ptr %ap)
  call void %set(ptr %prev)
  ret i64 0
caught:
  call void %set(ptr %prev)
  ret i64 1
}
define internal tailcc i64 @gcAslRethrow(i64 %g) {
  %gp = inttoptr i64 %g to ptr
  %rp = getelementptr inbounds i8, ptr %gp, i64 16
  %r = load ptr, ptr %rp
  call void %r()
  unreachable
}
define internal tailcc i64 @gcAslSortLarge(i64 %base, i64 %n) {
  %bp = inttoptr i64 %base to ptr
  call void @qsort(ptr %bp, i64 %n, i64 8, ptr @gcAslLargeCmp)
  ret i64 0
}
define internal tailcc i64 @gcAslCtz(i64 %w) {
  %r = call i64 @llvm.cttz.i64(i64 %w, i1 true)
  ret i64 %r
}
declare i64 @llvm.ctlz.i64(i64, i1)
define internal tailcc i64 @gcAslClz(i64 %w) {
  %r = call i64 @llvm.ctlz.i64(i64 %w, i1 true)
  ret i64 %r
}
declare i64 @llvm.ctpop.i64(i64)
define internal tailcc i64 @gcAslPopcount(i64 %w) {
  %r = call i64 @llvm.ctpop.i64(i64 %w)
  ret i64 %r
}
define internal tailcc i64 @gcAslAtexitStats() {
  %r = call i32 @atexit(ptr @gcAslPrintStatsC)
  ret i64 0
}
define internal tailcc i64 @gcAslF64Bits(double %d) {
  %b = bitcast double %d to i64
  ret i64 %b
}
define internal tailcc double @gcAslBitsF64(i64 %b) {
  %d = bitcast i64 %b to double
  ret double %d
}
define internal tailcc i64 @gcAslF64ToU64(double %d) {
  %u = fptoui double %d to i64
  ret i64 %u
}
define internal tailcc i64 @gcAslPublish() {
  store ptr @gcAsl.state, ptr @asl_gc_state_ptr
  ret i64 0
}
define internal tailcc i64 @gcAslFailBuf() {
  %p = ptrtoint ptr @gcAsl.failBuf to i64
  ret i64 %p
}
declare ptr @calloc(i64, i64)
declare ptr @realloc(ptr, i64)
declare i64 @free(ptr)
declare ptr @memset(ptr, i32, i64)
declare ptr @memcpy(ptr, ptr, i64)
declare i64 @strlen(ptr)
declare ptr @mmap(ptr, i64, i32, i32, i32, i64)
declare i32 @munmap(ptr, i64)
declare ptr @getenv(ptr)
declare double @strtod(ptr, ptr)
declare i64 @strtoull(ptr, ptr, i32)
declare ptr @__error()
declare i32 @clock_gettime(i32, ptr)
declare i64 @exit(i32)
declare i32 @dprintf(i32, ptr, ...)
declare i32 @snprintf(ptr, i64, ptr, ...)
declare i64 @gcFloorFail(ptr, ptr, ...)
declare void @llvm.trap()
declare i64 @write(i32, ptr, i64)
declare i32 @fflush(ptr)
declare void @longjmp(ptr, i32) noreturn


define ptr @asl_alloc(i32 %t, i64 %n) {
  %t64 = sext i32 %t to i64
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Ealloc(i64 %t64, i64 %n)
  %p = inttoptr i64 %r to ptr
  ret ptr %p
}
define ptr @asl_alloc_raw(i32 %t, i64 %n) {
  %t64 = sext i32 %t to i64
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EallocRaw(i64 %t64, i64 %n)
  %p = inttoptr i64 %r to ptr
  ret ptr %p
}
define ptr @asl_alloc_cons() {
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EallocCons()
  %p = inttoptr i64 %r to ptr
  ret ptr %p
}
define ptr @asl_alloc_perm(i32 %t, i64 %n) {
  %t64 = sext i32 %t to i64
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EallocPerm(i64 %t64, i64 %n)
  %p = inttoptr i64 %r to ptr
  ret ptr %p
}
define void @asl_gc_root_push(ptr %v) {
  %i = ptrtoint ptr %v to i64
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2ErootPush(i64 %i)
  ret void
}
define void @asl_gc_root_pop(i32 %n) {
  %n64 = sext i32 %n to i64
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2ErootPop(i64 %n64)
  ret void
}
define void @gcInit() {
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Einit()
  ret void
}
define void @gcWillAllocate(i64 %n) {
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EwillAllocate(i64 %n)
  ret void
}
define void @gcAccount(ptr %o, i64 %n) {
  %i = ptrtoint ptr %o to i64
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Eaccount(i64 %i, i64 %n)
  ret void
}
define void @gcRegisterProto(ptr %p) {
  %i = ptrtoint ptr %p to i64
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EregisterProto(i64 %i)
  ret void
}
define ptr @gcFindObj(i64 %w) {
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EfindObj(i64 %w)
  %p = inttoptr i64 %r to ptr
  ret ptr %p
}
define i64 @gcFreedObjects() {
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EfreedObjects()
  ret i64 %r
}
define void @gcTestFailNextPageSetGrow() {
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EfailNextGrow()
  ret void
}
define void @gcScanConservative(ptr %lo, ptr %hi) {
  %l = ptrtoint ptr %lo to i64
  %h = ptrtoint ptr %hi to i64
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EscanConservative(i64 %l, i64 %h)
  ret void
}
define void @asl_gc_collect() {
entry:
  %jb = alloca [128 x i64], align 16
  %fe = alloca [4096 x i8], align 16
  %t0 = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2Ebegin()
  %g = load ptr, ptr @gcFloorGuard
  %gi = ptrtoint ptr %g to i64
  %fei = ptrtoint ptr %fe to i64
  store i8 0, ptr %fe
  %plain = icmp eq ptr %g, null
  br i1 %plain, label %unguarded, label %guarded
unguarded:
  %m0 = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmarkPhase()
  br label %sweep
guarded:
  %get = load ptr, ptr %g
  %setp = getelementptr inbounds i8, ptr %g, i64 8
  %set = load ptr, ptr %setp
  %prev = call ptr %get()
  %jumped = call i32 @setjmp(ptr %jb)
  %first = icmp eq i32 %jumped, 0
  br i1 %first, label %armed, label %caught
armed:
  call void %set(ptr %jb)
  %m1 = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmarkPhase()
  call void %set(ptr %prev)
  br label %sweep
caught:
  %a = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EabortMark()
  call void %set(ptr %prev)
  %rp = getelementptr inbounds i8, ptr %g, i64 16
  %rethrow = load ptr, ptr %rp
  call void %rethrow()
  unreachable
sweep:
  %s = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EsweepPhase(i64 %t0, i64 %gi, i64 %fei)
  ret void
}
define internal void @gcAslMarkRootC({ i64, i64 } %v) {
  %w0 = extractvalue { i64, i64 } %v, 0
  %w1 = extractvalue { i64, i64 } %v, 1
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EmarkRoot(i64 %w0, i64 %w1)
  ret void
}
define internal void @gcAslPrintStatsC() {
  %r = call tailcc i64 @asl$2Dtarget$2Dllvm$2FgcAsl$2EprintStats()
  ret void
}
define internal i32 @gcAslLargeCmp(ptr %a, ptr %b) {
  %x = load ptr, ptr %a
  %y = load ptr, ptr %b
  %xi = ptrtoint ptr %x to i64
  %yi = ptrtoint ptr %y to i64
  %lt = icmp ult i64 %xi, %yi
  %gt = icmp ugt i64 %xi, %yi
  %g = zext i1 %gt to i32
  %r = select i1 %lt, i32 -1, i32 %g
  ret i32 %r
}
@gcStackBase = global ptr null, align 8
@gcStackTop = global ptr null, align 8
@gcExternalRoots = global ptr null, align 8
@gcAsl.state = internal global { [64 x i64], [4288 x i64] } { [64 x i64] [i64 0, i64 33554432, i64 33554432, i64 0, i64 4611686018427387904, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 1, i64 -1, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 1, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0], [4288 x i64] zeroinitializer }, align 16
@asl_gc_state_ptr = weak global ptr null, align 8
@gcAsl.failBuf = internal global [1024 x i8] zeroinitializer, align 1

@gcFloorGuard = external global ptr
declare i32 @setjmp(ptr) returns_twice
declare void @gcMutatorRoots(ptr)
declare void @qsort(ptr, i64, i64, ptr)
declare i32 @atexit(ptr)
declare i64 @llvm.cttz.i64(i64, i1)
