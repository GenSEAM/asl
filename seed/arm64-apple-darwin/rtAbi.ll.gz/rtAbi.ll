source_filename = "aslRtAbi"

%Val = type { i64, i64 }

@asl_rt_spill = global [1024 x %Val] zeroinitializer, align 16
@rtAbi.ready = internal global i32 0, align 4
@rtAbi.slots = internal global ptr null, align 8
@rtAbi.count = internal global i32 0, align 4
@rtAbi.cap = internal global i32 0, align 4
@rtAbi.stackTop = internal global ptr null, align 8
@rtAbi.errInternal = private unnamed_addr constant [13 x i8] c"ERR_INTERNAL\00"
@rtAbi.errLimit = private unnamed_addr constant [10 x i8] c"ERR_LIMIT\00"
@rtAbi.errOom = private unnamed_addr constant [8 x i8] c"ERR_OOM\00"
@rtAbi.noStack = private unnamed_addr constant [31 x i8] c"cannot locate the native stack\00"
@rtAbi.tooMany = private unnamed_addr constant [26 x i8] c"more than %d global roots\00"
@rtAbi.noMemory = private unnamed_addr constant [56 x i8] c"out of memory growing the global root table to %d slots\00"
@rtAbi.kw.some = private unnamed_addr constant [5 x i8] c"some\00"
@rtAbi.kw.none = private unnamed_addr constant [5 x i8] c"none\00"
@rtAbi.kw.ok = private unnamed_addr constant [3 x i8] c"ok\00"
@rtAbi.kw.err = private unnamed_addr constant [4 x i8] c"err\00"
@rtAbi.kw.partial = private unnamed_addr constant [8 x i8] c"partial\00"

define void @asl_rt_init() {
entry:
  %ready = load i32, ptr @rtAbi.ready
  %done = icmp ne i32 %ready, 0
  br i1 %done, label %out, label %init
init:
  call void @gcInit()
  %id.some = call i32 @aslInternShared(ptr @rtAbi.kw.some, i64 4)
  store i32 %id.some, ptr @KW_SOME
  %id.none = call i32 @aslInternShared(ptr @rtAbi.kw.none, i64 4)
  store i32 %id.none, ptr @KW_NONE
  %id.ok = call i32 @aslInternShared(ptr @rtAbi.kw.ok, i64 2)
  store i32 %id.ok, ptr @KW_OK
  %id.err = call i32 @aslInternShared(ptr @rtAbi.kw.err, i64 3)
  store i32 %id.err, ptr @KW_ERR
  %id.partial = call i32 @aslInternShared(ptr @rtAbi.kw.partial, i64 7)
  store i32 %id.partial, ptr @KW_PARTIAL
  call void @rtAbi.locateStack()
  store ptr @rtAbi.externalRoots, ptr @gcExternalRoots
  store i32 1, ptr @rtAbi.ready
  br label %out
out:
  ret void
}

define void @asl_rt_global_root(ptr %slot) {
entry:
  %n = load i32, ptr @rtAbi.count
  %cap = load i32, ptr @rtAbi.cap
  %full = icmp eq i32 %n, %cap
  br i1 %full, label %grow, label %put
grow:
  %limit = icmp sgt i32 %cap, 1073741823
  br i1 %limit, label %tooMany, label %resize
tooMany:
  %tooManyText = alloca [128 x i8], align 1
  %tooManyLen = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %tooManyText, i64 128, ptr @rtAbi.tooMany, i32 %cap)
  call void (ptr, ptr, ...) @gcFloorFail(ptr @rtAbi.errLimit, ptr %tooManyText)
  unreachable
resize:
  %empty = icmp eq i32 %cap, 0
  %twice = shl i32 %cap, 1
  %cap1 = select i1 %empty, i32 16, i32 %twice
  %cap64 = sext i32 %cap1 to i64
  %bytes = shl i64 %cap64, 3
  %old = load ptr, ptr @rtAbi.slots
  %grown = call ptr @realloc(ptr %old, i64 %bytes)
  %oom = icmp eq ptr %grown, null
  br i1 %oom, label %noMemory, label %grew
noMemory:
  %noMemoryText = alloca [128 x i8], align 1
  %noMemoryLen = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %noMemoryText, i64 128, ptr @rtAbi.noMemory, i32 %cap1)
  call void (ptr, ptr, ...) @gcFloorFail(ptr @rtAbi.errOom, ptr %noMemoryText)
  unreachable
grew:
  store ptr %grown, ptr @rtAbi.slots
  store i32 %cap1, ptr @rtAbi.cap
  br label %put
put:
  %table = load ptr, ptr @rtAbi.slots
  %n64 = sext i32 %n to i64
  %at = getelementptr inbounds ptr, ptr %table, i64 %n64
  store ptr %slot, ptr %at
  %n1 = add i32 %n, 1
  store i32 %n1, ptr @rtAbi.count
  ret void
}

define void @abiGcRoots(ptr %mark) {
entry:
  br label %loop
loop:
  %i = phi i32 [ 0, %entry ], [ %i1, %body ]
  %n = load i32, ptr @rtAbi.count
  %more = icmp slt i32 %i, %n
  br i1 %more, label %body, label %out
body:
  %table = load ptr, ptr @rtAbi.slots
  %i64 = sext i32 %i to i64
  %at = getelementptr inbounds ptr, ptr %table, i64 %i64
  %slot = load ptr, ptr %at
  %v = load %Val, ptr %slot
  call void %mark(%Val %v)
  %i1 = add i32 %i, 1
  br label %loop
out:
  ret void
}

define weak void @gcMutatorRoots(ptr %mark) {
entry:
  call void @abiGcRoots(ptr %mark)
  ret void
}

define internal void @rtAbi.externalRoots(ptr %mark) noinline {
entry:
  call void @llvm.eh.unwind.init()
  %lo = call ptr @llvm.stacksave.p0()
  %hi = load ptr, ptr @rtAbi.stackTop
  notail call void @gcScanConservative(ptr %lo, ptr %hi)

  ret void
}


define internal void @rtAbi.locateStack() {
entry:
  %self = call ptr @pthread_self()
  %top = call ptr @pthread_get_stackaddr_np(ptr %self)
  store ptr %top, ptr @rtAbi.stackTop
  ret void
}

@gcExternalRoots = external global ptr
@KW_SOME = external global i32
@KW_NONE = external global i32
@KW_OK = external global i32
@KW_ERR = external global i32
@KW_PARTIAL = external global i32
declare void @gcInit()
declare void @gcScanConservative(ptr, ptr)
declare i32 @aslInternShared(ptr, i64)
declare void @gcFloorFail(ptr, ptr, ...) noreturn
declare ptr @realloc(ptr, i64)
declare i32 @snprintf(ptr, i64, ptr, ...)
declare void @llvm.eh.unwind.init()
declare ptr @llvm.stacksave.p0()
declare ptr @pthread_self()
declare ptr @pthread_get_stackaddr_np(ptr)
