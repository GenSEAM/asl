source_filename = "aslRtAbi"

%Val = type { i64, i64 }

@asl_rt_spill = global [1024 x %Val] zeroinitializer, align 16
@rtAbi.ready = internal global i32 0, align 4
@rtAbi.slots = internal global ptr null, align 8
@rtAbi.count = internal global i32 0, align 4
@rtAbi.cap = internal global i32 0, align 4
@rtAbi.stackTop = internal global ptr null, align 8
@rtAbi.errInternal = private unnamed_addr constant [13 x i8] c"ERR_INTERNAL\00"
@rtAbi.errLimit = private unnamed_addr constant [10 x i8] c"ERR_LIMIT\00"
@rtAbi.errOom = private unnamed_addr constant [8 x i8] c"ERR_OOM\00"
@rtAbi.noStack = private unnamed_addr constant [31 x i8] c"cannot locate the native stack\00"
@rtAbi.mainBody = internal global ptr null, align 8
@rtAbi.mainArgc = internal global i32 0, align 4
@rtAbi.mainArgv = internal global ptr null, align 8
@rtAbi.noMainThread = private unnamed_addr constant [150 x i8] c"cannot run main on a %lld-byte thread stack: sigfillset %d, pthread_sigmask %d, pthread_attr_init %d, pthread_attr_setstacksize %d, pthread_create %d\00"
@rtAbi.mainJoined = private unnamed_addr constant [52 x i8] c"the main thread ended without exit: pthread_join %d\00"
@rtAbi.noMainMask = private unnamed_addr constant [70 x i8] c"cannot restore the signal mask on the main thread: pthread_sigmask %d\00"
@rtAbi.tooMany = private unnamed_addr constant [26 x i8] c"more than %d global roots\00"
@rtAbi.noMemory = private unnamed_addr constant [56 x i8] c"out of memory growing the global root table to %d slots\00"
@rtAbi.kw.some = private unnamed_addr constant [5 x i8] c"some\00"
@rtAbi.kw.none = private unnamed_addr constant [5 x i8] c"none\00"
@rtAbi.kw.ok = private unnamed_addr constant [3 x i8] c"ok\00"
@rtAbi.kw.err = private unnamed_addr constant [4 x i8] c"err\00"
@rtAbi.kw.partial = private unnamed_addr constant [8 x i8] c"partial\00"

define void @asl_rt_init() {
entry:
  %ready = load i32, ptr @rtAbi.ready
  %done = icmp ne i32 %ready, 0
  br i1 %done, label %out, label %init
init:
  call void @gcInit()
  %id.some = call i32 @aslInternShared(ptr @rtAbi.kw.some, i64 4)
  store i32 %id.some, ptr @KW_SOME
  %id.none = call i32 @aslInternShared(ptr @rtAbi.kw.none, i64 4)
  store i32 %id.none, ptr @KW_NONE
  %id.ok = call i32 @aslInternShared(ptr @rtAbi.kw.ok, i64 2)
  store i32 %id.ok, ptr @KW_OK
  %id.err = call i32 @aslInternShared(ptr @rtAbi.kw.err, i64 3)
  store i32 %id.err, ptr @KW_ERR
  %id.partial = call i32 @aslInternShared(ptr @rtAbi.kw.partial, i64 7)
  store i32 %id.partial, ptr @KW_PARTIAL
  call void @rtAbi.locateStack()
  store ptr @rtAbi.externalRoots, ptr @gcExternalRoots
  store i32 1, ptr @rtAbi.ready
  br label %out
out:
  ret void
}

@rtAbi.mainMask = internal global [128 x i8] zeroinitializer, align 8

define i32 @asl_rt_main(ptr %body, i32 %argc, ptr %argv) {
entry:
  store ptr %body, ptr @rtAbi.mainBody
  store i32 %argc, ptr @rtAbi.mainArgc
  store ptr %argv, ptr @rtAbi.mainArgv
  %sigpipeIgnored = call ptr @signal(i32 13, ptr inttoptr (i64 1 to ptr))
  %all = alloca [128 x i8], align 8
  %attr = alloca [56 x i8], align 16
  %thread = alloca i64, align 8
  %filled = call i32 @sigfillset(ptr %all)
  %masked = call i32 @pthread_sigmask(i32 0, ptr %all, ptr @rtAbi.mainMask)
  %inited = call i32 @pthread_attr_init(ptr %attr)
  %sized = call i32 @pthread_attr_setstacksize(ptr %attr, i64 1073741824)
  %started = call i32 @pthread_create(ptr %thread, ptr %attr, ptr @rtAbi.mainThread, ptr null)
  %destroyed = call i32 @pthread_attr_destroy(ptr %attr)
  %any1 = or i32 %filled, %masked
  %any2 = or i32 %any1, %inited
  %any3 = or i32 %any2, %sized
  %any4 = or i32 %any3, %started
  %failed = icmp ne i32 %any4, 0
  br i1 %failed, label %noThread, label %join
join:
  %handle = load i64, ptr %thread
  %joined = call i32 @pthread_join(i64 %handle, ptr null)
  %joinedText = alloca [128 x i8], align 1
  %joinedLen = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %joinedText, i64 128, ptr @rtAbi.mainJoined, i32 %joined)
  call void (ptr, ptr, ...) @gcFloorFail(ptr @rtAbi.errInternal, ptr %joinedText)
  unreachable
noThread:
  %noThreadText = alloca [256 x i8], align 1
  %noThreadLen = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %noThreadText, i64 256, ptr @rtAbi.noMainThread, i64 1073741824, i32 %filled, i32 %masked, i32 %inited, i32 %sized, i32 %started)
  call void (ptr, ptr, ...) @gcFloorFail(ptr @rtAbi.errInternal, ptr %noThreadText)
  unreachable
}

define internal ptr @rtAbi.mainThread(ptr %unused) {
entry:
  %restored = call i32 @pthread_sigmask(i32 2, ptr @rtAbi.mainMask, ptr null)
  %restoreFailed = icmp ne i32 %restored, 0
  br i1 %restoreFailed, label %noMask, label %run
run:
  %body = load ptr, ptr @rtAbi.mainBody
  %argc = load i32, ptr @rtAbi.mainArgc
  %argv = load ptr, ptr @rtAbi.mainArgv
  %code = call i32 %body(i32 %argc, ptr %argv)
  %mainThreadFlushed = call i32 @fflush(ptr null)
  call void @exit(i32 %code)
  unreachable
noMask:
  %noMaskText = alloca [128 x i8], align 1
  %noMaskLen = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %noMaskText, i64 128, ptr @rtAbi.noMainMask, i32 %restored)
  call void (ptr, ptr, ...) @gcFloorFail(ptr @rtAbi.errInternal, ptr %noMaskText)
  unreachable
}

define void @asl_rt_global_root(ptr %slot) {
entry:
  %n = load i32, ptr @rtAbi.count
  %cap = load i32, ptr @rtAbi.cap
  %full = icmp eq i32 %n, %cap
  br i1 %full, label %grow, label %put
grow:
  %limit = icmp sgt i32 %cap, 1073741823
  br i1 %limit, label %tooMany, label %resize
tooMany:
  %tooManyText = alloca [128 x i8], align 1
  %tooManyLen = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %tooManyText, i64 128, ptr @rtAbi.tooMany, i32 %cap)
  call void (ptr, ptr, ...) @gcFloorFail(ptr @rtAbi.errLimit, ptr %tooManyText)
  unreachable
resize:
  %empty = icmp eq i32 %cap, 0
  %twice = shl i32 %cap, 1
  %cap1 = select i1 %empty, i32 16, i32 %twice
  %cap64 = sext i32 %cap1 to i64
  %bytes = shl i64 %cap64, 3
  %old = load ptr, ptr @rtAbi.slots
  %grown = call ptr @realloc(ptr %old, i64 %bytes)
  %oom = icmp eq ptr %grown, null
  br i1 %oom, label %noMemory, label %grew
noMemory:
  %noMemoryText = alloca [128 x i8], align 1
  %noMemoryLen = call i32 (ptr, i64, ptr, ...) @snprintf(ptr %noMemoryText, i64 128, ptr @rtAbi.noMemory, i32 %cap1)
  call void (ptr, ptr, ...) @gcFloorFail(ptr @rtAbi.errOom, ptr %noMemoryText)
  unreachable
grew:
  store ptr %grown, ptr @rtAbi.slots
  store i32 %cap1, ptr @rtAbi.cap
  br label %put
put:
  %table = load ptr, ptr @rtAbi.slots
  %n64 = sext i32 %n to i64
  %at = getelementptr inbounds ptr, ptr %table, i64 %n64
  store ptr %slot, ptr %at
  %n1 = add i32 %n, 1
  store i32 %n1, ptr @rtAbi.count
  ret void
}

define void @abiGcRoots(ptr %mark) {
entry:
  br label %loop
loop:
  %i = phi i32 [ 0, %entry ], [ %i1, %body ]
  %n = load i32, ptr @rtAbi.count
  %more = icmp slt i32 %i, %n
  br i1 %more, label %body, label %out
body:
  %table = load ptr, ptr @rtAbi.slots
  %i64 = sext i32 %i to i64
  %at = getelementptr inbounds ptr, ptr %table, i64 %i64
  %slot = load ptr, ptr %at
  %v = load %Val, ptr %slot
  call void %mark(%Val %v)
  %i1 = add i32 %i, 1
  br label %loop
out:
  ret void
}

define weak void @gcMutatorRoots(ptr %mark) {
entry:
  call void @abiGcRoots(ptr %mark)
  ret void
}

define internal void @rtAbi.externalRoots(ptr %mark) noinline {
entry:
  call void @llvm.eh.unwind.init()
  %lo = call ptr @llvm.stacksave.p0()
  %hi = load ptr, ptr @rtAbi.stackTop
  notail call void @gcScanConservative(ptr %lo, ptr %hi)

  ret void
}


define internal void @rtAbi.locateStack() {
entry:
  %at = alloca [56 x i8], align 16
  %addr = alloca ptr, align 8
  %size = alloca i64, align 8
  %self = call i64 @pthread_self()
  %got = call i32 @pthread_getattr_np(i64 %self, ptr %at)
  %gotFail = icmp ne i32 %got, 0
  br i1 %gotFail, label %fail, label %read
read:
  %rc = call i32 @pthread_attr_getstack(ptr %at, ptr %addr, ptr %size)
  %destroyed = call i32 @pthread_attr_destroy(ptr %at)
  %readFail = icmp ne i32 %rc, 0
  br i1 %readFail, label %fail, label %done
done:
  %base = load ptr, ptr %addr
  %bytes = load i64, ptr %size
  %top = getelementptr i8, ptr %base, i64 %bytes
  store ptr %top, ptr @rtAbi.stackTop
  ret void
fail:
  call void (ptr, ptr, ...) @gcFloorFail(ptr @rtAbi.errInternal, ptr @rtAbi.noStack)
  unreachable
}

@gcExternalRoots = external global ptr
@KW_SOME = external global i32
@KW_NONE = external global i32
@KW_OK = external global i32
@KW_ERR = external global i32
@KW_PARTIAL = external global i32
declare void @gcInit()
declare void @gcScanConservative(ptr, ptr)
declare i32 @aslInternShared(ptr, i64)
declare void @gcFloorFail(ptr, ptr, ...) noreturn
declare ptr @realloc(ptr, i64)
declare i32 @snprintf(ptr, i64, ptr, ...)
declare void @llvm.eh.unwind.init()
declare ptr @llvm.stacksave.p0()
declare ptr @signal(i32, ptr)
declare i32 @fflush(ptr)
declare i32 @sigemptyset(ptr)
declare i32 @sigaction(i32, ptr, ptr)
declare i32 @sigaltstack(ptr, ptr)
declare i32 @raise(i32)
declare i64 @write(i32, ptr, i64)
declare void @_exit(i32) noreturn
declare i32 @sigfillset(ptr)
declare i32 @pthread_sigmask(i32, ptr, ptr)
declare i32 @pthread_attr_init(ptr)
declare i32 @pthread_attr_setstacksize(ptr, i64)
declare i32 @pthread_create(ptr, ptr, ptr, ptr)
declare void @exit(i32) noreturn
declare i64 @pthread_self()
declare i32 @pthread_getattr_np(i64, ptr)
declare i32 @pthread_attr_getstack(ptr, ptr, ptr)
declare i32 @pthread_attr_destroy(ptr)
declare i32 @pthread_join(i64, ptr)
