source_filename = "aslRtFloor"

@gcFloorGuard = weak global ptr null, align 8
@gcFloorRaise = weak global ptr null, align 8

define weak void @gcFloorFail(ptr %code, ptr %msg, ...) noreturn {
entry:
  %line = alloca [1152 x i8], align 1
  %raise = load ptr, ptr @gcFloorRaise
  %hasRaise = icmp ne ptr %raise, null
  br i1 %hasRaise, label %raising, label %print
raising:
  call void %raise(ptr %code, ptr %msg)
  br label %print
print:
  %codeLen = call i64 @strlen(ptr %code)
  %cl = call i64 @llvm.umin.i64(i64 %codeLen, i64 125)
  %msgLen = call i64 @strlen(ptr %msg)
  %ml = call i64 @llvm.umin.i64(i64 %msgLen, i64 1023)
  call void @llvm.memcpy.p0.p0.i64(ptr %line, ptr %code, i64 %cl, i1 false)
  %sep = getelementptr inbounds i8, ptr %line, i64 %cl
  store i8 58, ptr %sep
  %space = getelementptr inbounds i8, ptr %sep, i64 1
  store i8 32, ptr %space
  %text = getelementptr inbounds i8, ptr %sep, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr %text, ptr %msg, i64 %ml, i1 false)
  %nl = getelementptr inbounds i8, ptr %text, i64 %ml
  store i8 10, ptr %nl
  %head = add i64 %cl, %ml
  %len = add i64 %head, 3
  call void @rtFloor.writeAll(ptr %line, i64 %len)
  call void @exit(i32 1)
  unreachable
}

define internal void @rtFloor.writeAll(ptr %p, i64 %n) {
entry:
  br label %loop
loop:
  %at = phi ptr [ %p, %entry ], [ %at, %interrupted ], [ %next, %advance ]
  %left = phi i64 [ %n, %entry ], [ %left, %interrupted ], [ %rest, %advance ]
  %done = icmp sle i64 %left, 0
  br i1 %done, label %out, label %write
write:
  %w = call i64 @write(i32 2, ptr %at, i64 %left)
  %failed = icmp slt i64 %w, 0
  br i1 %failed, label %error, label %wrote
error:
  %ep = call ptr @__errno_location()
  %e = load i32, ptr %ep
  %intr = icmp eq i32 %e, 4
  br i1 %intr, label %interrupted, label %out
interrupted:
  br label %loop
wrote:
  %none = icmp eq i64 %w, 0
  br i1 %none, label %out, label %advance
advance:
  %next = getelementptr inbounds i8, ptr %at, i64 %w
  %rest = sub i64 %left, %w
  br label %loop
out:
  ret void
}

declare i64 @write(i32, ptr, i64)
declare i64 @strlen(ptr)
declare ptr @__errno_location()
declare void @exit(i32) noreturn
declare i64 @llvm.umin.i64(i64, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
